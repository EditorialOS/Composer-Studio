-- Composer Studio v1.5 — one-shot migration.
-- Run in the Supabase SQL editor (or `supabase db push`) after creating
-- the project. Covers:
--   1. composer_mcp_keys   — per-customer MCP keys (SHA-256 hashes only)
--   2. asset_embeddings    — pgvector library embeddings (semantic search)
--   3. match_asset_embeddings — the RPC the semantic fallback calls

-- pgvector for semantic asset search
create extension if not exists vector;

-- ── 1. Per-customer MCP keys ────────────────────────────────────────
create table if not exists composer_mcp_keys (
  id          uuid primary key default gen_random_uuid(),
  key_hash    text not null unique,           -- SHA-256 hex of the presented key
  org_id      text not null,
  label       text not null default '',
  created_at  timestamptz not null default now(),
  revoked_at  timestamptz                     -- null = active
);

create index if not exists composer_mcp_keys_hash_idx on composer_mcp_keys (key_hash);
create index if not exists composer_mcp_keys_org_idx on composer_mcp_keys (org_id);

-- Row-level security: server access is via the service role (bypasses
-- RLS); keep anon/authenticated locked out of key material entirely.
alter table composer_mcp_keys enable row level security;

-- ── 2. Asset embeddings (pgvector semantic library search) ─────────
create table if not exists asset_embeddings (
  org_id      text not null,
  public_id   text not null,                  -- Cloudinary public_id
  content     text not null default '',       -- the embedded text (tags + context)
  embedding   vector(1536),                   -- text-embedding-3-small
  updated_at  timestamptz not null default now(),
  primary key (org_id, public_id)
);

alter table asset_embeddings enable row level security;

-- ── 3. Semantic match RPC ───────────────────────────────────────────
-- Called by the real AssetAdapter's semantic fallback and the DAM
-- search route: cosine similarity over stored embeddings.
create or replace function match_asset_embeddings(
  query_embedding vector(1536),
  match_count int default 8,
  org_id text default null
)
returns table (public_id text, content text, similarity float)
language sql stable
as $$
  select
    ae.public_id,
    ae.content,
    1 - (ae.embedding <=> query_embedding) as similarity
  from asset_embeddings ae
  where (match_asset_embeddings.org_id is null or ae.org_id = match_asset_embeddings.org_id)
    and ae.embedding is not null
  order by ae.embedding <=> query_embedding
  limit match_count;
$$;

-- ── 4. App tables (billing, audit, waitlist — Pixel-Sky fold-ins) ──
create table if not exists audit_logs (
  id          uuid primary key default gen_random_uuid(),
  org_id      text not null,
  user_id     text not null,
  action      text not null,
  details     jsonb default '{}'::jsonb,
  created_at  timestamptz default now()
);

create table if not exists organization_billing (
  org_id                   text primary key,
  stripe_customer_id       text,
  stripe_subscription_id   text,
  status                   text,
  price_id                 text,
  current_period_end       timestamptz,
  trial_end                timestamptz,
  created_at               timestamptz default now(),
  updated_at               timestamptz default now()
);

create table if not exists waitlist_signups (
  id          uuid primary key default gen_random_uuid(),
  email       text not null unique,
  source      text not null default 'marketing',
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);
