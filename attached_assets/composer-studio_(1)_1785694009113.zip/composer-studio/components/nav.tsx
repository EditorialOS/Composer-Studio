'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const LINKS = [
  { href: '/compose', label: 'Compose' },
  { href: '/newsletter', label: 'Newsletter' },
  { href: '/assets', label: 'Assets' },
  { href: '/library', label: 'Library' },
  { href: '/send', label: 'Send' },
  { href: '/memory', label: 'Memory' },
  { href: '/onboarding', label: 'Workspace' },
];

const HIDE_ON = ['/marketing', '/sign-in', '/sign-up', '/legal'];

export function Nav() {
  const pathname = usePathname();
  const mock = process.env.NEXT_PUBLIC_COMPOSER_MOCK === '1';

  if (HIDE_ON.some((p) => pathname.startsWith(p))) return null;

  return (
    <header className="sticky top-0 z-20 border-b border-black/5 bg-[#f7f5f0]/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-3.5">
        <Link href="/compose" className="flex items-center gap-2">
          <span className="text-sm font-semibold tracking-wide text-cs-t1">Composer Studio</span>
          {mock && (
            <span className="rounded-full border border-black/10 bg-cs-warnbg px-2 py-0.5 text-[10px] font-medium text-cs-warn">
              Mock mode
            </span>
          )}
        </Link>
        <nav className="flex items-center gap-1 text-[13px]">
          {LINKS.map((link) => {
            const active = pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-full px-3 py-1.5 transition ${
                  active
                    ? 'bg-cs-infobg font-medium text-cs-info'
                    : 'text-cs-t2 hover:bg-black/5 hover:text-cs-t1'
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
