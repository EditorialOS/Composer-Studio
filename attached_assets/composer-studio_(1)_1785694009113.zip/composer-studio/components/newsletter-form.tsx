'use client';

import { useEffect, useState } from 'react';
import type { EditionPackage, StoryPackage } from '@/lib/engine/types';
import { NEWSLETTER_DEMO_EDITION } from '@/lib/engine/fixtures/newsletter';
import { AssetResults } from './assets-search';
import { RightsBadge } from './ui';

const ACK_STEPS = [
  'reading the edition…',
  'decomposing into story atoms…',
  'searching assets + rights per story…',
  'weighing the hero candidates…',
  'assembling the edition package…',
];

// ── Hero recommendation card (top of the results view) ──────

function HeroCard({ edition }: { edition: EditionPackage }) {
  if (!edition.hero) {
    return (
      <div className="rounded-cs-lg border border-cs-bd3 bg-cs-warnbg p-4">
        <p className="m-0 mb-1 text-[11px] font-semibold uppercase tracking-[0.5px] text-cs-warn">
          Hero recommendation — withheld
        </p>
        <p className="m-0 text-[13px] leading-[1.6] text-cs-t2">{edition.heroNote}</p>
      </div>
    );
  }
  const { hero } = edition;
  return (
    <div className="overflow-hidden rounded-cs-lg bg-cs-b2">
      <div className="grid gap-0 sm:grid-cols-[240px_1fr]">
        <div className="relative" style={{ aspectRatio: '4/3' }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={hero.asset.thumbnailUrl}
            alt={hero.asset.tags.join(', ') || hero.assetId}
            className="absolute inset-0 h-full w-full object-cover"
            loading="lazy"
          />
          <div className="absolute left-2 top-2">
            <RightsBadge status={hero.asset.rightsStatus} />
          </div>
        </div>
        <div className="p-4">
          <p className="m-0 mb-1 text-[11px] font-semibold uppercase tracking-[0.5px] text-cs-success">
            Hero recommendation — one pick for the whole edition
          </p>
          <p className="m-0 text-[14px] font-medium text-cs-t1">{hero.assetId}</p>
          <p className="m-0 mt-0.5 text-[12px] text-cs-t2">
            Story {hero.storyIndex + 1} — &quot;{hero.storyTitle}&quot;
            {hero.asset.photographer ? ` · ${hero.asset.photographer}` : ''}
            {hero.asset.rightsLabel ? ` · ${hero.asset.rightsLabel}` : ''}
          </p>
          <p className="m-0 mt-2 text-[13px] leading-[1.6] text-cs-t2">{hero.reasoning}</p>
          {hero.asset.derivatives.length > 0 && (
            <div className="mt-2.5 flex flex-wrap gap-1">
              {hero.asset.derivatives.map((d) => (
                <a
                  key={d.key}
                  href={d.url}
                  target="_blank"
                  rel="noreferrer"
                  title={`${d.label} — ${d.width}×${d.height}`}
                  className="rounded bg-cs-b1 px-1.5 py-0.5 text-[10px] text-cs-info hover:underline"
                >
                  {d.key}
                </a>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Per-story section ───────────────────────────────────────

function StorySection({ story }: { story: StoryPackage }) {
  return (
    <section className="cs-card">
      <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="m-0 text-[15px] font-medium text-cs-t1">
          Story {story.atom.index + 1}: {story.atom.title}
        </h3>
        <span className="text-[11px] text-cs-t3">
          {story.atom.wordCount} words · {story.assets.length} asset
          {story.assets.length === 1 ? '' : 's'}
        </span>
      </div>
      {story.atom.dek && (
        <p className="m-0 mb-3 text-[12px] leading-[1.6] text-cs-t3">{story.atom.dek}</p>
      )}
      {story.note && (
        <p className="m-0 mb-3 rounded-cs-md bg-cs-warnbg px-3 py-2 text-[12px] text-cs-warn">
          {story.note}
        </p>
      )}
      {/* Reuses the /assets results grid: rights badges, derivative
          pills, and the per-source honesty report. */}
      <AssetResults
        result={{
          query: story.atom.title,
          total: story.assets.length,
          assets: story.assets,
          sources: story.sources,
        }}
      />
    </section>
  );
}

// ── The results view ────────────────────────────────────────

export function EditionResults({ edition }: { edition: EditionPackage }) {
  return (
    <div className="mt-8">
      <div className="mb-4">
        <p className="cs-card-label">Edition package</p>
        <h2 className="m-0 text-[18px] font-medium text-cs-t1">{edition.title}</h2>
        <p className="m-0 mt-1 text-[12px] text-cs-t3">
          {edition.storyCount} stories · atomized by {edition.atomization === 'llm' ? 'the configured model' : 'the heading/HR heuristic'} ·{' '}
          {edition.generationMs}ms
        </p>
      </div>

      <HeroCard edition={edition} />

      {edition.notes.length > 0 && (
        <div className="mt-4 rounded-cs-md bg-cs-b1 p-3.5">
          <p className="m-0 mb-1 text-[11px] font-semibold uppercase tracking-[0.5px] text-cs-t3">
            Honesty notes — what worked, what didn&apos;t
          </p>
          {edition.notes.map((note, i) => (
            <p key={i} className="m-0 mt-1 text-[12px] leading-[1.5] text-cs-t2">
              · {note}
            </p>
          ))}
        </div>
      )}

      <div className="mt-5 flex flex-col gap-4">
        {edition.stories.map((story) => (
          <StorySection key={story.atom.index} story={story} />
        ))}
      </div>
    </div>
  );
}

// ── The form ────────────────────────────────────────────────

export function NewsletterForm({ initialEditionId }: { initialEditionId?: string }) {
  const [edition, setEdition] = useState('');
  const [phase, setPhase] = useState<'idle' | 'working' | 'error'>('idle');
  const [ackStep, setAckStep] = useState(0);
  const [error, setError] = useState('');
  const [result, setResult] = useState<EditionPackage | null>(null);

  // Deep link from /compose when the intake router routes a paste here.
  useEffect(() => {
    if (!initialEditionId) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/newsletter?id=${encodeURIComponent(initialEditionId)}`);
        if (!res.ok) return;
        const data = (await res.json()) as EditionPackage;
        if (!cancelled) setResult(data);
      } catch {
        // deep-link load is best-effort
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [initialEditionId]);

  const submit = async () => {
    if (!edition.trim() || phase === 'working') return;
    setPhase('working');
    setError('');
    setResult(null);
    setAckStep(0);
    const timers = ACK_STEPS.map((_, i) => setTimeout(() => setAckStep(i), 350 * i));
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ edition: edition.trim() }),
      });
      const data = (await res.json()) as EditionPackage & { error?: string };
      if (!res.ok || 'error' in data) {
        throw new Error('error' in data && data.error ? data.error : 'Edition composition failed.');
      }
      setResult(data);
      setPhase('idle');
    } catch (err) {
      setPhase('error');
      setError(err instanceof Error ? err.message : 'Edition composition failed.');
    } finally {
      timers.forEach(clearTimeout);
    }
  };

  return (
    <div>
      <div className="cs-card">
        <textarea
          value={edition}
          onChange={(e) => setEdition(e.target.value)}
          rows={14}
          placeholder={
            'Paste the full edition — every story. Markdown headings (## per story), HR-separated, or Subject:-line structure all work. ' +
            'Or start with "/run newsletter" anywhere you paste from.'
          }
          className="w-full resize-y rounded-cs-md border border-cs-bd3 bg-cs-b1 p-3 font-mono text-[13px] leading-[1.6] text-cs-t1 outline-none placeholder:text-cs-t3 focus:border-cs-info"
          disabled={phase === 'working'}
        />
        <div className="mt-4 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setEdition(NEWSLETTER_DEMO_EDITION)}
            className="text-[12px] text-cs-info hover:underline"
            disabled={phase === 'working'}
          >
            Try: demo edition (The Departures — 3 stories)
          </button>
          <button
            type="button"
            onClick={submit}
            disabled={!edition.trim() || phase === 'working'}
            className="rounded-full bg-cs-t1 px-5 py-2 text-[13px] font-medium text-white transition enabled:hover:opacity-85 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Compose edition
          </button>
        </div>

        {phase === 'working' && (
          <div className="mt-5 rounded-cs-md bg-cs-b1 p-3.5">
            <p className="m-0 text-[13px] font-medium text-cs-t1">
              on it — <span className="cs-pulse text-cs-t2">{ACK_STEPS[ackStep]}</span>
            </p>
          </div>
        )}
        {phase === 'error' && (
          <div className="mt-5 rounded-cs-md bg-cs-dangerbg p-3.5">
            <p className="m-0 text-[13px] text-cs-danger">{error}</p>
          </div>
        )}
      </div>

      {result && <EditionResults edition={result} />}
    </div>
  );
}
