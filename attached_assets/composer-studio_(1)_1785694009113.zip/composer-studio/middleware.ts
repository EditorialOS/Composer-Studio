import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server';
import { NextResponse } from 'next/server';
import type { NextFetchEvent, NextRequest } from 'next/server';

const isPublicRoute = createRouteMatcher([
  '/marketing(.*)',
  '/sign-in(.*)',
  '/sign-up(.*)',
  '/api/marketing(.*)',
  '/api/stripe/webhook(.*)',
  // MCP endpoint does its own Bearer (COMPOSER_API_KEY) auth — agents
  // don't carry Clerk sessions.
  '/api/mcp(.*)',
]);

const clerkHandler = clerkMiddleware(async (auth, req) => {
  if (!isPublicRoute(req)) {
    await auth.protect();
  }
});

export default function middleware(req: NextRequest, event: NextFetchEvent) {
  // MOCK MODE: COMPOSER_MOCK=1 bypasses Clerk entirely so the product
  // runs end-to-end with zero API keys (demo org: "Demo Publication").
  if (process.env.COMPOSER_MOCK === '1') {
    return NextResponse.next();
  }
  // CLERK NOT CONFIGURED: don't 500 every route (the MCP endpoint does
  // its own Bearer auth and works without Clerk). Dashboard routes
  // still require auth and fail honestly until Clerk keys are set.
  if (!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY) {
    return NextResponse.next();
  }
  return clerkHandler(req, event);
}

export const config = {
  matcher: [
    // Skip Next.js internals and all static files, unless found in search params
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    // Always run for API routes
    '/(api|trpc)(.*)',
  ],
};
