# Composer Studio

**Paste a brief, get a publishable package** — your images, rights-checked and cropped; your
archive's prior coverage; the competitive landscape; the angle to take. Works with the DAM and
CMS you already have. Is one if you don't.

## Quickstart (zero API keys)

```bash
npm install
COMPOSER_MOCK=1 npm run dev
```

Open http://localhost:3000 — you are **Demo Publication**, fully signed in. Everything works
end-to-end with mock adapters and rich fixtures:

- **Compose** (`/compose`) — paste a brief (or click a demo brief). The intake router
  classifies it automatically: story/brief → the full package loop; short find-intent
  (e.g. "search for apple pictures") → the asset quick-hit; edition-shaped input
  (multiple headings, 800+ words, or a "/run newsletter" prefix) → the newsletter batch.
  The UI shows which route was taken.
- **Newsletter** (`/newsletter`) — the batch workflow (v1.5): paste a full multi-story
  edition → decomposed into story atoms → per-story asset packages (search + rights +
  derivative crops, with per-source honesty notes) → ONE hero recommendation for the
  edition — the strongest cleared-rights asset across all stories, with reasoning.
  Try the demo edition: **The Departures** (Oaxaca hotel opening, Tokyo city guide,
  mezcal trend piece).
- **Assets** (`/assets`) — the standalone quick-hit: source-agnostic search across every
  connected library with rights badges, derivative pills, and an honest per-source report
  (matched / searched-but-empty / not connected — e.g. Drive searches *filenames only*).
- **The Package** (`/package/casa-soledad`, `/package/noto-earthquake`) — the tabbed artifact:
  five-gate editorial assessment with verdict + required revisions, rights-badged asset matching
  with derivative crops, market context with source-URL'd facts, and honest provenance
  ("what worked vs didn't").
- **Library** (`/library`) — asset grid with CLEARED / EXPIRING / CHECK / UNKNOWN rights badges.
- **Send** (`/send`) — beehiiv draft / CMS draft / download-all (all mock).
- **Memory** (`/memory`) — every package logged: lanes taken, rights flagged, verdict.
- **Workspace** (`/onboarding`) — active themes, recent coverage, voice notes, calendar. The
  gate evaluation consumes these on every run. Includes adapter capability probing.

Two fixture packages seed automatically: **Casa Soledad** (hotel launch, REVISE with a red on
theme alignment) and **Noto earthquake** (breaking news context package).

## Architecture map

```
app/
  compose/            brief input → POST /api/compose → intake router → package OR quick-hit OR newsletter
  newsletter/         the batch workflow (edition → atoms → per-story packages + hero pick)
  assets/             standalone asset quick-hit (source-agnostic, per-source honesty)
  package/[id]/       the hero screen (components/package-view.tsx — tabbed artifact)
  library/            asset grid + rights badges
  send/               one click onward
  memory/             package log
  onboarding/         workspace context + capability probing
  marketing/          landing page ("Paste a brief, get a publishable package")
  api/compose|assets|newsletter|send|workspace/  engine routes
  api/mcp/            MCP endpoint (Streamable HTTP) — same engine, agent-callable
  api/settings/keys/  per-customer MCP key mint/list/revoke (SHA-256 hashes in Supabase)
  api/dam|stripe|billing|audit/ Pixel-Sky fold-ins (billing, audit, BYOC Cloudinary)
components/
  package-view.tsx    tabbed package UI (ported from the reference HTML designs)
  assets-search.tsx   quick-hit form + merged results grid (reused by compose + newsletter)
  newsletter-form.tsx edition form + results view (hero card + per-story sections)
  nav.tsx, ui.tsx, compose-form.tsx, send-form.tsx, workspace-form.tsx
lib/
  mock.ts             COMPOSER_MOCK flag + demo workspace
  workspace.ts        org resolution (Clerk in prod, demo org in mock)
  mcp-keys.ts         per-customer MCP keys (SHA-256 hash lookup, legacy shared-key fallback)
  engine/
    types.ts          domain types + the six adapter interfaces + edition types
    router.ts         THE INTAKE ROUTER (assets vs compose vs newsletter; LLM seam)
    assets.ts         source-agnostic asset fan-out + rights check
    compose.ts        THE COMPOSE LOOP
    newsletter.ts     THE NEWSLETTER BATCH LOOP (atomize → per-story packages → hero)
    mcp.ts            MCP tool implementations (shared engine, thin wrapper)
    store.ts          package/edition/memory/send/workspace store (file mock → Supabase)
    derivatives.ts    Cloudinary URL transforms (hero/social/story/thumb)
    fixtures/         Casa Soledad + Noto earthquake + The Departures demo edition
    adapters/
      index.ts        getAdapters() — mock vs real selection + capability probing
      mock/           rich fixtures, honest gaps (visualSearch: false, etc.)
      real/           env-gated implementations (llm/search/assets/archive/send/model)
  supabase.ts, stripe.ts, openai.ts, cloudinary.ts, billing.ts, audit.ts …  fold-in infra
supabase/migrations/  0001_composer_v15.sql — composer_mcp_keys + asset_embeddings + match RPC
middleware.ts         Clerk middleware with COMPOSER_MOCK=1 bypass; /api/mcp does Bearer auth
```

### The intake router (lib/engine/router.ts)

One input box; the brief classifies itself (spec Part 5B). Short asset-search intent → the
`/assets` quick-hit (AssetAdapter fan-out only — no archive, no market context). Edition-shaped
input (multiple headings, 800+ words, or "/run newsletter") → the `/newsletter` batch.
Story/brief → the full compose loop. Mock mode uses a keyword/length/structure heuristic;
real mode can classify through the ModelAdapter seam (`classifyIntakeWithModel` — strict JSON,
temperature 0, heuristic fallback). The classification table grows by rows, not rebuilds.

### The newsletter batch loop (lib/engine/newsletter.ts) — v1.5

1. **Atomize** — split the edition into story atoms (markdown headings / HRs / Subject: lines;
   LLM atomization seam in real mode with honest heuristic fallback).
2. **Per-story asset packages** — the same source-agnostic fan-out, rights enrichment, and
   derivative crops as the /assets quick-hit, run per story in parallel.
3. **Hero recommendation** — ONE hero for the edition: the highest-resolution CLEARED-rights
   asset across all stories, with reasoning. EXPIRING/CHECK/UNKNOWN assets are never
   recommended; if nothing is cleared, the recommendation is honestly withheld.
4. **Assemble the edition package** → store → **log to memory** (lanes, rights flagged).

### The compose loop (lib/engine/compose.ts)

1. **Parse brief** → headline, kind, search tags, scenario (ModelAdapter)
2. **Editorial gate evaluation** — five gates (theme alignment, angle differentiation, audience
   need, production reality, calendar fit) with colored status + verdict APPROVED/REVISE +
   required revisions. Consumes workspace context.
3. **PARALLEL** archive search + asset search + market context (Promise.all)
4. **Rights enrichment + derivative crops** (RightsAdapter, AssetAdapter transforms)
5. **Filtration** — any market-context fact without a `sourceUrl` is dropped at assembly, in
   code, and counted honestly ("no URL, no fact").
6. **Assemble Package** → save → **log to memory** (lanes taken, rights flagged).

### The adapter seam (spec Part 5)

Every capability is a pluggable adapter — nothing is hardwired. Each adapter reports
capabilities; the engine degrades gracefully and names every gap in the package's provenance.

| Adapter | Interface | Mock | Real (env-gated) reads |
|---|---|---|---|
| `webSearch` | `SearchAdapter` | fixture market context | `SEARCH_PROVIDER` + `TAVILY_API_KEY` / `BRAVE_API_KEY` / `PERPLEXITY_API_KEY` (first-configured-wins default) |
| `imageLibrary` | `AssetAdapter` | fixture assets + derivatives | `CLOUDINARY_*` + pgvector semantic fallback (`OPENAI_API_KEY` + Supabase embeddings) |
| `archive` | `ArchiveAdapter` | fixture prior coverage | `GOOGLE_DRIVE_API_KEY` or `GOOGLE_SERVICE_ACCOUNT_JSON` (else honest "No archive configured") |
| `rights` | `RightsAdapter` | embedded-metadata simulation | reads Cloudinary context metadata (photographer / usage_rights / expiration) |
| `send` | `SendAdapter` | mock beehiiv/CMS/download | `BEEHIIV_API_KEY` + `BEEHIIV_PUBLICATION_ID` (REST v2 draft posts) |
| `llm` | `ModelAdapter` | fixture + heuristic gate eval | `ANTHROPIC_API_KEY` (default claude-sonnet) or `OPENAI_API_KEY` + optional `OPENAI_BASE_URL` (Kimi/Groq) |

Rules of the seam: search is hot-swappable; anything the user has, Composer can ride; graceful
degradation is a product feature (the package always ships, gaps are always named); every
adapter ships a mock so the product runs offline end-to-end. Every real adapter is fetch-only
(no SDKs beyond the existing Cloudinary/Supabase clients), temperature ~0 with strict JSON
schemas for model calls, and falls back to heuristics with an honest provenance note when a
key is missing or the API errors.

## MCP (agent access — same engine, thin wrapper)

The engine is exposed as MCP tools over Streamable HTTP at **`/api/mcp`**
(`app/api/mcp/route.ts`, `@modelcontextprotocol/sdk`). One engine, two faces: the dashboard is
the money product; MCP is the distribution play — same adapters, same fixtures, same honesty.

**Tools** (`GET /api/mcp` returns the tools/list-compatible descriptor):

| Tool | What it does |
|---|---|
| `search_assets(query)` | Merged asset results + per-source honesty report (matched / searched-but-empty / not connected) |
| `compose_package(brief)` | Full package JSON: `id`, `verdict`, and the complete tabs payload |
| `check_rights(asset_id)` | Rights badge + expiry + photographer, with "not on file" honesty |
| `compose_newsletter(edition)` | Edition batch: story atoms, per-story asset packages, hero recommendation (v1.5) |
| `send_package(package_id, destination)` | beehiiv draft / CMS draft / download (mock adapters in mock mode) |

**Auth:** every request needs `Authorization: Bearer <key>`. Per-customer keys are minted at
`POST /api/settings/keys` and verified by SHA-256 hash against the `composer_mcp_keys` table
(Supabase — see `supabase/migrations/0001_composer_v15.sql`); the legacy shared
`COMPOSER_API_KEY` works as a fallback, and in `COMPOSER_MOCK=1` any non-empty key resolves
the demo org. Missing/invalid keys get a JSON-RPC-shaped `401`.

**Claude Cowork / Desktop config** (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "composer-studio": {
      "url": "https://<your-host>/api/mcp",
      "headers": { "Authorization": "Bearer <COMPOSER_API_KEY>" }
    }
  }
}
```

Local dev: `"url": "http://localhost:3000/api/mcp"`, any bearer token while `COMPOSER_MOCK=1`.

## Environment

See `.env.example` for the full table. Only `COMPOSER_MOCK=1` is required for the demo. For
production: Clerk (auth), Supabase (store/billing/audit), Cloudinary (library), Stripe
(billing), a search provider, beehiiv (send), OpenAI/Anthropic (models). `HANDOFF.md` has the
dummy-proof version.

## Scripts

```bash
npm run dev     # develop
npm run build   # production build
npm run start   # serve the build
npm run lint    # eslint
```

## Deploy

Standard Next.js on Vercel. Set env vars per `.env.example` / `HANDOFF.md`. In mock mode no
env vars are needed at all.
