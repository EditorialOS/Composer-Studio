import { NewsletterForm } from '@/components/newsletter-form';
import { ensureSeedData } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

export default async function NewsletterPage({
  searchParams,
}: {
  searchParams: Promise<{ edition?: string }>;
}) {
  const { orgId, orgName } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);
  const { edition: editionId } = await searchParams;

  return (
    <main className="mx-auto max-w-5xl px-6 py-8">
      <p className="mb-1 text-[11px] uppercase tracking-[0.5px] text-cs-t3">
        Newsletter — {orgName}
      </p>
      <h1 className="m-0 mb-1.5 text-[20px] font-medium text-cs-t1">
        Paste the edition, get per-story asset packages + one hero pick
      </h1>
      <p className="mb-6 mt-0 max-w-2xl text-[13px] leading-[1.6] text-cs-t2">
        The batch workflow: the edition is decomposed into story atoms, every story gets its
        own asset search with rights badges and derivative crops, and the engine recommends
        ONE hero for the whole edition — the strongest cleared-rights asset, with reasoning.
        Gaps are named, never silent.
      </p>

      <NewsletterForm initialEditionId={editionId} />
    </main>
  );
}
