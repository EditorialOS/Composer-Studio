// Admin: per-customer MCP keys (v1.5). Mint / list / revoke keys for
// the caller's org. Keys are stored as SHA-256 hashes in
// composer_mcp_keys (supabase/migrations/0001_composer_v15.sql); the
// plaintext key is returned ONCE at mint time and never persisted.
//
// Mock-guarded: in COMPOSER_MOCK=1 any non-empty key already works, so
// minting is a no-op with an honest note. Without Supabase configured
// the route says so (503) instead of failing silently.

import { NextResponse } from 'next/server';
import { isMockMode, MOCK_WORKSPACE } from '@/lib/mock';
import { listMcpKeys, mintMcpKey, revokeMcpKey, supabaseConfigured } from '@/lib/mcp-keys';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const runtime = 'nodejs';

const MOCK_NOTE =
  'Mock mode — any non-empty bearer key resolves the demo org, so there is nothing to mint. Connect Supabase (SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY) and unset COMPOSER_MOCK to manage per-customer keys.';

const UNCONFIGURED = NextResponse.json(
  {
    error:
      'Key storage not configured — set SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY and run supabase/migrations/0001_composer_v15.sql.',
  },
  { status: 503 },
);

export async function GET() {
  if (isMockMode()) {
    return NextResponse.json({
      mock: true,
      note: MOCK_NOTE,
      keys: [
        {
          id: 'demo-key',
          org_id: MOCK_WORKSPACE.orgId,
          label: 'demo (any non-empty key works)',
          created_at: new Date().toISOString(),
          revoked_at: null,
        },
      ],
    });
  }
  if (!supabaseConfigured()) return UNCONFIGURED;
  const { orgId } = await getWorkspaceIdentity();
  return NextResponse.json({ keys: await listMcpKeys(orgId) });
}

export async function POST(req: Request) {
  if (isMockMode()) {
    return NextResponse.json({ mock: true, note: MOCK_NOTE });
  }
  if (!supabaseConfigured()) return UNCONFIGURED;
  const { orgId } = await getWorkspaceIdentity();
  let label = 'MCP key';
  try {
    const body = (await req.json()) as { label?: string };
    if (typeof body.label === 'string' && body.label.trim()) label = body.label.trim().slice(0, 80);
  } catch {
    // no body is fine — default label
  }
  const { key, row } = await mintMcpKey(orgId, label);
  return NextResponse.json({
    // Shown once — store it now. Only the hash is kept server-side.
    key,
    row,
    note: 'Store this key now — it is shown only once. Agents send it as Authorization: Bearer <key> to POST /api/mcp.',
  });
}

export async function DELETE(req: Request) {
  if (isMockMode()) {
    return NextResponse.json({ mock: true, note: MOCK_NOTE });
  }
  if (!supabaseConfigured()) return UNCONFIGURED;
  const { orgId } = await getWorkspaceIdentity();
  const id = new URL(req.url).searchParams.get('id') ?? '';
  if (!id) {
    return NextResponse.json({ error: 'Missing ?id= of the key to revoke.' }, { status: 400 });
  }
  const ok = await revokeMcpKey(orgId, id);
  if (!ok) {
    return NextResponse.json({ error: 'Revoke failed — key not found for this org.' }, { status: 404 });
  }
  return NextResponse.json({ revoked: id });
}
