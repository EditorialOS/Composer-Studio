/**
 * Composer Studio — MCP endpoint (Streamable HTTP).
 *
 * The same engine the dashboard uses, exposed as agent-callable tools
 * (spec Part 4: one engine, two faces — MCP follows from the same
 * codebase as a thin wrapper; the proxy pattern is proven twice:
 * The-Gate-VPS, Context-API).
 *
 * Tools: search_assets · compose_package · check_rights · compose_newsletter ·
 * send_package (GET /api/mcp returns the tools/list-compatible descriptor.)
 *
 * Auth: `Authorization: Bearer <key>` on every request. Per-customer
 * keys are minted at /api/settings/keys and verified by SHA-256 hash
 * against composer_mcp_keys (Supabase); the legacy shared
 * COMPOSER_API_KEY still works as a fallback. In COMPOSER_MOCK=1 any
 * non-empty key works and resolves the demo org.
 *
 * ── Client config: Claude Cowork / Claude Desktop ──────────────────
 * claude_desktop_config.json (or Cowork's MCP settings):
 *
 * {
 *   "mcpServers": {
 *     "composer-studio": {
 *       "url": "https://<your-host>/api/mcp",
 *       "headers": {
 *         "Authorization": "Bearer <COMPOSER_API_KEY>"
 *       }
 *     }
 *   }
 * }
 *
 * Local dev: "url": "http://localhost:3000/api/mcp" with any bearer
 * token while COMPOSER_MOCK=1.
 * ───────────────────────────────────────────────────────────────────
 */

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import { z } from 'zod';
import {
  MCP_TOOL_DESCRIPTORS,
  toolCheckRights,
  toolComposeNewsletter,
  toolComposePackage,
  toolSearchAssets,
  toolSendPackage,
} from '@/lib/engine/mcp';
import { resolveMcpKey } from '@/lib/mcp-keys';

export const runtime = 'nodejs';

interface McpAuth {
  orgId: string;
}

/**
 * Bearer auth. Mock mode: any non-empty key → demo org. Real mode:
 * per-customer keys (SHA-256 hash lookup in composer_mcp_keys), with
 * the legacy shared COMPOSER_API_KEY as fallback.
 */
async function authenticate(req: Request): Promise<McpAuth | null> {
  const header = req.headers.get('authorization') ?? '';
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  const token = match?.[1]?.trim();
  if (!token) return null;
  const resolved = await resolveMcpKey(token);
  return resolved ? { orgId: resolved.orgId } : null;
}

/** JSON-RPC-shaped 401, per the MCP-over-HTTP convention. */
function unauthorized(): Response {
  return Response.json(
    {
      jsonrpc: '2.0',
      error: {
        code: -32001,
        message:
          'Unauthorized — send Authorization: Bearer <COMPOSER_API_KEY>. In mock mode any non-empty key works.',
      },
      id: null,
    },
    { status: 401, headers: { 'WWW-Authenticate': 'Bearer realm="composer-studio-mcp"' } },
  );
}

function textResult(payload: unknown) {
  return {
    content: [{ type: 'text' as const, text: JSON.stringify(payload, null, 2) }],
  };
}

/** Request-scoped server — one McpServer per POST, never shared state. */
function createServer(orgId: string): McpServer {
  const server = new McpServer({ name: 'composer-studio', version: '1.0.0' });

  server.registerTool(
    'search_assets',
    {
      description: MCP_TOOL_DESCRIPTORS[0].description,
      inputSchema: { query: z.string().min(1).describe('What to look for, e.g. "apple pictures".') },
    },
    async ({ query }) => textResult(await toolSearchAssets(query)),
  );

  server.registerTool(
    'compose_package',
    {
      description: MCP_TOOL_DESCRIPTORS[1].description,
      inputSchema: { brief: z.string().min(1).describe('The story brief — one line to a full draft.') },
    },
    async ({ brief }) => textResult(await toolComposePackage(brief, orgId)),
  );

  server.registerTool(
    'check_rights',
    {
      description: MCP_TOOL_DESCRIPTORS[2].description,
      inputSchema: { asset_id: z.string().min(1).describe('Asset id, e.g. "lib-apple-orchard-row".') },
    },
    async ({ asset_id }) => textResult(await toolCheckRights(asset_id)),
  );

  server.registerTool(
    'compose_newsletter',
    {
      description: MCP_TOOL_DESCRIPTORS[3].description,
      inputSchema: {
        edition: z
          .string()
          .min(1)
          .describe('The full newsletter edition — markdown headings, HR-separated, or Subject:-line structure.'),
      },
    },
    async ({ edition }) => textResult(await toolComposeNewsletter(edition, orgId)),
  );

  server.registerTool(
    'send_package',
    {
      description: MCP_TOOL_DESCRIPTORS[4].description,
      inputSchema: {
        package_id: z.string().min(1).describe('Package id returned by compose_package.'),
        destination: z.enum(['beehiiv', 'cms', 'download']),
      },
    },
    async ({ package_id, destination }) => textResult(await toolSendPackage(package_id, destination)),
  );

  return server;
}

export async function POST(req: Request) {
  const auth = await authenticate(req);
  if (!auth) return unauthorized();

  // Stateless (no session id) + JSON responses — one request in, one
  // response out, nothing held between calls. Request-scoped server.
  const server = createServer(auth.orgId);
  const transport = new WebStandardStreamableHTTPServerTransport({
    enableJsonResponse: true,
  });
  try {
    await server.connect(transport);
    return await transport.handleRequest(req);
  } finally {
    await transport.close().catch(() => {});
    await server.close().catch(() => {});
  }
}

/** Discovery: the tools/list-compatible descriptor, no auth required. */
export async function GET() {
  return Response.json({
    name: 'composer-studio',
    version: '1.0.0',
    transport: 'streamable-http',
    auth: 'Bearer <per-customer key from /api/settings/keys> (legacy COMPOSER_API_KEY fallback; any non-empty key in COMPOSER_MOCK=1)',
    tools: MCP_TOOL_DESCRIPTORS,
  });
}
