// The /newsletter batch workflow API (spec Part 5B, v1.5).
// POST { edition } → the edition package: story atoms, per-story asset
// packages (search + rights + derivatives), ONE hero recommendation.
// GET ?id= → a stored edition package (for deep links from /compose).

import { NextResponse } from 'next/server';
import { composeNewsletter } from '@/lib/engine/newsletter';
import { ensureSeedData, getEdition, listEditions } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';
import { isMockMode } from '@/lib/mock';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  let body: { edition?: string };
  try {
    body = (await req.json()) as { edition?: string };
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  const edition = (body.edition ?? '').trim();
  if (!edition) {
    return NextResponse.json({ error: 'Edition text is required.' }, { status: 400 });
  }

  const { orgId } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);

  // Mock mode: let the working state breathe (matches /api/compose).
  if (isMockMode()) {
    await new Promise((resolve) => setTimeout(resolve, 1200));
  }

  const pkg = await composeNewsletter(edition, orgId);
  return NextResponse.json(pkg);
}

export async function GET(req: Request) {
  const { orgId } = await getWorkspaceIdentity();
  const id = new URL(req.url).searchParams.get('id');
  if (id) {
    const edition = await getEdition(id);
    if (!edition || edition.orgId !== orgId) {
      return NextResponse.json({ error: `No edition with id "${id}" — not on file.` }, { status: 404 });
    }
    return NextResponse.json(edition);
  }
  // Listing: recent editions for the newsletter screen's history row.
  const editions = await listEditions(orgId);
  return NextResponse.json({
    editions: editions.slice(0, 10).map((e) => ({
      id: e.id,
      title: e.title,
      storyCount: e.storyCount,
      createdAt: e.createdAt,
      heroAssetId: e.hero?.assetId ?? null,
    })),
  });
}
