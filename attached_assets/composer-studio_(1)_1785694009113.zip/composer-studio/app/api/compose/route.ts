import { NextResponse } from 'next/server';
import { searchAllAssetSources } from '@/lib/engine/assets';
import { composePackage } from '@/lib/engine/compose';
import { composeNewsletter } from '@/lib/engine/newsletter';
import { classifyIntakeWithModel } from '@/lib/engine/router';
import { ensureSeedData } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';
import { isMockMode } from '@/lib/mock';
import type { ArchiveDepth, ComposeInput } from '@/lib/engine/types';

export const runtime = 'nodejs';

const VALID_DEPTHS: ArchiveDepth[] = ['shallow', 'standard', 'deep'];

export async function POST(req: Request) {
  let body: Partial<ComposeInput>;
  try {
    body = (await req.json()) as Partial<ComposeInput>;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  const brief = (body.brief ?? '').trim();
  if (!brief) {
    return NextResponse.json({ error: 'Brief is required.' }, { status: 400 });
  }

  const { orgId } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);

  // The intake router (spec Part 5B): the user never picks a mode.
  // Short asset-search intent → /assets quick-hit; edition-shaped input
  // → the newsletter batch workflow; story/brief → full compose. Real
  // mode classifies through the ModelAdapter seam with heuristic fallback.
  const classification = await classifyIntakeWithModel(brief);

  if (classification.route === 'assets') {
    const result = await searchAllAssetSources(classification.query ?? brief);
    return NextResponse.json({
      routed: 'asset-search',
      reason: classification.reason,
      ...result,
    });
  }

  if (classification.route === 'newsletter') {
    if (isMockMode()) {
      await new Promise((resolve) => setTimeout(resolve, 1200));
    }
    const edition = await composeNewsletter(brief, orgId);
    return NextResponse.json({
      routed: 'newsletter-batch',
      reason: classification.reason,
      id: edition.id,
      storyCount: edition.storyCount,
    });
  }

  const input: ComposeInput = {
    brief,
    platforms: Array.isArray(body.platforms) ? body.platforms.map(String) : ['Newsletter'],
    archiveDepth: VALID_DEPTHS.includes(body.archiveDepth as ArchiveDepth)
      ? (body.archiveDepth as ArchiveDepth)
      : 'standard',
  };

  // Mock mode: let the "on it —" ack state breathe; generation takes seconds.
  if (isMockMode()) {
    await new Promise((resolve) => setTimeout(resolve, 1400));
  }

  const pkg = await composePackage(input, orgId);
  return NextResponse.json({
    routed: 'full-package',
    reason: classification.reason,
    id: pkg.id,
    verdict: pkg.evaluation.verdict,
  });
}
