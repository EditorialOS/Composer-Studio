# HANDOFF — Composer Studio

## What's left is accounts, not code.

The codebase is feature-complete for v1.5: the newsletter batch workflow, all six real
adapters (env-gated, fetch-only, honest fallbacks), per-customer MCP keys, and the mock
mode that runs everything with zero keys. Nothing below is a code task — every step is
"create an account, copy a key, paste it into env." Each step says **exactly which env
var** and **how to verify the adapter flipped live**.

If you can copy-paste, you can do everything below.

---

## 0. The 60-second demo (no keys, no accounts)

```bash
npm install
COMPOSER_MOCK=1 npm run dev
```

Open http://localhost:3000. Everything works: auth is bypassed (you are "Demo Publication"),
and search/assets/archive/send/models are mock adapters with real-feeling fixtures —
including the newsletter batch workflow (`/newsletter`, try the demo edition).

**Replit:** import the repo → add one Secret `COMPOSER_MOCK=1` → Run command `npm run dev`. Done.

---

## The account checklist (in order)

### 1. Supabase project (store, MCP keys, embeddings)

1. supabase.com → **New project** → copy the database password you set.
2. Project → **SQL Editor** → paste the entire contents of
   `supabase/migrations/0001_composer_v15.sql` → **Run**. (Creates `composer_mcp_keys`,
   `asset_embeddings` + pgvector match RPC, audit/billing/waitlist tables.)
3. Project → **Settings → API** → copy:
   - `SUPABASE_URL` (Project URL)
   - `SUPABASE_SERVICE_ROLE_KEY` (`service_role` key — keep secret)
   - `SUPABASE_ANON_KEY` (`anon` key)
4. **Verify live:** `POST /api/settings/keys` (signed in, mock mode OFF) → returns a
   `csk_…` key once. Then `curl -X POST https://<host>/api/mcp -H "Authorization: Bearer csk_…"`
   with a `tools/list` JSON-RPC body → 200, not 401.

### 2. Clerk app (auth + organizations)

1. dashboard.clerk.com → **Create application** → enable **Organizations**.
2. **API Keys** → copy `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` and `CLERK_SECRET_KEY`.
3. **Verify live:** unset `COMPOSER_MOCK`, open the app → you get a real sign-in screen
   (not a 500). Sign up, create an org — workspace context at `/onboarding` now saves per-org.

### 3. Cloudinary (the built-in asset library)

1. cloudinary.com → **Dashboard** → copy `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`,
   `CLOUDINARY_API_SECRET`.
2. Upload a few images; tag them; add context metadata (`photographer`, `usage_rights`,
   `expiration` as an ISO date) — the rights model reads these fields.
3. **Verify live:** `POST /api/compose` with any brief → the package's Visual assets tab
   shows YOUR images with rights badges (not the demo fixtures). Library (`/library`) lists
   your assets. Without keys, the package honestly says "No assets matched this brief."

### 4. Semantic library search (optional, needs step 1 + an OpenAI key)

1. Set `OPENAI_API_KEY` (also powers the model adapter below).
2. Embeddings are written by the DAM upload/index path into `asset_embeddings`
   (table from step 1's migration).
3. **Verify live:** search for something your tags DON'T cover → matched assets carry the
   note "Semantic match — embedding similarity (pgvector), not tags." With tag hits, the
   note reads "Tag match."

### 5. Stripe (billing: Solo / Studio / Agency)

1. dashboard.stripe.com → **Developers → API keys** → `STRIPE_SECRET_KEY` +
   `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`.
2. **Products** → create three prices ($99 Solo / $299 Studio / $750 Agency, monthly) →
   copy the `price_…` IDs into `STRIPE_PRICE_SOLO_ID` / `STRIPE_PRICE_STUDIO_ID` /
   `STRIPE_PRICE_AGENCY_ID`.
3. **Webhooks** → add endpoint `https://<your-domain>/api/stripe/webhook` → copy the
   signing secret into `STRIPE_WEBHOOK_SECRET`.
4. **Verify live:** `/billing` → upgrade → Stripe Checkout opens with your prices; the
   webhook flips the org's billing row in Supabase.

### 6. beehiiv (Send → draft posts)

1. app.beehiiv.com → **Settings → API** → copy `BEEHIIV_API_KEY` and your
   `BEEHIIV_PUBLICATION_ID` (`pub_…`).
2. **Verify live:** compose a package → `/send` → beehiiv → the response names the draft
   id/URL and the draft appears in beehiiv. Without keys the Send tab honestly says
   "beehiiv not configured" and CMS/download paths still work.

### 7. Search provider (market context + angle assessment)

Pick ONE — first configured key wins, or pin with `SEARCH_PROVIDER`
(`tavily` | `brave` | `perplexity`):

- **Tavily:** tavily.com → API keys → `TAVILY_API_KEY`
- **Brave:** brave.com/search/api → `BRAVE_API_KEY`
- **Perplexity Sonar:** perplexity.ai → API settings → `PERPLEXITY_API_KEY`

**Verify live:** compose a package → the Market context tab shows live facts with real
source URLs (not example.com). Without a key the package notes "No search provider
configured — market context skipped."

### 8. Model key (the full Editorial Director)

Pick ONE (Anthropic preferred; `MODEL_PROVIDER` pins either):

- **Anthropic:** console.anthropic.com → `ANTHROPIC_API_KEY` (default model claude-sonnet;
  override with `ANTHROPIC_MODEL`)
- **OpenAI-compatible:** platform.openai.com → `OPENAI_API_KEY` (+ optional
  `OPENAI_BASE_URL` — covers Kimi, Groq, any compatible endpoint; `OPENAI_MODEL` to name it)

Powers: five-gate evaluation (strict JSON, temperature 0), intake-router classification,
newsletter atomization, and market-context synthesis.
**Verify live:** compose a package → the gate evaluation's editor note names the provider
(e.g. "by anthropic/claude-sonnet-4-5"). Without a key it honestly says the heuristic ran.

### 9. Google Drive archive (optional)

- Simple: Google Cloud Console → enable **Drive API** → create an API key →
  `GOOGLE_DRIVE_API_KEY`.
- Or: create a service account, share your archive Drive folder with its email, and paste
  the whole JSON key blob into `GOOGLE_SERVICE_ACCOUNT_JSON`.

**Verify live:** compose a brief that matches files in the Drive → the Archive tab lists
findings with links and modified dates. Without config it says "No archive configured."

### 10. Deploy to Vercel (5 minutes)

1. Push the repo to GitHub → vercel.com → **Add New → Project** → import. Framework:
   **Next.js** (auto-detected).
2. **Environment Variables:** paste everything from `.env.example` that you filled in —
   or just `COMPOSER_MOCK=1` for a live demo deploy.
3. Deploy. `/marketing` is public; the app is behind Clerk (or open in mock mode).
4. Back in Clerk: add your Vercel domain to allowed origins. Back in Stripe: point the
   webhook at the production domain (step 5).

### 11. Flip the adapters one at a time

Unset `COMPOSER_MOCK` LAST. The intended order is the checklist order: each adapter
activates the moment its env vars exist and reports "not configured" (never crashes) until
then. After each step, run that step's "verify live" line. The workspace screen
(`/onboarding`) shows the live capability probe for all six adapters at a glance.

---

## Environment variables

Copy `.env.example` to `.env.local` and fill in what you're connecting. **Everything is
optional except removing `COMPOSER_MOCK` when you go live.** The full annotated table is
in `.env.example`, grouped by adapter.

**MCP endpoint:** the engine is agent-callable at `POST /api/mcp` (Streamable HTTP). Tools:
`search_assets`, `compose_package`, `check_rights`, `compose_newsletter`, `send_package`.
Auth is `Authorization: Bearer <key>` — per-customer keys minted at `/api/settings/keys`
(SHA-256 hashed in `composer_mcp_keys`), legacy shared `COMPOSER_API_KEY` as fallback, any
non-empty key in mock mode.

## Verify before selling

```bash
npx tsc --noEmit   # 0 errors
npm run build      # succeeds
```

Then click through: compose a brief → package renders all tabs → paste the demo edition at
`/newsletter` → 3 story sections + hero card → library badges → send creates a draft →
memory logs the run → workspace context edits change the gate evaluation on the next compose.
