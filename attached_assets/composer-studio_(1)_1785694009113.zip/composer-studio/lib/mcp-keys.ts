// Per-customer MCP keys (v1.5). The single shared COMPOSER_API_KEY is
// replaced by a keys model: composer_mcp_keys rows keyed by SHA-256
// hash of the presented bearer token, each mapped to an org.
//
// Resolution order:
//   1. Mock mode → any non-empty key resolves the demo org.
//   2. Supabase configured → hash the presented key, look up an active
//      (non-revoked) composer_mcp_keys row, return its org_id.
//   3. Fallback → the legacy shared COMPOSER_API_KEY (org pinning via
//      COMPOSER_MCP_ORG_ID) so existing deployments keep working.
//   4. Nothing matched → null → the MCP route returns 401.
//
// Keys are stored as hashes only — the plaintext key is shown once at
// mint time (app/api/settings/keys) and never persisted.

import { createHash, randomBytes } from 'node:crypto';
import { isMockMode, MOCK_WORKSPACE } from './mock';
import { getSupabaseAdmin } from './supabase';

export interface McpKeyRow {
  id: string;
  org_id: string;
  label: string;
  created_at: string;
  revoked_at: string | null;
}

export function hashMcpKey(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export function supabaseConfigured(): boolean {
  return Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);
}

/** Resolve a presented bearer token to an org, or null (→ 401). */
export async function resolveMcpKey(token: string): Promise<{ orgId: string; label?: string } | null> {
  if (!token) return null;
  if (isMockMode()) {
    return { orgId: MOCK_WORKSPACE.orgId, label: 'demo (mock mode accepts any non-empty key)' };
  }

  if (supabaseConfigured()) {
    try {
      // Table types aren't generated — cast like the DAM routes do.
      const supabase = getSupabaseAdmin() as any;
      const { data, error } = await supabase
        .from('composer_mcp_keys')
        .select('id, org_id, label, created_at, revoked_at')
        .eq('key_hash', hashMcpKey(token))
        .is('revoked_at', null)
        .limit(1)
        .maybeSingle();
      if (!error && data) {
        return { orgId: (data as McpKeyRow).org_id, label: (data as McpKeyRow).label };
      }
    } catch {
      // fall through to the legacy shared key — never lock agents out
      // because the key store had a bad moment; note via the fallback.
    }
  }

  const expected = process.env.COMPOSER_API_KEY;
  if (expected && token === expected) {
    return { orgId: process.env.COMPOSER_MCP_ORG_ID ?? 'mcp-customer', label: 'shared COMPOSER_API_KEY' };
  }
  return null;
}

/** Mint a new key for an org. Returns the plaintext ONCE. */
export async function mintMcpKey(
  orgId: string,
  label: string,
): Promise<{ key: string; row: McpKeyRow }> {
  const key = `csk_${randomBytes(24).toString('hex')}`;
  const supabase = getSupabaseAdmin() as any;
  const { data, error } = await supabase
    .from('composer_mcp_keys')
    .insert({ key_hash: hashMcpKey(key), org_id: orgId, label })
    .select('id, org_id, label, created_at, revoked_at')
    .single();
  if (error) throw new Error(`Failed to store MCP key: ${error.message}`);
  return { key, row: data as McpKeyRow };
}

export async function listMcpKeys(orgId: string): Promise<McpKeyRow[]> {
  const supabase = getSupabaseAdmin() as any;
  const { data, error } = await supabase
    .from('composer_mcp_keys')
    .select('id, org_id, label, created_at, revoked_at')
    .eq('org_id', orgId)
    .order('created_at', { ascending: false });
  if (error) throw new Error(`Failed to list MCP keys: ${error.message}`);
  return (data ?? []) as McpKeyRow[];
}

export async function revokeMcpKey(orgId: string, id: string): Promise<boolean> {
  const supabase = getSupabaseAdmin() as any;
  const { error } = await supabase
    .from('composer_mcp_keys')
    .update({ revoked_at: new Date().toISOString() })
    .eq('id', id)
    .eq('org_id', orgId);
  return !error;
}
