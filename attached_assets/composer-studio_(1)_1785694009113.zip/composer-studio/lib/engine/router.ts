// The intake router (spec Part 5B — the command grammar).
// One input box. The brief classifies itself; the user never picks a
// mode. Three routes, one engine:
//   assets     → /assets quick-hit (AssetAdapter fan-out only — no
//                archive, no market context)
//   compose    → the full /compose loop (brief → package)
//   newsletter → the /newsletter batch workflow (edition → story atoms
//                → per-story asset packages + one hero recommendation)
//
// Mock mode uses the keyword/length/structure heuristic below. Real
// mode can route classification through the ModelAdapter seam
// (classifyIntakeWithModel) — an LLM call with the same table as the
// schema, falling back to this heuristic when no model provider is
// configured. The classification table grows by rows, not rebuilds —
// add intent patterns here.

import { isMockMode } from '../mock';
import type { IntakeClassification } from './types';

// Short asset-search intent: a find-verb near a media-noun, or a bare
// "photos of X" phrasing. Keep rows additive — config, not code paths.
const ASSET_INTENT_PATTERNS: RegExp[] = [
  /\b(search|find|get|show|look\s?up|pull|grab|fetch)\b[^.!?\n]*\b(photo|photos|picture|pictures|image|images|pic|pics|asset|assets|graphic|graphics|shot|shots)\b/i,
  /\b(photos|pictures|images|pics|shots)\s+(of|for)\b/i,
];

// Longer than this (or multi-sentence) reads as a story/brief, not a
// quick asset lookup — route to the full compose loop.
const MAX_QUICK_HIT_CHARS = 160;
const MAX_QUICK_HIT_WORDS = 25;

// Edition-shaped input (spec Part 5B, v1.5): an explicit "/run
// newsletter" prefix, multiple markdown/Subject headings, or a paste
// long enough to be a full multi-story edition.
const NEWSLETTER_PREFIX = /^\s*\/run\s+newsletter\b/i;
const HEADING_LINE = /^(?:#{1,3}\s+\S|(?:subject|story|headline)\s*:\s*\S)/gim;
const MIN_EDITION_WORDS = 800;

const LEADING_FILLER =
  /^\s*(?:please\s+)?(?:can you\s+|could you\s+)?(?:search|find|get|show|look\s?up|pull|grab|fetch)\s+(?:for\s+|me\s+|up\s+)*/i;

/** Strip the find-verb framing so "search for apple pictures" → "apple pictures". */
export function extractAssetQuery(text: string): string {
  const cleaned = text.trim().replace(LEADING_FILLER, '').replace(/[.!?\s]+$/, '');
  return cleaned || text.trim();
}

export function classifyIntake(text: string): IntakeClassification {
  const trimmed = text.trim();
  const wordCount = trimmed.split(/\s+/).filter(Boolean).length;

  // Edition-shaped input routes to the newsletter batch workflow.
  if (NEWSLETTER_PREFIX.test(trimmed)) {
    return {
      route: 'newsletter',
      reason:
        'Routed: newsletter batch — explicit "/run newsletter" prefix. Decomposing the edition into story atoms.',
    };
  }
  const headingCount = (trimmed.match(HEADING_LINE) ?? []).length;
  if (headingCount >= 2) {
    return {
      route: 'newsletter',
      reason: `Routed: newsletter batch — edition-shaped input (${headingCount} story headings detected).`,
    };
  }
  if (wordCount >= MIN_EDITION_WORDS) {
    return {
      route: 'newsletter',
      reason: `Routed: newsletter batch — ${wordCount} words reads as a full edition, not a single brief.`,
    };
  }

  const shortEnough =
    trimmed.length <= MAX_QUICK_HIT_CHARS && wordCount <= MAX_QUICK_HIT_WORDS;
  const assetIntent = ASSET_INTENT_PATTERNS.some((pattern) => pattern.test(trimmed));

  if (assetIntent && shortEnough) {
    const query = extractAssetQuery(trimmed);
    return {
      route: 'assets',
      query,
      reason: `Routed: asset search — short find-intent detected ("${query}"). No archive, no market context.`,
    };
  }

  if (assetIntent) {
    return {
      route: 'compose',
      reason:
        'Routed: full package — mentions assets but reads as a story/brief (too long for a quick-hit).',
    };
  }

  return {
    route: 'compose',
    reason: 'Routed: full package — narrative brief, running the full compose loop.',
  };
}

/**
 * ModelAdapter-seam classification (real mode, model key configured):
 * one strict-JSON LLM call, temperature 0, validated against the route
 * table. Any error or missing key falls back to the heuristic above —
 * never a crash, and the returned reason says which path ran.
 */
export async function classifyIntakeWithModel(text: string): Promise<IntakeClassification> {
  if (isMockMode()) return classifyIntake(text);
  try {
    const { chatJson, modelConfigured } = await import('./adapters/real/llm');
    if (!modelConfigured()) return classifyIntake(text);
    const result = await chatJson<{ route?: unknown; query?: unknown; reason?: unknown }>({
      system:
        'You classify one input into exactly one route for an editorial packaging engine. ' +
        'Routes: "assets" (short asset-search intent, e.g. "search for apple pictures"), ' +
        '"compose" (a story brief — one line to a full draft of a single story), ' +
        '"newsletter" (a full multi-story newsletter edition, or an explicit "/run newsletter" request). ' +
        'Respond with STRICT JSON only: {"route": "assets"|"compose"|"newsletter", "query": string|null, "reason": string}. ' +
        '"query" is the cleaned asset search string, only for route "assets".',
      user: text.slice(0, 6000),
    });
    if (result && (result.route === 'assets' || result.route === 'compose' || result.route === 'newsletter')) {
      const route = result.route;
      return {
        route,
        query:
          route === 'assets' && typeof result.query === 'string' && result.query
            ? result.query
            : route === 'assets'
              ? extractAssetQuery(text.trim())
              : undefined,
        reason:
          typeof result.reason === 'string' && result.reason
            ? `Routed (model): ${result.reason}`
            : `Routed (model): ${route}.`,
      };
    }
    return classifyIntake(text);
  } catch {
    return classifyIntake(text);
  }
}
