// Real ArchiveAdapter — Google Drive (spec Part 5: archives ride the
// seam). Config: GOOGLE_DRIVE_API_KEY (API-key auth) or
// GOOGLE_SERVICE_ACCOUNT_JSON (service-account JSON → OAuth2 JWT
// bearer, signed with node:crypto — no SDK). Searches Drive files by
// name/fullText query and returns findings with links + modifiedTime.
// Missing config → the existing "No archive configured" honest state.

import { createSign } from 'node:crypto';
import type { ArchiveAdapter, ArchiveDepth, ArchiveFinding, ArchiveResult, ParsedBrief } from '../../types';

function driveConfigured() {
  return Boolean(process.env.GOOGLE_DRIVE_API_KEY || process.env.GOOGLE_SERVICE_ACCOUNT_JSON);
}

// ── Auth ─────────────────────────────────────────────────────

function base64url(input: string | Buffer) {
  return Buffer.from(input).toString('base64url');
}

/** Service-account JWT → OAuth2 access token (RS256, node:crypto only). */
async function serviceAccountToken(): Promise<string | null> {
  const raw = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  if (!raw) return null;
  try {
    const sa = JSON.parse(raw) as { client_email?: string; private_key?: string };
    if (!sa.client_email || !sa.private_key) return null;
    const now = Math.floor(Date.now() / 1000);
    const header = base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
    const claims = base64url(
      JSON.stringify({
        iss: sa.client_email,
        scope: 'https://www.googleapis.com/auth/drive.readonly',
        aud: 'https://oauth2.googleapis.com/token',
        iat: now,
        exp: now + 3600,
      }),
    );
    const signer = createSign('RSA-SHA256');
    signer.update(`${header}.${claims}`);
    const jwt = `${header}.${claims}.${signer.sign(sa.private_key, 'base64url')}`;
    const res = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        assertion: jwt,
      }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { access_token?: string };
    return data.access_token ?? null;
  } catch {
    return null;
  }
}

// ── Drive search ─────────────────────────────────────────────

interface DriveFile {
  id?: string;
  name?: string;
  mimeType?: string;
  modifiedTime?: string;
  webViewLink?: string;
  description?: string;
}

async function driveSearch(
  query: string,
  depth: ArchiveDepth,
): Promise<{ files: DriveFile[] } | null> {
  const apiKey = process.env.GOOGLE_DRIVE_API_KEY;
  const token = apiKey ? null : await serviceAccountToken();
  if (!apiKey && !token) return null;

  const escaped = query.replace(/['\\]/g, ' ').slice(0, 120);
  // Shallow = filenames only; standard/deep add fullText (file content).
  const q =
    depth === 'shallow'
      ? `name contains '${escaped}' and trashed = false`
      : `(name contains '${escaped}' or fullText contains '${escaped}') and trashed = false`;
  const url =
    'https://www.googleapis.com/drive/v3/files' +
    `?q=${encodeURIComponent(q)}` +
    '&fields=files(id,name,mimeType,modifiedTime,webViewLink,description)' +
    `&pageSize=${depth === 'deep' ? 20 : 10}` +
    (apiKey ? `&key=${encodeURIComponent(apiKey)}` : '');

  const res = await fetch(url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!res.ok) return null;
  const data = (await res.json()) as { files?: DriveFile[] };
  return { files: data.files ?? [] };
}

// ── The adapter ──────────────────────────────────────────────

export class RealArchiveAdapter implements ArchiveAdapter {
  name = 'google-drive';

  async capabilities() {
    return { connected: driveConfigured(), deepSearch: driveConfigured() };
  }

  async searchArchive(parsed: ParsedBrief, depth: ArchiveDepth): Promise<ArchiveResult> {
    if (!driveConfigured()) {
      return {
        connected: false,
        adapterName: 'none',
        findings: [],
        metrics: [],
        note: 'No archive configured — set GOOGLE_DRIVE_API_KEY or GOOGLE_SERVICE_ACCOUNT_JSON (or connect Sanity/Contentful/WordPress). The package ships; the gap is named.',
      };
    }

    const query = [parsed.headline, ...parsed.searchTags.slice(0, 3)].join(' ');
    let result: { files: DriveFile[] } | null = null;
    try {
      result = await driveSearch(query, depth);
    } catch {
      result = null;
    }
    if (!result) {
      return {
        connected: false,
        adapterName: this.name,
        findings: [],
        metrics: [],
        note: 'Google Drive archive configured but the search failed (auth or API error) — gap noted, package ships.',
      };
    }

    const findings: ArchiveFinding[] = result.files.map((f) => ({
      title: f.name ?? 'Untitled Drive file',
      excerpt: f.description
        ? f.description.slice(0, 200)
        : `Drive file match (${f.mimeType ?? 'unknown type'}) — open to review prior coverage.`,
      date: f.modifiedTime,
      source: f.webViewLink ?? `https://drive.google.com/file/d/${f.id}/view`,
    }));

    return {
      connected: true,
      adapterName: this.name,
      findings,
      metrics: [
        { label: 'Drive files matched', value: String(findings.length), sub: depth === 'shallow' ? 'filename search' : 'name + fullText' },
      ],
      note:
        findings.length === 0
          ? 'Drive searched — no prior coverage matched this brief.'
          : depth === 'deep'
            ? 'Deep archive sweep: fullText + filename matches included.'
            : undefined,
    };
  }
}
