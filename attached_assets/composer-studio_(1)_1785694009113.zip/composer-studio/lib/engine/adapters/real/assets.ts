// Real AssetAdapter — Cloudinary (built-in library or BYO Cloudinary).
// Admin API search by tags + context/metadata fields; the rights model
// reads photographer / usage_rights / expiration from embedded context
// metadata. Derivative URLs come from the existing derivatives.ts.
//
// Semantic fallback (lib/embeddings.ts): when OPENAI_API_KEY and
// Supabase are configured and tag search comes back thin, the query is
// embedded and matched against stored asset embeddings (pgvector,
// match_asset_embeddings RPC). The search method used is noted on
// every matched asset ("Tag match" vs "Semantic match") and in
// capabilities — never silently.

import { v2 as cloudinary } from 'cloudinary';
import type { AssetAdapter, MatchedAsset, ParsedBrief, RightsStatus } from '../../types';
import { withDerivatives } from '../../derivatives';

function cloudinaryConfigured() {
  return Boolean(
    process.env.CLOUDINARY_CLOUD_NAME &&
      process.env.CLOUDINARY_API_KEY &&
      process.env.CLOUDINARY_API_SECRET,
  );
}

function semanticConfigured() {
  return Boolean(process.env.OPENAI_API_KEY && process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);
}

/** Below this many tag hits, the semantic fallback kicks in. */
const THIN_TAG_RESULTS = 3;

// ── Rights mapping: Cloudinary context metadata → rights model ──
// context.photographer          → photographer credit
// context.usage_rights          → rights label ("Perpetual", "Editorial use · expires …")
// context.expiration (ISO date) → expiry tracking: past → check,
//                                 < 30 days → expiring, else cleared

const EXPIRING_WINDOW_MS = 30 * 24 * 60 * 60 * 1000;

function mapRights(context: Record<string, string>): {
  photographer?: string;
  campaign?: string;
  rightsLabel?: string;
  rightsStatus: RightsStatus;
  rightsExpiresAt?: string;
  rightsNote?: string;
} {
  const photographer = context.photographer;
  const campaign = context.campaign;
  const rightsLabel = context.usage_rights;
  const expirationRaw = context.expiration ?? context.usage_rights_expiration;

  let rightsExpiresAt: string | undefined;
  let expirationMs: number | null = null;
  if (expirationRaw) {
    const parsed = Date.parse(expirationRaw);
    if (!Number.isNaN(parsed)) {
      expirationMs = parsed;
      rightsExpiresAt = new Date(parsed).toISOString();
    }
  }

  let rightsStatus: RightsStatus;
  let rightsNote: string | undefined;
  if (expirationMs !== null && expirationMs < Date.now()) {
    rightsStatus = 'check';
    rightsNote = 'Usage rights EXPIRED — do not publish until re-cleared.';
  } else if (
    (expirationMs !== null && expirationMs - Date.now() < EXPIRING_WINDOW_MS) ||
    (rightsLabel ? /expir/i.test(rightsLabel) : false)
  ) {
    rightsStatus = 'expiring';
    rightsNote = 'Usage rights expire — flagged automatically from metadata.';
  } else if (rightsLabel) {
    rightsStatus = 'cleared';
  } else if (photographer) {
    rightsStatus = 'check';
    rightsNote = 'Photographer on file but no usage-rights label — confirm terms before publish.';
  } else {
    rightsStatus = 'unknown';
    rightsNote = 'No rights metadata embedded — not on file.';
  }

  return { photographer, campaign, rightsLabel, rightsStatus, rightsExpiresAt, rightsNote };
}

function mapCloudinaryResource(r: any, matchNote?: string): MatchedAsset {
  const context = (r.context?.custom ?? r.context ?? {}) as Record<string, string>;
  return withDerivatives({
    id: r.public_id,
    url: r.secure_url,
    thumbnailUrl: r.secure_url,
    width: r.width ?? 0,
    height: r.height ?? 0,
    format: r.format ?? 'jpg',
    bytes: r.bytes ?? 0,
    tags: r.tags ?? [],
    matchNote,
    ...mapRights(context),
    derivatives: [],
  });
}

// ── Semantic fallback (pgvector over stored embeddings) ──────

async function semanticSearch(parsed: ParsedBrief): Promise<MatchedAsset[] | null> {
  if (!semanticConfigured()) return null;
  try {
    const { createEmbeddings } = await import('../../../embeddings');
    const { getSupabaseAdmin } = await import('../../../supabase');
    const query = [parsed.headline, ...parsed.searchTags].join(' ');
    const [embedding] = await createEmbeddings([query]);
    if (!embedding) return null;
    const supabase = getSupabaseAdmin();
    const rpcArgs: Record<string, unknown> = {
      query_embedding: embedding,
      match_count: 8,
    };
    // The RPC takes an org scope when multi-tenant embeddings exist;
    // omit it for single-workspace libraries.
    if (process.env.COMPOSER_SEMANTIC_ORG_ID) {
      rpcArgs.org_id = process.env.COMPOSER_SEMANTIC_ORG_ID;
    }
    const { data, error } = await (supabase as any).rpc('match_asset_embeddings', rpcArgs);
    if (error || !Array.isArray(data) || data.length === 0) return null;
    const publicIds = (data as Array<{ public_id?: string }>)
      .map((row) => row.public_id)
      .filter((id): id is string => Boolean(id));
    if (publicIds.length === 0) return null;

    // Fetch the matched resources so rights metadata comes along.
    const expression = publicIds.map((id) => `public_id:${id}`).join(' OR ');
    const result = await cloudinary.search
      .expression(expression)
      .with_field('context')
      .with_field('tags')
      .max_results(publicIds.length)
      .execute();
    const byId = new Map(
      (result.resources ?? []).map((r: any) => [r.public_id, r] as const),
    );
    return publicIds
      .map((id) => byId.get(id))
      .filter(Boolean)
      .map((r: any) =>
        mapCloudinaryResource(r, 'Semantic match — embedding similarity (pgvector), not tags.'),
      );
  } catch {
    return null;
  }
}

// ── The adapter ──────────────────────────────────────────────

export class RealAssetAdapter implements AssetAdapter {
  name = 'cloudinary';

  async capabilities() {
    const configured = cloudinaryConfigured();
    return {
      tagSearch: configured,
      // Visual search requires per-asset indexing; not probed live — reported off.
      visualSearch: false,
      derivatives: configured,
      rightsMetadata: configured,
    };
  }

  private configure() {
    cloudinary.config({
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET,
      secure: true,
    });
  }

  async searchAssets(parsed: ParsedBrief): Promise<MatchedAsset[]> {
    if (!cloudinaryConfigured()) return [];
    this.configure();
    const expression =
      parsed.searchTags.length > 0
        ? parsed.searchTags.map((t) => `tags:${t}`).join(' OR ')
        : 'resource_type:image';
    try {
      const result = await cloudinary.search
        .expression(expression)
        .with_field('context')
        .with_field('tags')
        .max_results(12)
        .execute();
      const tagHits = (result.resources ?? []).map((r: any) =>
        mapCloudinaryResource(r, 'Tag match — Cloudinary Admin API tag search.'),
      );
      if (tagHits.length >= THIN_TAG_RESULTS) return tagHits;

      // Thin tag results → semantic fallback (embeddings + pgvector).
      const semanticHits = await semanticSearch(parsed);
      if (semanticHits && semanticHits.length > 0) {
        const seen = new Set(tagHits.map((a: MatchedAsset) => a.id));
        return [...tagHits, ...semanticHits.filter((a: MatchedAsset) => !seen.has(a.id))];
      }
      return tagHits;
    } catch {
      // Cloudinary Admin API error → honest empty (the compose loop
      // notes "No assets matched" — never a crash).
      return [];
    }
  }

  async listAssets(): Promise<MatchedAsset[]> {
    if (!cloudinaryConfigured()) return [];
    this.configure();
    try {
      const result = await cloudinary.search
        .expression('resource_type:image')
        .with_field('context')
        .with_field('tags')
        .max_results(50)
        .execute();
      return (result.resources ?? []).map((r: any) => mapCloudinaryResource(r));
    } catch {
      return [];
    }
  }

  buildDerivatives(asset: MatchedAsset) {
    return withDerivatives(asset).derivatives;
  }
}
