// Real adapters — one file per capability, all behind the same seam.
// Every adapter reads env config, reports capabilities honestly, and
// degrades to "not configured" (never an exception) when env is
// missing — the compose loop notes the gap in the package.
//
//   llm.ts      Anthropic / OpenAI-compatible chat helper (fetch-only)
//   search.ts   Tavily / Brave / Perplexity Sonar (hot-swappable)
//   assets.ts   Cloudinary Admin API + pgvector semantic fallback
//   archive.ts  Google Drive (API key or service account)
//   send.ts     beehiiv drafts / CMS / download
//   model.ts    the Editorial Director (LLM gate eval + heuristic fallback)

import type { MatchedAsset, RightsAdapter } from '../../types';

export { RealArchiveAdapter } from './archive';
export { RealAssetAdapter } from './assets';
export { RealModelAdapter } from './model';
export { RealSearchAdapter } from './search';
export { RealSendAdapter } from './send';

// ── Rights (reads embedded metadata already on assets) ───────

export class RealRightsAdapter implements RightsAdapter {
  name = 'embedded-xmp';

  async capabilities() {
    return { embeddedMetadata: true, expiryTracking: true };
  }

  async enrichRights(assets: MatchedAsset[]): Promise<MatchedAsset[]> {
    return assets.map((asset) =>
      asset.rightsStatus === 'unknown' && !asset.rightsNote
        ? { ...asset, rightsNote: 'No rights metadata embedded — not on file.' }
        : asset,
    );
  }
}
