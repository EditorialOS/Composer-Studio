// Real ModelAdapter — the Editorial Director. Anthropic (messages API,
// default claude-sonnet) or any OpenAI-compatible endpoint (OPENAI_API_KEY
// + optional OPENAI_BASE_URL — covers Kimi, Groq) behind the existing
// ModelAdapter interface, fetch-only. Gate evaluation uses a strict
// 5-gate JSON schema at temperature 0; any API error or missing key
// falls back to the deterministic heuristic, and the fallback is logged
// honestly in the evaluation's editorNote (it lands in provenance).

import {
  GATE_NAMES,
  type ComposeInput,
  type GateEvaluation,
  type GateName,
  type GateResult,
  type GateStatus,
  type ModelAdapter,
  type ParsedBrief,
  type WorkspaceContextData,
} from '../../types';
import { keywords, MockModelAdapter } from '../mock';
import { chatJson, modelConfigured, modelProviderLabel } from './llm';

const STATUSES: GateStatus[] = ['pass', 'warn', 'fail'];

interface LlmGateEval {
  gates?: Array<{ gate?: unknown; status?: unknown; note?: unknown }>;
  verdict?: unknown;
  verdict_summary?: unknown;
  required_revisions?: unknown;
}

/** Validate + normalize the model's 5-gate JSON into a GateEvaluation. */
function parseGateEval(raw: LlmGateEval | null): GateEvaluation | null {
  if (!raw || !Array.isArray(raw.gates) || raw.gates.length === 0) return null;
  const gates: GateResult[] = [];
  for (const name of GATE_NAMES) {
    const found = raw.gates.find(
      (g) => typeof g?.gate === 'string' && g.gate.toLowerCase() === name.toLowerCase(),
    );
    if (!found) return null; // strict: all five gates required
    const status = STATUSES.includes(found.status as GateStatus)
      ? (found.status as GateStatus)
      : 'warn';
    gates.push({
      gate: name as GateName,
      status,
      note: typeof found.note === 'string' && found.note ? found.note : 'No note returned.',
    });
  }
  const verdict = raw.verdict === 'APPROVED' ? 'APPROVED' : 'REVISE';
  return {
    gates,
    verdict,
    verdictSummary:
      typeof raw.verdict_summary === 'string' && raw.verdict_summary
        ? raw.verdict_summary
        : verdict === 'APPROVED'
          ? 'All five gates pass against current workspace context.'
          : 'One or more gates need attention — see required revisions.',
    requiredRevisions: Array.isArray(raw.required_revisions)
      ? raw.required_revisions.filter((r): r is string => typeof r === 'string')
      : [],
    editorNote: `Editorial Director evaluation by ${modelProviderLabel()} (strict JSON, temperature 0).`,
  };
}

export class RealModelAdapter extends MockModelAdapter implements ModelAdapter {
  name = 'editorial-director';

  async capabilities() {
    const provider = modelConfigured();
    return {
      gateEval: true,
      provider: provider ? modelProviderLabel() : 'heuristic',
    };
  }

  // parseBrief stays deterministic (never the mock fixtures): first
  // line = headline, keywords = search tags. The classification seam
  // (router) and atomization seam (newsletter) carry the LLM paths.
  async parseBrief(input: ComposeInput): Promise<ParsedBrief> {
    const firstLine =
      input.brief.split(/[.\n]/).map((s) => s.trim()).filter(Boolean)[0] ?? 'Untitled brief';
    return {
      headline: firstLine.length > 90 ? `${firstLine.slice(0, 87)}…` : firstLine,
      subhead: `${input.platforms.length || 1} platform${(input.platforms.length || 1) > 1 ? 's' : ''} · ${input.archiveDepth} archive depth`,
      kind: 'general',
      searchTags: keywords(input.brief),
      scenario: 'general',
    };
  }

  async evaluateGates(args: {
    parsed: ParsedBrief;
    workspace: WorkspaceContextData;
  }): Promise<GateEvaluation> {
    if (modelConfigured()) {
      const raw = await chatJson<LlmGateEval>({
        system:
          'You are the Editorial Director of a publication. Evaluate the story brief against five gates, ' +
          `in this exact order: ${GATE_NAMES.join(', ')}. ` +
          'Respond with STRICT JSON only: {"gates": [{"gate": string, "status": "pass"|"warn"|"fail", "note": string}], ' +
          '"verdict": "APPROVED"|"REVISE", "verdict_summary": string, "required_revisions": [string]}. ' +
          'Gate names must match exactly. Be a hard editor: warn/fail when the brief does not clearly advance an active theme, ' +
          'overlaps recent coverage, or clashes with the calendar. Verdict REVISE unless every gate passes.',
        user:
          `Brief headline: ${args.parsed.headline}\n` +
          `Brief subhead: ${args.parsed.subhead}\n` +
          `Search tags: ${args.parsed.searchTags.join(', ')}\n\n` +
          `Workspace context:\n` +
          `- Active themes: ${args.workspace.activeThemes.join('; ') || '(none)'}\n` +
          `- Recent coverage: ${args.workspace.recentCoverage.join('; ') || '(none)'}\n` +
          `- Voice notes: ${args.workspace.voiceNotes || '(none)'}\n` +
          `- Calendar: ${args.workspace.calendar.join('; ') || '(none)'}`,
        maxTokens: 1500,
      });
      const evaluation = parseGateEval(raw);
      if (evaluation) return evaluation;
      // Fall through to heuristic — noted honestly below.
    }
    const fallback = await super.evaluateGates({
      ...args,
      parsed: { ...args.parsed, scenario: 'general' },
    });
    fallback.editorNote = modelConfigured()
      ? `LLM gate evaluation failed or returned invalid JSON — heuristic fallback used (gap noted honestly). ${fallback.editorNote ?? ''}`.trim()
      : fallback.editorNote;
    return fallback;
  }
}
