// Real SendAdapter — beehiiv draft posts (REST API v2), CMS drafts,
// and the download bundle. Missing beehiiv keys → the honest
// "beehiiv not configured" note (the mock behavior is the fallback);
// API errors → skipped with the status, never a crash.

import type {
  ComposerPackage,
  SendAdapter,
  SendDestination,
  SendRecord,
} from '../../types';

function beehiivConfigured() {
  return Boolean(process.env.BEEHIIV_API_KEY && process.env.BEEHIIV_PUBLICATION_ID);
}

/** The assembled package content as the draft body (deliverables + asset sheet). */
function packageBodyHtml(pkg: ComposerPackage): string {
  const deliverables = pkg.deliverables
    .map((d) => `<h3>${d.title}</h3><p>${d.detail}</p>`)
    .join('');
  const assets =
    pkg.assets.length > 0
      ? `<h3>Asset sheet</h3><ul>${pkg.assets
          .map(
            (a) =>
              `<li>${a.id}${a.photographer ? ` — ${a.photographer}` : ''} · rights: ${
                a.rightsLabel ?? a.rightsStatus.toUpperCase()
              } · <a href="${a.url}">source</a></li>`,
          )
          .join('')}</ul>`
      : '';
  const facts =
    pkg.market.facts.length > 0
      ? `<h3>Sources</h3><ul>${pkg.market.facts
          .map((f) => `<li><a href="${f.sourceUrl}">${f.sourceName ?? f.sourceUrl}</a></li>`)
          .join('')}</ul>`
      : '';
  return `${deliverables}${assets}${facts}`;
}

interface BeehiivPostResponse {
  data?: { id?: string | number; web_url?: string };
}

export class RealSendAdapter implements SendAdapter {
  name = 'send';

  async capabilities() {
    return {
      beehiivDraft: beehiivConfigured(),
      cmsDraft: false,
      downloadAll: true,
    };
  }

  async send(
    pkg: ComposerPackage,
    destination: SendDestination,
  ): Promise<Omit<SendRecord, 'id' | 'packageId' | 'createdAt'>> {
    if (destination === 'download') {
      return {
        destination,
        status: 'download-ready',
        url: `/package/${pkg.id}#download`,
        note: 'Deliverables + derivative URLs bundled for download.',
      };
    }

    if (destination === 'beehiiv') {
      if (!beehiivConfigured()) {
        return {
          destination,
          status: 'skipped',
          note: 'beehiiv not configured — set BEEHIIV_API_KEY and BEEHIIV_PUBLICATION_ID. Nothing sent, gap noted.',
        };
      }
      try {
        const res = await fetch(
          `https://api.beehiiv.com/v2/publications/${process.env.BEEHIIV_PUBLICATION_ID}/posts`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${process.env.BEEHIIV_API_KEY}`,
            },
            body: JSON.stringify({
              title: pkg.headline,
              subtitle: pkg.subhead,
              status: 'draft',
              content: { free: { web: packageBodyHtml(pkg) } },
            }),
          },
        );
        if (!res.ok) {
          return {
            destination,
            status: 'skipped',
            note: `beehiiv draft failed (${res.status}) — nothing sent, gap noted.`,
          };
        }
        const data = (await res.json().catch(() => ({}))) as BeehiivPostResponse;
        const draftId = data.data?.id;
        const draftUrl =
          data.data?.web_url ??
          (draftId
            ? `https://app.beehiiv.com/posts/${draftId}`
            : undefined);
        return {
          destination,
          status: 'draft-created',
          url: draftUrl,
          note: `beehiiv draft created: "${pkg.headline}"${draftId ? ` (draft ${draftId})` : ''}.`,
        };
      } catch {
        return {
          destination,
          status: 'skipped',
          note: 'beehiiv request failed (network error) — nothing sent, gap noted.',
        };
      }
    }

    return {
      destination,
      status: 'skipped',
      note: 'CMS send not configured — connect WordPress/Sanity/Contentful. Download remains available.',
    };
  }
}
