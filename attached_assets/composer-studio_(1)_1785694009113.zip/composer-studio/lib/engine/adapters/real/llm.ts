// Real ModelAdapter plumbing — Anthropic + OpenAI-compatible chat,
// fetch-only (no SDKs), strict JSON, temperature 0.
//
// Provider selection: ANTHROPIC_API_KEY first (default claude-sonnet),
// then OPENAI_API_KEY with an optional OPENAI_BASE_URL (covers Kimi,
// Groq, and any OpenAI-compatible endpoint). MODEL_PROVIDER overrides
// the preference. Every caller gets `null` on any error — the seam's
// rule is heuristic fallback with an honest provenance note, never a
// crash.

export type ModelProvider = 'anthropic' | 'openai';

const ANTHROPIC_DEFAULT_MODEL = 'claude-sonnet-4-5';
const OPENAI_DEFAULT_MODEL = 'gpt-4o-mini';
const OPENAI_DEFAULT_BASE_URL = 'https://api.openai.com/v1';

export function modelConfigured(): ModelProvider | null {
  const pref = (process.env.MODEL_PROVIDER ?? '').toLowerCase();
  const hasAnthropic = Boolean(process.env.ANTHROPIC_API_KEY);
  const hasOpenai = Boolean(process.env.OPENAI_API_KEY);
  if (pref === 'anthropic') return hasAnthropic ? 'anthropic' : null;
  if (pref === 'openai') return hasOpenai ? 'openai' : null;
  if (hasAnthropic) return 'anthropic';
  if (hasOpenai) return 'openai';
  return null;
}

export function modelProviderLabel(): string {
  const provider = modelConfigured();
  if (!provider) return 'none';
  if (provider === 'anthropic') {
    return `anthropic/${process.env.ANTHROPIC_MODEL || ANTHROPIC_DEFAULT_MODEL}`;
  }
  const base = process.env.OPENAI_BASE_URL || OPENAI_DEFAULT_BASE_URL;
  let host = 'openai-compatible';
  try {
    host = base.includes('api.openai.com') ? 'openai' : new URL(base).hostname;
  } catch {
    // keep the generic label
  }
  return `${host}/${process.env.OPENAI_MODEL || OPENAI_DEFAULT_MODEL}`;
}

interface ChatArgs {
  system: string;
  user: string;
  /** Cap on completion tokens (gate eval + classification are small). */
  maxTokens?: number;
}

async function anthropicChat(args: ChatArgs): Promise<string | null> {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY!,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || ANTHROPIC_DEFAULT_MODEL,
      max_tokens: args.maxTokens ?? 2048,
      temperature: 0,
      system: args.system,
      messages: [{ role: 'user', content: args.user }],
    }),
  });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    content?: Array<{ type?: string; text?: string }>;
  };
  const text = (data.content ?? []).find((c) => c.type === 'text')?.text;
  return text ?? null;
}

async function openaiChat(args: ChatArgs): Promise<string | null> {
  const base = (process.env.OPENAI_BASE_URL || OPENAI_DEFAULT_BASE_URL).replace(/\/$/, '');
  const res = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || OPENAI_DEFAULT_MODEL,
      temperature: 0,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: args.system },
        { role: 'user', content: args.user },
      ],
      ...(args.maxTokens ? { max_tokens: args.maxTokens } : {}),
    }),
  });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  return data.choices?.[0]?.message?.content ?? null;
}

/** Extract the first JSON object from model output (fence-tolerant). */
function parseJsonObject(text: string): unknown | null {
  const fenced = /```(?:json)?\s*([\s\S]*?)```/.exec(text);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.indexOf('{');
  const end = candidate.lastIndexOf('}');
  if (start === -1 || end <= start) return null;
  try {
    return JSON.parse(candidate.slice(start, end + 1));
  } catch {
    return null;
  }
}

/**
 * One strict-JSON model call. Returns the parsed object, or null when
 * no provider is configured, the API errors, or the output isn't
 * parseable JSON — callers fall back to heuristics and note it.
 */
export async function chatJson<T>(args: ChatArgs): Promise<T | null> {
  const provider = modelConfigured();
  if (!provider) return null;
  try {
    const raw = provider === 'anthropic' ? await anthropicChat(args) : await openaiChat(args);
    if (!raw) return null;
    const parsed = parseJsonObject(raw);
    return (parsed as T) ?? null;
  } catch {
    return null;
  }
}
