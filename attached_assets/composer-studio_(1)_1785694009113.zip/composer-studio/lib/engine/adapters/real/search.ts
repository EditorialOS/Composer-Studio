// Real SearchAdapter — live web search behind the seam (spec Part 5,
// rule 1: web search is first-class and hot-swappable). Providers:
// Tavily, Brave, Perplexity Sonar — normalized to a common result
// shape. Facts constructed from results always carry sourceUrl (the
// compose loop's filtration drops URL-less facts — no URL, no fact).
//
// Provider selection: SEARCH_PROVIDER (or legacy
// COMPOSER_SEARCH_PROVIDER) pins the provider; otherwise the first
// configured key wins (tavily → brave → perplexity). Missing key or
// API error → available:false with an honest note, never a crash.

import type { ParsedBrief, SearchAdapter, SourceFact } from '../../types';
import { chatJson, modelConfigured } from './llm';

/** Normalized search result — every provider maps into this. */
export interface NormalizedResult {
  title: string;
  url: string;
  snippet: string;
  publishedAt?: string;
}

type ProviderName = 'tavily' | 'brave' | 'perplexity';

const PROVIDER_ORDER: ProviderName[] = ['tavily', 'brave', 'perplexity'];

function providerKey(provider: ProviderName): string | null {
  switch (provider) {
    case 'tavily':
      return process.env.TAVILY_API_KEY ?? null;
    case 'brave':
      return process.env.BRAVE_API_KEY ?? process.env.BRAVE_SEARCH_API_KEY ?? null;
    case 'perplexity':
      return process.env.PERPLEXITY_API_KEY ?? null;
  }
}

/** Provider + key, honoring SEARCH_PROVIDER, else first-configured-wins. */
function selectProvider(): { provider: ProviderName; key: string | null } {
  const pinned = (
    process.env.SEARCH_PROVIDER ??
    process.env.COMPOSER_SEARCH_PROVIDER ??
    ''
  ).toLowerCase();
  if (pinned && (PROVIDER_ORDER as string[]).includes(pinned)) {
    const provider = pinned as ProviderName;
    return { provider, key: providerKey(provider) };
  }
  for (const provider of PROVIDER_ORDER) {
    const key = providerKey(provider);
    if (key) return { provider, key };
  }
  return { provider: 'tavily', key: null };
}

// ── Provider calls ───────────────────────────────────────────

async function searchTavily(query: string, key: string): Promise<NormalizedResult[] | null> {
  const res = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ api_key: key, query, max_results: 8 }),
  });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    results?: Array<{ title?: string; content?: string; url?: string; published_date?: string }>;
  };
  return (data.results ?? [])
    .filter((r) => r.url)
    .map((r) => ({
      title: r.title ?? r.url!,
      url: r.url!,
      snippet: (r.content ?? '').slice(0, 300),
      publishedAt: r.published_date,
    }));
}

async function searchBrave(query: string, key: string): Promise<NormalizedResult[] | null> {
  const url = `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=8`;
  const res = await fetch(url, { headers: { 'X-Subscription-Token': key } });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    web?: {
      results?: Array<{ title?: string; url?: string; description?: string; page_age?: string }>;
    };
  };
  return (data.web?.results ?? [])
    .filter((r) => r.url)
    .map((r) => ({
      title: r.title ?? r.url!,
      url: r.url!,
      snippet: (r.description ?? '').slice(0, 300),
      publishedAt: r.page_age,
    }));
}

async function searchPerplexity(query: string, key: string): Promise<NormalizedResult[] | null> {
  const res = await fetch('https://api.perplexity.ai/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: 'sonar',
      messages: [
        {
          role: 'system',
          content:
            'You are a research assistant for an editorial team. Answer with current, sourced facts only.',
        },
        { role: 'user', content: query },
      ],
    }),
  });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
    citations?: string[];
  };
  const content = data.choices?.[0]?.message?.content ?? '';
  const citations = data.citations ?? [];
  if (citations.length === 0 && !content) return [];
  // Sonar returns an answer + citation URLs. Each citation becomes a
  // normalized result; the answer leads the first entry's snippet.
  return citations.map((url, i) => {
    let title = url;
    try {
      title = new URL(url).hostname;
    } catch {
      // keep the raw URL as the title
    }
    return {
      title,
      url,
      snippet: (i === 0 ? content : `Cited source for: ${query}`).slice(0, 300),
    };
  });
}

const PROVIDERS: Record<ProviderName, (q: string, key: string) => Promise<NormalizedResult[] | null>> = {
  tavily: searchTavily,
  brave: searchBrave,
  perplexity: searchPerplexity,
};

// ── Market-context synthesis ─────────────────────────────────

interface SynthesizedMarket {
  intro?: unknown;
  competitors?: Array<{ name?: unknown; detail?: unknown; color?: unknown; sourceUrl?: unknown }>;
  facts?: Array<{ text?: unknown; sourceName?: unknown; sourceUrl?: unknown }>;
  callout?: unknown;
}

const COMPETITOR_COLORS = ['#534AB7', '#1D9E75', '#D85A30', '#888780'];

/**
 * LLM synthesis of raw results into intro + competitors + facts.
 * Strict JSON, temperature 0 — and even the model's output is filtered
 * against the actual result URLs (no URL, no fact applies to the model
 * too). Returns null when no model is configured or anything fails.
 */
async function synthesizeWithModel(
  parsed: ParsedBrief,
  results: NormalizedResult[],
): Promise<{
  intro: string;
  competitors: Array<{ name: string; detail: string; color: string; sourceUrl?: string }>;
  facts: SourceFact[];
  callout?: string;
} | null> {
  if (!modelConfigured()) return null;
  const urlSet = new Set(results.map((r) => r.url));
  const payload = results
    .map((r, i) => `[${i}] ${r.title} — ${r.url}\n${r.snippet}`)
    .join('\n\n');
  const out = await chatJson<SynthesizedMarket>({
    system:
      'You synthesize web search results into market context for an editorial package. ' +
      'Respond with STRICT JSON only: {"intro": string, "competitors": [{"name": string, "detail": string, "sourceUrl": string}], ' +
      '"facts": [{"text": string, "sourceName": string, "sourceUrl": string}], "callout": string}. ' +
      'Every sourceUrl MUST be copied verbatim from the provided result URLs. Never invent a URL. ' +
      'Competitors = comparable outlets/properties/products covering the same story. Facts = sourced claims useful to an editor.',
    user: `Brief: ${parsed.headline}\nTags: ${parsed.searchTags.join(', ')}\n\nSearch results:\n${payload}`,
    maxTokens: 2500,
  });
  if (!out) return null;

  const facts: SourceFact[] = (out.facts ?? [])
    .filter((f) => typeof f?.text === 'string' && typeof f?.sourceUrl === 'string' && urlSet.has(f.sourceUrl))
    .map((f) => ({
      text: f.text as string,
      sourceName: typeof f.sourceName === 'string' ? f.sourceName : undefined,
      sourceUrl: f.sourceUrl as string,
    }));
  if (facts.length === 0) return null;

  return {
    intro:
      typeof out.intro === 'string' && out.intro
        ? out.intro
        : `Live market context synthesized from ${results.length} search results:`,
    competitors: (out.competitors ?? [])
      .filter((c) => typeof c?.name === 'string' && typeof c?.detail === 'string')
      .slice(0, 4)
      .map((c, i) => ({
        name: c.name as string,
        detail: c.detail as string,
        color: COMPETITOR_COLORS[i % COMPETITOR_COLORS.length],
        sourceUrl:
          typeof c.sourceUrl === 'string' && urlSet.has(c.sourceUrl) ? c.sourceUrl : undefined,
      })),
    facts,
    callout: typeof out.callout === 'string' ? out.callout : undefined,
  };
}

// ── The adapter ──────────────────────────────────────────────

export class RealSearchAdapter implements SearchAdapter {
  name = 'web-search';

  async capabilities() {
    const { provider, key } = selectProvider();
    return { webSearch: Boolean(key), provider };
  }

  async searchMarketContext(parsed: ParsedBrief) {
    const { provider, key } = selectProvider();
    if (!key) {
      return {
        available: false,
        intro: '',
        competitors: [],
        facts: [],
        note: `No search provider configured — set TAVILY_API_KEY, BRAVE_API_KEY, or PERPLEXITY_API_KEY (optionally pin SEARCH_PROVIDER). Market context skipped, gap noted.`,
      };
    }

    const query = [parsed.headline, ...parsed.searchTags.slice(0, 4)].join(' ');
    let results: NormalizedResult[] | null = null;
    try {
      results = await PROVIDERS[provider](query, key);
    } catch {
      results = null;
    }
    if (!results) {
      return {
        available: false,
        intro: '',
        competitors: [],
        facts: [],
        note: `Search provider "${provider}" errored — market context skipped, gap noted.`,
      };
    }
    if (results.length === 0) {
      return {
        available: true,
        intro: `Live search via ${provider} returned no results for this brief.`,
        competitors: [],
        facts: [],
        note: `Search provider "${provider}" returned zero results.`,
      };
    }

    // Preferred path: model synthesis over the raw results (strict JSON,
    // URLs filtered against actual results). Fallback: raw mapping —
    // snippets become facts directly, URLs always attached.
    const synthesized = await synthesizeWithModel(parsed, results);
    if (synthesized) {
      return { available: true, ...synthesized };
    }
    return {
      available: true,
      intro: `Live market context via ${provider} (${results.length} results — raw mapping, no model configured):`,
      competitors: [],
      facts: results
        .filter((r) => r.snippet)
        .map((r) => ({ text: r.snippet, sourceName: r.title, sourceUrl: r.url })),
    };
  }
}
