// Composer Studio engine — domain types + adapter seam.
// Every capability in the engine is a pluggable adapter. Nothing is
// hardwired. Adapters report capabilities; the compose loop degrades
// gracefully and notes every gap honestly in the package.

export type RightsStatus = 'cleared' | 'expiring' | 'check' | 'unknown';
export type GateStatus = 'pass' | 'warn' | 'fail';
export type Verdict = 'APPROVED' | 'REVISE';
export type PackageKind = 'breaking' | 'feature' | 'general';
export type ArchiveDepth = 'shallow' | 'standard' | 'deep';
export type SendDestination = 'beehiiv' | 'cms' | 'download';
export type ScenarioKey = 'casa-soledad' | 'noto-earthquake' | 'general';

export const GATE_NAMES = [
  'Theme alignment',
  'Angle differentiation',
  'Audience need',
  'Production reality',
  'Calendar fit',
] as const;
export type GateName = (typeof GATE_NAMES)[number];

export interface ComposeInput {
  brief: string;
  platforms: string[];
  archiveDepth: ArchiveDepth;
}

export interface ParsedBrief {
  headline: string;
  subhead: string;
  kind: PackageKind;
  badge?: string;
  searchTags: string[];
  scenario: ScenarioKey;
}

export interface GateResult {
  gate: GateName;
  status: GateStatus;
  note: string;
}

export interface GateEvaluation {
  gates: GateResult[];
  verdict: Verdict;
  verdictSummary: string;
  requiredRevisions: string[];
  editorNote?: string;
}

export interface Derivative {
  key: 'hero' | 'social' | 'story' | 'thumb';
  label: string;
  width: number;
  height: number;
  url: string;
}

export interface MatchedAsset {
  id: string;
  url: string;
  thumbnailUrl: string;
  width: number;
  height: number;
  format: string;
  bytes: number;
  tags: string[];
  matchNote?: string;
  photographer?: string;
  campaign?: string;
  rightsLabel?: string;
  rightsStatus: RightsStatus;
  rightsExpiresAt?: string;
  rightsNote?: string;
  derivatives: Derivative[];
}

export interface ArchiveFinding {
  title: string;
  excerpt: string;
  date?: string;
  source: string;
}

export interface MetricCard {
  label: string;
  value: string;
  sub?: string;
}

export interface ArchiveResult {
  connected: boolean;
  adapterName: string;
  findings: ArchiveFinding[];
  metrics: MetricCard[];
  note?: string;
}

export interface SourceFact {
  text: string;
  sourceName?: string;
  /** Arrival's discipline: no URL, no fact. Facts without one are dropped at assembly. */
  sourceUrl?: string;
}

export interface CompetitorCard {
  name: string;
  detail: string;
  color: string;
  sourceUrl?: string;
}

export interface MarketContext {
  intro: string;
  competitors: CompetitorCard[];
  /** Filtered at assembly: every fact here is guaranteed to carry a sourceUrl. */
  facts: SourceFact[];
  droppedFactCount: number;
  callout?: string;
}

export interface Deliverable {
  title: string;
  detail: string;
  color: string;
}

export interface WorkflowStep {
  title: string;
  detail: string;
}

export type CapabilityTone = 'ok' | 'warn' | 'gap';
export interface CapabilityNote {
  area: 'search' | 'assets' | 'archive' | 'rights' | 'send' | 'model';
  tone: CapabilityTone;
  note: string;
}

export interface Provenance {
  worked: string[];
  didntWork: string[];
  capabilityNotes: CapabilityNote[];
  generationMs: number;
}

export interface ComposerPackage {
  id: string;
  orgId: string;
  createdAt: string;
  brief: string;
  platforms: string[];
  archiveDepth: ArchiveDepth;
  kind: PackageKind;
  badge?: string;
  headline: string;
  subhead: string;
  evaluation: GateEvaluation;
  assets: MatchedAsset[];
  assetSearchNote?: string;
  archive: ArchiveResult;
  market: MarketContext;
  deliverables: Deliverable[];
  workflow: WorkflowStep[];
  provenance: Provenance;
}

export interface MemoryEntry {
  id: string;
  packageId: string;
  topic: string;
  createdAt: string;
  lanesTaken: string[];
  rightsFlagged: string[];
  verdict: Verdict;
  platforms: string[];
}

export interface SendRecord {
  id: string;
  packageId: string;
  destination: SendDestination;
  status: 'draft-created' | 'download-ready' | 'skipped';
  url?: string;
  note: string;
  createdAt: string;
}

export interface WorkspaceContextData {
  activeThemes: string[];
  recentCoverage: string[];
  voiceNotes: string;
  calendar: string[];
}

export interface SearchAdapter {
  name: string;
  capabilities(): Promise<{ webSearch: boolean; provider?: string }>;
  searchMarketContext(parsed: ParsedBrief): Promise<{
    available: boolean;
    intro: string;
    competitors: CompetitorCard[];
    /** May include URL-less facts; the assemble step drops them and counts. */
    facts: SourceFact[];
    callout?: string;
    note?: string;
  }>;
}

export interface AssetAdapter {
  name: string;
  capabilities(): Promise<{
    tagSearch: boolean;
    visualSearch: boolean;
    derivatives: boolean;
    rightsMetadata: boolean;
  }>;
  searchAssets(parsed: ParsedBrief): Promise<MatchedAsset[]>;
  listAssets(): Promise<MatchedAsset[]>;
  buildDerivatives(asset: MatchedAsset): Derivative[];
}

export interface ArchiveAdapter {
  name: string;
  capabilities(): Promise<{ connected: boolean; deepSearch: boolean }>;
  searchArchive(parsed: ParsedBrief, depth: ArchiveDepth): Promise<ArchiveResult>;
}

export interface RightsAdapter {
  name: string;
  capabilities(): Promise<{ embeddedMetadata: boolean; expiryTracking: boolean }>;
  enrichRights(assets: MatchedAsset[]): Promise<MatchedAsset[]>;
}

export interface SendAdapter {
  name: string;
  capabilities(): Promise<{ beehiivDraft: boolean; cmsDraft: boolean; downloadAll: boolean }>;
  send(
    pkg: ComposerPackage,
    destination: SendDestination,
  ): Promise<Omit<SendRecord, 'id' | 'packageId' | 'createdAt'>>;
}

export interface ModelAdapter {
  name: string;
  capabilities(): Promise<{ gateEval: boolean; provider?: string }>;
  parseBrief(input: ComposeInput): Promise<ParsedBrief>;
  evaluateGates(args: {
    parsed: ParsedBrief;
    workspace: WorkspaceContextData;
  }): Promise<GateEvaluation>;
  /** Assembled deliverables, workflow narration, and provenance seeds. */
  packageContent(parsed: ParsedBrief): Promise<{
    deliverables: Deliverable[];
    workflow: WorkflowStep[];
    worked: string[];
    didntWork: string[];
    assetSearchNote?: string;
  }>;
}

export interface ComposerAdapters {
  webSearch: SearchAdapter;
  imageLibrary: AssetAdapter;
  archive: ArchiveAdapter;
  rights: RightsAdapter;
  send: SendAdapter;
  llm: ModelAdapter;
}

// ── Intake router + source-agnostic asset quick-hit ─────────
// Spec Part 5B: one input box, the brief classifies itself. The user
// never picks a mode; the parse step routes.

export type IntakeRoute = 'assets' | 'compose' | 'newsletter';

export interface IntakeClassification {
  route: IntakeRoute;
  /** Human-readable why, surfaced in the UI ("Routed: asset search"). */
  reason: string;
  /** Cleaned search query when routed to the /assets quick-hit. */
  query?: string;
}

export type AssetSourceStatus = 'matched' | 'searched-empty' | 'not-connected';

/**
 * Per-source honesty report. /assets is source-agnostic: results merge
 * across connected adapters and every source names what it did —
 * matched, searched-but-empty (with the caveat that teaches library
 * hygiene), or not connected. Never a silent gap.
 */
export interface AssetSourceReport {
  source: string;
  status: AssetSourceStatus;
  matchCount: number;
  note: string;
}

export interface AssetSearchResult {
  query: string;
  total: number;
  assets: MatchedAsset[];
  sources: AssetSourceReport[];
}

export interface RightsCheckResult {
  assetId: string;
  found: boolean;
  source?: string;
  status?: RightsStatus;
  badge?: string;
  photographer?: string;
  rightsLabel?: string;
  expiresAt?: string;
  /** Always present — includes the "not on file" honesty. */
  note: string;
}

// ── Newsletter batch workflow (spec Part 5B, v1.5) ──────────
// "/run newsletter" + pasted edition → decompose into story atoms →
// per-story asset packages → ONE hero recommendation for the edition.
// The wedge buyer's daily workflow.

/** One story decomposed from a pasted newsletter edition. */
export interface StoryAtom {
  index: number;
  title: string;
  dek?: string;
  /** The story body text (used for keyword extraction + market search). */
  body: string;
  /** Cleaned search query for the asset fan-out. */
  searchQuery: string;
  wordCount: number;
}

/** Per-story asset package: merged matches + per-source honesty report. */
export interface StoryPackage {
  atom: StoryAtom;
  assets: MatchedAsset[];
  /** Per-source notes — matched / searched-but-empty / not connected. */
  sources: AssetSourceReport[];
  note?: string;
}

/** The single hero pick for the whole edition, with reasoning. */
export interface HeroRecommendation {
  assetId: string;
  storyIndex: number;
  storyTitle: string;
  reasoning: string;
  asset: MatchedAsset;
}

export type AtomizationMethod = 'heuristic' | 'llm';

/** The edition package object — assembled, stored, logged to memory. */
export interface EditionPackage {
  id: string;
  orgId: string;
  createdAt: string;
  title: string;
  storyCount: number;
  stories: StoryPackage[];
  /** Strongest cleared-rights asset across stories. Null = honest miss. */
  hero: HeroRecommendation | null;
  /** Present when hero is null — why no recommendation was made. */
  heroNote?: string;
  atomization: AtomizationMethod;
  /** Edition-level honesty notes (fallbacks, gaps, thin searches). */
  notes: string[];
  generationMs: number;
}
