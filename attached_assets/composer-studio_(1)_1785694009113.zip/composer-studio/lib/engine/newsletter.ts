// The /newsletter batch workflow (spec Part 5B, v1.5 — the headline
// feature): paste a full newsletter edition → decompose into story
// atoms → per-story asset package (asset search + rights + derivatives,
// reusing the /assets fan-out in assets.ts) → ONE hero recommendation
// for the edition → edition package object logged to memory.
//
// Atomization is heuristic in mock mode (split on markdown headings /
// HRs / subject structure). The LLM seam is wired for real mode: when
// a model provider is configured, atomization goes through the
// ModelAdapter's chat helper with a strict JSON schema and falls back
// to the heuristic on any error — logged honestly in the edition notes.

import { isMockMode } from '../mock';
import { searchAllAssetSources } from './assets';
import { appendMemory, getEdition, saveEdition } from './store';
import type {
  AtomizationMethod,
  EditionPackage,
  HeroRecommendation,
  MatchedAsset,
  StoryAtom,
  StoryPackage,
} from './types';

/** Explicit trigger — "/run newsletter" + pasted edition. */
const RUN_PREFIX = /^\s*\/run\s+newsletter\b[\s:.-]*/i;

export function stripRunPrefix(text: string): string {
  return text.replace(RUN_PREFIX, '').trim();
}

// ── Atomization ──────────────────────────────────────────────

const HEADING = /^(#{1,3})\s+(.+?)\s*#*\s*$/;
const HR = /^\s*(?:---|\*\*\*|___)\s*$/;
// "Subject:" / "Story:" structure — newsletter exports often use it.
const SUBJECT = /^(?:subject|story|headline)\s*:\s*(.+)$/i;

function atomFromSection(index: number, title: string, body: string): StoryAtom {
  const trimmedBody = body.trim();
  const words = trimmedBody.split(/\s+/).filter(Boolean);
  // Query = title + the opening of the body — the terms most likely to
  // carry library tags (place names, subjects), not mid-story prose.
  const searchQuery = `${title} ${words.slice(0, 30).join(' ')}`.trim();
  return {
    index,
    title: title.trim(),
    dek: words.slice(0, 24).join(' ') + (words.length > 24 ? '…' : ''),
    body: trimmedBody,
    searchQuery,
    wordCount: words.length,
  };
}

/**
 * Heuristic atomizer: markdown headings (# = edition title, ##/### =
 * stories), HR-separated sections, or Subject:-line structure. The
 * classification table grows by rows — add structure patterns here.
 */
export function atomizeHeuristic(editionText: string): { title: string; stories: StoryAtom[] } {
  const text = stripRunPrefix(editionText);
  const lines = text.split('\n');

  let editionTitle = '';
  const sections: Array<{ title: string; level: number; body: string[] }> = [];

  for (const line of lines) {
    const heading = HEADING.exec(line);
    const subject = SUBJECT.exec(line);
    if (heading) {
      const [, hashes, title] = heading;
      // First single-# heading = the edition title, not a story.
      if (hashes.length === 1 && sections.length === 0 && !editionTitle) {
        editionTitle = title;
        continue;
      }
      sections.push({ title, level: hashes.length, body: [] });
    } else if (subject) {
      sections.push({ title: subject[1], level: 2, body: [] });
    } else if (HR.test(line)) {
      // HR = hard story boundary when the current section has content.
      const current = sections[sections.length - 1];
      if (current && current.body.join(' ').trim()) {
        sections.push({ title: '', level: 2, body: [] });
      }
    } else if (sections.length > 0) {
      sections[sections.length - 1].body.push(line);
    } else if (!editionTitle && line.trim() && !editionTitle) {
      // Leading non-heading text before any story — candidate title.
      editionTitle = line.trim().slice(0, 90);
    }
  }

  const stories = sections
    .filter((s) => s.title || s.body.join(' ').trim())
    .map((s, i) =>
      atomFromSection(
        i,
        s.title || `Story ${i + 1}`,
        // Untitled HR-split sections keep their first line as dek only.
        s.body.join('\n'),
      ),
    );

  if (!editionTitle) {
    editionTitle = stories[0]?.title ?? 'Untitled edition';
  }
  return { title: editionTitle, stories };
}

interface LlmAtom {
  title?: unknown;
  dek?: unknown;
  body?: unknown;
}

/**
 * LLM atomizer (real mode only, model key configured): strict JSON
 * schema, temperature 0, heuristic fallback on any error. Returns null
 * when unavailable so the caller falls back and notes it honestly.
 */
async function atomizeWithLlm(
  editionText: string,
): Promise<{ title: string; stories: StoryAtom[] } | null> {
  if (isMockMode()) return null;
  try {
    // Dynamic import: keeps the mock path dependency-free.
    const { chatJson, modelConfigured } = await import('./adapters/real/llm');
    if (!modelConfigured()) return null;
    const result = await chatJson<{ edition_title?: unknown; stories?: LlmAtom[] }>({
      system:
        'You decompose a newsletter edition into story atoms. Respond with STRICT JSON only: ' +
        '{"edition_title": string, "stories": [{"title": string, "dek": string, "body": string}]}. ' +
        'One entry per distinct story. Preserve the story body text; do not invent content.',
      user: stripRunPrefix(editionText).slice(0, 12000),
    });
    if (!result || !Array.isArray(result.stories) || result.stories.length === 0) return null;
    const stories = result.stories
      .filter((s) => typeof s?.title === 'string' && s.title)
      .map((s, i) => {
        const body = typeof s.body === 'string' ? s.body : '';
        const atom = atomFromSection(i, String(s.title), body);
        if (typeof s.dek === 'string' && s.dek) atom.dek = s.dek;
        return atom;
      });
    if (stories.length === 0) return null;
    return {
      title:
        typeof result.edition_title === 'string' && result.edition_title
          ? result.edition_title
          : stories[0].title,
      stories,
    };
  } catch {
    return null;
  }
}

// ── Hero recommendation ──────────────────────────────────────
// ONE hero for the edition: the strongest CLEARED-rights asset across
// all stories. Expiring/check/unknown assets are never recommended —
// that's the point of rights-first packaging.

const MAX_DIMENSION = 4000;

function rankCleared(
  candidates: Array<{ asset: MatchedAsset; storyIndex: number; storyTitle: string }>,
): { asset: MatchedAsset; storyIndex: number; storyTitle: string } {
  return candidates.sort((a, b) => {
    const areaA = a.asset.width * a.asset.height;
    const areaB = b.asset.width * b.asset.height;
    // Beyond MAX_DIMENSION extra pixels stop mattering for a hero —
    // prefer the lead story instead.
    const effA = Math.min(a.asset.width, MAX_DIMENSION) * Math.min(a.asset.height, MAX_DIMENSION);
    const effB = Math.min(b.asset.width, MAX_DIMENSION) * Math.min(b.asset.height, MAX_DIMENSION);
    if (effA !== effB) return effB - effA;
    if (a.storyIndex !== b.storyIndex) return a.storyIndex - b.storyIndex;
    return areaB - areaA;
  })[0];
}

function pickHero(stories: StoryPackage[]): { hero: HeroRecommendation | null; note?: string } {
  const all = stories.flatMap((story) =>
    story.assets.map((asset) => ({
      asset,
      storyIndex: story.atom.index,
      storyTitle: story.atom.title,
    })),
  );
  const cleared = all.filter((c) => c.asset.rightsStatus === 'cleared');

  if (cleared.length === 0) {
    const flagged = all.length;
    return {
      hero: null,
      note:
        flagged > 0
          ? `No CLEARED-rights asset across the ${stories.length} stories (${flagged} matched but flagged EXPIRING/CHECK/UNKNOWN) — hero recommendation withheld. Clear rights on one of the flagged assets and re-run.`
          : 'No assets matched any story in this edition — no hero recommendation possible. This is a shot spec: commission or clear imagery first.',
    };
  }

  const winner = rankCleared(cleared);
  const { asset } = winner;
  const others = cleared.length - 1;
  return {
    hero: {
      assetId: asset.id,
      storyIndex: winner.storyIndex,
      storyTitle: winner.storyTitle,
      reasoning:
        `"${asset.id}" is the strongest cleared-rights asset in the edition: ` +
        `${asset.rightsLabel ? `rights "${asset.rightsLabel}"` : 'rights CLEARED'}` +
        `${asset.photographer ? ` by ${asset.photographer}` : ''}, ` +
        `${asset.width}×${asset.height}px — the highest-resolution CLEARED image across all ` +
        `${stories.length} stories${others > 0 ? ` (${others} other cleared candidate${others > 1 ? 's' : ''} considered)` : ''}. ` +
        `Comes from story ${winner.storyIndex + 1} ("${winner.storyTitle}"). ` +
        `EXPIRING, CHECK, and UNKNOWN assets were excluded on rights grounds.`,
      asset,
    },
  };
}

// ── The edition package ──────────────────────────────────────

function slugify(text: string): string {
  const slug = text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 48);
  return slug || 'edition';
}

async function uniqueEditionId(base: string): Promise<string> {
  if (!(await getEdition(base))) return base;
  for (let i = 2; i < 100; i++) {
    const candidate = `${base}-${i}`;
    if (!(await getEdition(candidate))) return candidate;
  }
  return `${base}-${Date.now().toString(36)}`;
}

/**
 * The newsletter batch loop:
 *   atomize → PARALLEL per-story asset fan-out (search + rights +
 *   derivatives via assets.ts) → hero recommendation → assemble →
 *   store → log to memory. Gaps are named, never silent.
 */
export async function composeNewsletter(
  edition: string,
  orgId: string,
): Promise<EditionPackage> {
  const startedAt = Date.now();
  const text = edition.trim();
  const notes: string[] = [];

  // 1. Atomize — LLM seam in real mode, heuristic fallback (and always
  //    heuristic in mock mode, zero keys required).
  let atomization: AtomizationMethod = 'heuristic';
  let { title, stories: atoms } = atomizeHeuristic(text);
  const llmAtoms = await atomizeWithLlm(text);
  if (llmAtoms) {
    atomization = 'llm';
    ({ title, stories: atoms } = llmAtoms);
    notes.push('Edition atomized by the configured model provider (structured JSON, temperature 0).');
  } else if (!isMockMode()) {
    notes.push(
      'Model provider unavailable or unconfigured — edition atomized with the heading/HR heuristic (gap noted, no silent failure).',
    );
  } else {
    notes.push('Mock mode: edition atomized with the heading/HR heuristic.');
  }

  if (atoms.length === 0) {
    atoms = [atomFromSection(0, title || 'Untitled story', text)];
    notes.push('No story structure detected — treated the whole paste as a single story.');
  }
  if (atoms.length === 1) {
    notes.push('Only one story detected — the hero pick is that story\'s strongest cleared asset.');
  }

  // 2. Per-story asset packages — the same source-agnostic fan-out,
  //    rights enrichment, and derivative crops as the /assets quick-hit.
  const stories: StoryPackage[] = await Promise.all(
    atoms.map(async (atom) => {
      const result = await searchAllAssetSources(atom.searchQuery);
      // Rank: rights-cleared first, then resolution.
      const ranked = [...result.assets].sort((a, b) => {
        const rank = (s: string) => (s === 'cleared' ? 0 : s === 'expiring' ? 1 : s === 'check' ? 2 : 3);
        const d = rank(a.rightsStatus) - rank(b.rightsStatus);
        return d !== 0 ? d : b.width * b.height - a.width * a.height;
      });
      const assets = ranked.slice(0, 6);
      const note =
        assets.length === 0
          ? 'No assets matched this story — treat as a shot spec (IMAGE NEEDED) and commission or clear imagery.'
          : assets.every((a) => a.rightsStatus !== 'cleared')
            ? 'Assets matched but none are CLEARED — rights work needed before publish.'
            : undefined;
      return { atom, assets, sources: result.sources, note };
    }),
  );

  // 3. ONE hero recommendation for the edition.
  const { hero, note: heroNote } = pickHero(stories);
  if (heroNote) notes.push(heroNote);

  // 4. Edition-level honesty notes.
  const unknownRights = stories
    .flatMap((s) => s.assets)
    .filter((a) => a.rightsStatus === 'unknown').length;
  if (unknownRights > 0) {
    notes.push(
      `${unknownRights} matched asset${unknownRights > 1 ? 's' : ''} with no rights metadata on file — flagged UNKNOWN.`,
    );
  }
  const thinStories = stories.filter((s) => s.assets.length === 0).length;
  if (thinStories > 0) {
    notes.push(
      `${thinStories} stor${thinStories > 1 ? 'ies' : 'y'} with zero asset matches — shot spec needed.`,
    );
  }

  const editionTitle = title || 'Untitled edition';
  const id = await uniqueEditionId(`edition-${slugify(editionTitle)}`);

  const pkg: EditionPackage = {
    id,
    orgId,
    createdAt: new Date().toISOString(),
    title: editionTitle,
    storyCount: stories.length,
    stories,
    hero,
    heroNote,
    atomization,
    notes,
    generationMs: Date.now() - startedAt,
  };

  // 5. Store + log to memory — lanes taken, rights flagged.
  await saveEdition(pkg);
  const rightsFlagged = [
    ...new Set(
      stories
        .flatMap((s) => s.assets)
        .filter((a) => a.rightsStatus !== 'cleared')
        .map((a) => `${a.photographer ?? a.id}: ${a.rightsStatus.toUpperCase()}`),
    ),
  ];
  await appendMemory(orgId, {
    id: `mem-${id}`,
    packageId: id,
    topic: `${editionTitle} (newsletter batch · ${stories.length} stories)`,
    createdAt: pkg.createdAt,
    lanesTaken: [
      'newsletter-batch',
      'assets',
      ...(rightsFlagged.length > 0 ? ['rights-flagged'] : ['rights']),
      ...(hero ? ['hero-recommendation'] : []),
    ],
    rightsFlagged,
    verdict:
      hero && stories.every((s) => s.assets.some((a) => a.rightsStatus === 'cleared'))
        ? 'APPROVED'
        : 'REVISE',
    platforms: ['Newsletter'],
  });

  return pkg;
}
