# HANDOFF — Composer Studio

Dummy-proof instructions for running, wiring real services, and deploying Composer Studio.
If you can copy-paste, you can do everything below.

---

## 0. The 60-second demo (no keys, no accounts)

```bash
npm install
COMPOSER_MOCK=1 npm run dev
```

Open http://localhost:3000. Everything works: auth is bypassed (you are "Demo Publication"),
and search/assets/archive/send/models are mock adapters with real-feeling fixtures.

**Replit:** import the repo → add one Secret `COMPOSER_MOCK=1` → Run command `npm run dev`. Done.

---

## 1. Environment variables

Copy `.env.example` to `.env.local` and fill in what you're connecting. **Everything is
optional except removing `COMPOSER_MOCK` when you go live.**

| Variable | What it's for | Where to get it |
|---|---|---|
| `COMPOSER_MOCK` | `1` = full demo with zero keys. **Unset it for production.** | You set it yourself |
| `COMPOSER_API_KEY` | Bearer key for the MCP endpoint (`POST /api/mcp`). In mock mode any non-empty key works. | You invent it (keep secret) |
| `COMPOSER_MCP_ORG_ID` | Optional org pinning for MCP calls (until per-customer keys land) | You choose |
| `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` | Clerk auth (sign-in/up, orgs) — browser side | dashboard.clerk.com → your app → API Keys |
| `CLERK_SECRET_KEY` | Clerk auth — server side | same place |
| `SUPABASE_URL` | Package/memory store, billing rows, audit log | supabase.com → project → Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | Server-side Supabase access (keep secret!) | same page, "service_role" key |
| `SUPABASE_ANON_KEY` | Client-side Supabase (optional today) | same page, "anon" key |
| `CLOUDINARY_CLOUD_NAME` | Built-in asset library | cloudinary.com → Dashboard |
| `CLOUDINARY_API_KEY` | 〃 | 〃 |
| `CLOUDINARY_API_SECRET` | 〃 (keep secret) | 〃 |
| `CLOUDINARY_FOLDER` | Optional folder scope per library | you choose |
| `COMPOSER_SEARCH_PROVIDER` | Which web-search adapter powers market context (`tavily` default) | you choose |
| `TAVILY_API_KEY` | Live market/angle context | tavily.com → API keys |
| `BRAVE_SEARCH_API_KEY` | Alternative search provider | brave.com/search/api |
| `PERPLEXITY_API_KEY` | Alternative search provider | perplexity.ai → API settings |
| `BEEHIIV_API_KEY` | Send → beehiiv draft posts | beehiiv → Settings → API |
| `BEEHIIV_PUBLICATION_ID` | Which beehiiv publication drafts go to | same page (`pub_…`) |
| `STRIPE_SECRET_KEY` | Billing (Solo/Studio/Agency) | dashboard.stripe.com → Developers → API keys |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Stripe — browser side | same page |
| `STRIPE_PRICE_SOLO_ID` / `STRIPE_PRICE_STUDIO_ID` / `STRIPE_PRICE_AGENCY_ID` | Price objects for the three tiers | Stripe → Products → create 3 prices, copy `price_…` IDs |
| `STRIPE_WEBHOOK_SECRET` | Verifies Stripe webhooks | Stripe → Webhooks → add `/api/stripe/webhook` → signing secret |
| `STRIPE_TRIAL_DAYS` | Trial length (default 7) | you choose |
| `OPENAI_API_KEY` | Editorial gate eval + library embeddings | platform.openai.com → API keys |
| `OPENAI_MODEL` / `OPENAI_EMBEDDING_MODEL` | Model overrides | defaults are fine |
| `ANTHROPIC_API_KEY` | Alternative model provider | console.anthropic.com |
| `NEXT_PUBLIC_APP_URL` | Public URL (Stripe redirects) | your Vercel domain |
| `NEXT_PUBLIC_GA_ID` | Google Analytics (optional) | analytics.google.com |
| `COMPOSER_ASSET_LIMIT` | Library cap per workspace (default 50) | you choose |

Rule of thumb: **Clerk + Supabase + Cloudinary** get you a working real product. Add a search
key next, beehiiv when you want Send, Stripe when you want money, OpenAI when you want the
full Editorial Director.

**MCP endpoint:** the engine is agent-callable at `POST /api/mcp` (Streamable HTTP). Tools:
`search_assets`, `compose_package`, `check_rights`, `send_package`. Auth is
`Authorization: Bearer $COMPOSER_API_KEY` on every request (mock mode accepts any non-empty
key and serves the demo org). `GET /api/mcp` returns the tools/list-compatible descriptor.
The exact Claude Cowork/Desktop `mcpServers` config JSON is in the comment block at the top
of `app/api/mcp/route.ts` and in the README's MCP section.

---

## 2. Supabase tables (one-time, SQL editor)

```sql
create table if not exists organization_cloudinary (
  org_id text primary key,
  cloud_name text not null, api_key text not null, api_secret text not null,
  folder text, created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  org_id text not null, user_id text not null, action text not null,
  details jsonb default '{}'::jsonb, created_at timestamptz default now()
);
create table if not exists organization_billing (
  org_id text primary key,
  stripe_customer_id text, stripe_subscription_id text, status text, price_id text,
  current_period_end timestamptz, trial_end timestamptz,
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists waitlist_signups (
  id uuid primary key default gen_random_uuid(),
  email text not null unique, source text not null default 'marketing',
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create extension if not exists vector;
create table if not exists asset_embeddings (
  org_id text not null, public_id text not null, content text,
  embedding vector(1536), updated_at timestamptz default now(),
  primary key (org_id, public_id)
);
```

---

## 3. Deploy to Vercel (5 minutes)

1. Push the repo to GitHub (or import as-is).
2. vercel.com → **Add New → Project** → import the repo. Framework preset: **Next.js** (auto-detected).
3. **Environment Variables:** paste everything from your `.env.local` — or just `COMPOSER_MOCK=1` for a live demo deploy.
4. Deploy. Visit the URL → `/marketing` is public, the app is behind Clerk (or open in mock mode).
5. In Clerk dashboard: add your Vercel domain to allowed origins; in Stripe: point the webhook at `https://<your-domain>/api/stripe/webhook`.

## 4. Replit

1. Import from GitHub.
2. Secrets: add the env vars you need (or just `COMPOSER_MOCK=1`).
3. Run: `npm run dev`. If prompted to install, run `npm install` first.

## 5. Verify before selling

```bash
npx tsc --noEmit   # 0 errors
npm run build      # succeeds
```

Then click through: compose a brief → package renders all four tabs → library badges → send
creates a (mock) draft → memory logs the run → workspace context edits change the gate
evaluation on the next compose.
