import { WorkspaceForm } from '@/components/workspace-form';
import { probeCapabilities } from '@/lib/engine/adapters';
import { ensureSeedData, getWorkspaceContextData } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

function CapRow({ ok, label, detail }: { ok: boolean | 'warn'; label: string; detail: string }) {
  const color = ok === true ? '#639922' : ok === 'warn' ? '#EF9F27' : '#E24B4A';
  return (
    <div className="flex items-start gap-2.5">
      <span className="cs-dot mt-1" style={{ background: color }} />
      <p className="m-0 text-[13px] leading-[1.6] text-cs-t2">
        <span className="font-medium text-cs-t1">{label}</span> — {detail}
      </p>
    </div>
  );
}

export default async function OnboardingPage() {
  const { orgId, orgName, mock } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);
  const [workspace, caps] = await Promise.all([getWorkspaceContextData(orgId), probeCapabilities()]);

  return (
    <main className="mx-auto max-w-[680px] px-6 py-8">
      <p className="mb-1 text-[11px] uppercase tracking-[0.5px] text-cs-t3">Workspace — {orgName}</p>
      <h1 className="m-0 mb-1.5 text-[20px] font-medium text-cs-t1">Workspace context</h1>
      <p className="mb-6 mt-0 text-[13px] leading-[1.6] text-cs-t2">
        Better inputs = sharper critique. The editorial gate evaluation consumes everything below on
        every compose run.
      </p>

      <WorkspaceForm initial={workspace} />

      <div className="mt-6">
        <p className="cs-card-label">Adapter capability probing — detected at setup, reported honestly</p>
        <div className="cs-card flex flex-col gap-2">
          <CapRow
            ok={caps.webSearch.webSearch}
            label={`Web search (${caps.adapters.webSearch})`}
            detail={
              caps.webSearch.webSearch
                ? `provider: ${caps.webSearch.provider ?? 'configured'}`
                : 'not configured — market context skipped, gap named in the package'
            }
          />
          <CapRow
            ok={caps.imageLibrary.tagSearch}
            label={`Asset library (${caps.adapters.imageLibrary})`}
            detail={caps.imageLibrary.tagSearch ? 'tag search available' : 'not configured'}
          />
          <CapRow
            ok={caps.imageLibrary.visualSearch ? true : 'warn'}
            label="Visual search"
            detail={
              caps.imageLibrary.visualSearch
                ? 'indexed and available'
                : 'not indexed on this library — falls back to tag search, noted in output'
            }
          />
          <CapRow
            ok={caps.archive.connected}
            label={`Archive (${caps.adapters.archive})`}
            detail={
              caps.archive.connected
                ? 'connected — prior coverage + institutional notes'
                : 'not connected — packages say "No archive configured"'
            }
          />
          <CapRow
            ok={caps.rights.embeddedMetadata}
            label={`Rights (${caps.adapters.rights})`}
            detail="reads embedded XMP/IPTC metadata; unknowns flagged, never hidden"
          />
          <CapRow
            ok={caps.send.beehiivDraft || caps.send.cmsDraft ? true : 'warn'}
            label={`Send (${caps.adapters.send})`}
            detail={`beehiiv draft: ${caps.send.beehiivDraft ? 'ready' : 'not configured'} · CMS draft: ${caps.send.cmsDraft ? 'ready' : 'not configured'} · download: always`}
          />
          <CapRow
            ok={caps.llm.gateEval}
            label={`Editorial model (${caps.adapters.llm})`}
            detail={`provider: ${caps.llm.provider ?? 'none'}`}
          />
        </div>
      </div>

      {!mock && (
        <p className="mt-6 text-[12px] text-cs-t3">
          Team management lives in <a href="/organization" className="text-cs-info underline">Workspace → team</a>.
          Bring-your-own-Cloudinary connector: <a href="/settings/cloudinary" className="text-cs-info underline">settings</a>.
        </p>
      )}
    </main>
  );
}
