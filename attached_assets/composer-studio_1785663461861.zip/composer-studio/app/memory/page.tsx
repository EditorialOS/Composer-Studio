import Link from 'next/link';
import { formatDate } from '@/components/ui';
import { ensureSeedData, listMemory } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

export default async function MemoryPage() {
  const { orgId } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);
  const entries = await listMemory();

  return (
    <main className="mx-auto max-w-[680px] px-6 py-8">
      <p className="mb-1 text-[11px] uppercase tracking-[0.5px] text-cs-t3">Memory</p>
      <h1 className="m-0 mb-1.5 text-[20px] font-medium text-cs-t1">
        What we know, package by package
      </h1>
      <p className="mb-6 mt-0 text-[13px] leading-[1.6] text-cs-t2">
        Every package logs back: lanes taken, rights flagged, sources used. This view gets smarter
        every run.
      </p>

      {entries.length === 0 && (
        <div className="cs-card">
          <p className="m-0 text-[13px] text-cs-t2">Nothing logged yet — compose a package.</p>
        </div>
      )}

      <div className="flex flex-col gap-2">
        {entries.map((entry) => (
          <Link
            key={entry.id}
            href={`/package/${entry.packageId}`}
            className="rounded-cs-lg bg-cs-b2 p-4 transition hover:bg-cs-bd3/40"
          >
            <div className="flex items-start justify-between gap-3">
              <p className="m-0 text-[14px] font-medium text-cs-t1">{entry.topic}</p>
              <span
                className={`flex-shrink-0 rounded px-2 py-0.5 text-[10px] font-semibold ${
                  entry.verdict === 'APPROVED'
                    ? 'bg-cs-successbg text-cs-success'
                    : 'bg-cs-dangerbg text-cs-danger'
                }`}
              >
                {entry.verdict}
              </span>
            </div>
            <p className="m-0 mt-1 text-[11px] text-cs-t3">
              {formatDate(entry.createdAt)} · {entry.platforms.join(', ') || 'no platforms'}
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {entry.lanesTaken.map((lane) => (
                <span key={lane} className="cs-pill text-cs-t2">
                  {lane}
                </span>
              ))}
            </div>
            {entry.rightsFlagged.length > 0 && (
              <p className="m-0 mt-2 text-[12px] text-cs-warn">
                Rights flagged: {entry.rightsFlagged.join(' · ')}
              </p>
            )}
          </Link>
        ))}
      </div>
    </main>
  );
}
