'use client';

import Link from 'next/link';
import { SignUp } from '@clerk/nextjs';

const MOCK = process.env.NEXT_PUBLIC_COMPOSER_MOCK === '1';

export default function SignUpPage() {
  if (MOCK) {
    return (
      <div className="min-h-screen bg-os-bg text-os-text">
        <div className="mx-auto flex min-h-screen max-w-5xl items-center justify-center px-6 py-12">
          <div className="w-full max-w-md rounded-3xl border border-black/10 bg-white p-6 text-center shadow-sm">
            <h1 className="text-2xl font-semibold">Mock mode — no sign-up needed</h1>
            <p className="mt-2 text-sm text-os-muted">
              COMPOSER_MOCK=1 bypasses auth. You are the demo org: <strong>Demo Publication</strong>.
            </p>
            <Link
              href="/compose"
              className="mt-6 inline-flex rounded-full bg-os-accent px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-600"
            >
              Open Composer Studio
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-os-bg text-os-text">
      <div className="mx-auto flex min-h-screen max-w-5xl items-center justify-center px-6 py-12">
        <div className="w-full max-w-md rounded-3xl border border-black/10 bg-white p-6 shadow-sm">
          <h1 className="text-2xl font-semibold">Create your account</h1>
          <p className="mt-2 text-sm text-os-muted">Start composing publishable packages.</p>
          <div className="mt-6">
            <SignUp routing="path" path="/sign-up" />
          </div>
        </div>
      </div>
    </div>
  );
}
