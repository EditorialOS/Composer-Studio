import { notFound } from 'next/navigation';
import { PackageView } from '@/components/package-view';
import { ensureSeedData, getPackage } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

export default async function PackagePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { orgId } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);
  const pkg = await getPackage(id);
  if (!pkg) notFound();
  return (
    <main className="min-h-screen">
      <PackageView pkg={pkg} />
    </main>
  );
}
