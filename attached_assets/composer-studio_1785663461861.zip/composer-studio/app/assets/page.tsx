import { AssetsSearch } from '@/components/assets-search';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

export default async function AssetsPage() {
  const { orgName } = await getWorkspaceIdentity();

  return (
    <main className="mx-auto max-w-5xl px-6 py-8">
      <p className="mb-1 text-[11px] uppercase tracking-[0.5px] text-cs-t3">
        Assets — {orgName}
      </p>
      <h1 className="m-0 mb-1.5 text-[20px] font-medium text-cs-t1">
        Asset quick-hit — search everything that&apos;s connected
      </h1>
      <p className="mb-6 mt-0 max-w-2xl text-[13px] leading-[1.6] text-cs-t2">
        Source-agnostic: results merge across every connected library, and each source reports
        honestly — matched, searched-but-empty, or not connected. Rights badges and derivative
        crops only; no archive, no market context. For the full loop, use{' '}
        <a href="/compose" className="text-cs-info hover:underline">
          Compose
        </a>
        .
      </p>

      <AssetsSearch />
    </main>
  );
}
