import { Suspense } from 'react';
import { SendForm } from '@/components/send-form';
import { ensureSeedData, listPackages, listSends } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

export default async function SendPage() {
  const { orgId } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);
  const [packages, sends] = await Promise.all([listPackages(orgId), listSends()]);

  return (
    <main className="mx-auto max-w-[680px] px-6 py-8">
      <p className="mb-1 text-[11px] uppercase tracking-[0.5px] text-cs-t3">Send</p>
      <h1 className="m-0 mb-1.5 text-[20px] font-medium text-cs-t1">One click onward</h1>
      <p className="mb-6 mt-0 text-[13px] leading-[1.6] text-cs-t2">
        beehiiv draft, CMS draft, or download-all. The package never locks you in.
      </p>
      {packages.length === 0 ? (
        <div className="cs-card">
          <p className="m-0 text-[13px] text-cs-t2">No packages yet — compose one first.</p>
        </div>
      ) : (
        <Suspense>
          <SendForm packages={packages} sends={sends} />
        </Suspense>
      )}
    </main>
  );
}
