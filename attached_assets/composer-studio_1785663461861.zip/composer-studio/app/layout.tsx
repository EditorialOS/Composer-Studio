import type { Metadata } from 'next'
import Script from 'next/script'
import { ClerkProvider } from '@clerk/nextjs'
import { Nav } from '@/components/nav'
import './globals.css'

export const metadata: Metadata = {
  title: 'Composer Studio',
  description:
    'Paste a brief, get a publishable package — your images rights-checked and cropped, your archive, the competitive landscape, the angle to take.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const gaId = process.env.NEXT_PUBLIC_GA_ID
  const mockMode = process.env.COMPOSER_MOCK === '1'

  const shell = (
    <>
      <Nav />
      {children}
    </>
  )

  return (
    <html lang="en">
      <body className="antialiased bg-os-bg text-cs-t1">
        {/* Mock mode runs without Clerk keys — provider is skipped entirely. */}
        {mockMode ? shell : <ClerkProvider>{shell}</ClerkProvider>}
        {gaId && (
          <>
            <Script
              src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`}
              strategy="afterInteractive"
            />
            <Script id="ga-init" strategy="afterInteractive">
              {`window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', '${gaId}');`}
            </Script>
          </>
        )}
      </body>
    </html>
  )
}
