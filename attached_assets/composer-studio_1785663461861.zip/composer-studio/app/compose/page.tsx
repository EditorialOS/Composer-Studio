import Link from 'next/link';
import { ComposeForm } from '@/components/compose-form';
import { relativeTime } from '@/components/ui';
import { ensureSeedData, listPackages } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

export default async function ComposePage() {
  const { orgId } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);
  const recent = (await listPackages(orgId)).slice(0, 4);

  return (
    <main className="mx-auto max-w-[680px] px-6 py-8">
      <p className="mb-1 text-[11px] uppercase tracking-[0.5px] text-cs-t3">Compose</p>
      <h1 className="m-0 mb-1.5 text-[20px] font-medium text-cs-t1">
        Paste a brief, get a publishable package
      </h1>
      <p className="mb-6 mt-0 text-[13px] leading-[1.6] text-cs-t2">
        Your images, rights-checked and cropped. Your archive&apos;s prior coverage. The competitive
        landscape. The angle to take.
      </p>

      <ComposeForm />

      {recent.length > 0 && (
        <div className="mt-8">
          <p className="cs-card-label">Recent packages</p>
          <div className="flex flex-col gap-2">
            {recent.map((pkg) => (
              <Link
                key={pkg.id}
                href={`/package/${pkg.id}`}
                className="flex items-center justify-between rounded-cs-md bg-cs-b2 px-4 py-3 transition hover:bg-cs-bd3/40"
              >
                <div>
                  <p className="m-0 text-[13px] font-medium text-cs-t1">{pkg.headline}</p>
                  <p className="m-0 mt-0.5 text-[11px] text-cs-t3">
                    {relativeTime(pkg.createdAt)} · {pkg.platforms.join(', ') || 'no platforms'}
                  </p>
                </div>
                <span
                  className={`rounded px-2 py-0.5 text-[10px] font-semibold ${
                    pkg.evaluation.verdict === 'APPROVED'
                      ? 'bg-cs-successbg text-cs-success'
                      : 'bg-cs-dangerbg text-cs-danger'
                  }`}
                >
                  {pkg.evaluation.verdict}
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
