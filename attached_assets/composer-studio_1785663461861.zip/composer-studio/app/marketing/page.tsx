'use client';

import { useState } from 'react';
import Link from 'next/link';

const SCREENS = [
  {
    title: 'Library',
    copy: 'The asset grid with rights badges at a glance: CLEARED / EXPIRING / CHECK / UNKNOWN.',
  },
  {
    title: 'Compose',
    copy: 'One input: the brief. Optional platforms and archive depth. Generation takes seconds.',
  },
  {
    title: 'The Package',
    copy: 'A tabbed artifact: five-gate editorial assessment, rights-badged assets, derivative crops, market context, honest provenance.',
  },
  {
    title: 'Send',
    copy: 'One click onward: beehiiv draft, CMS draft, or download-all.',
  },
  {
    title: 'Memory',
    copy: 'Every package logged: lanes taken, rights flagged, sources used. Smarter every run.',
  },
];

const TIERS = [
  { name: 'Solo', price: '$99/mo', detail: '1 publication · 20 packages/mo · built-in library OR 1 connector · beehiiv/CMS send' },
  { name: 'Studio', price: '$299/mo', detail: '3 publications · unlimited packages · all connectors · memory · priority models' },
  { name: 'Agency', price: '$750+/mo', detail: 'Multi-client workspaces · white-label packages · API/MCP access' },
];

export default function MarketingPage() {
  const [email, setEmail] = useState('');
  const [submitState, setSubmitState] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [submitMessage, setSubmitMessage] = useState('');

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    const normalizedEmail = email.trim();
    if (!normalizedEmail) return;

    setSubmitState('loading');
    setSubmitMessage('');

    try {
      const response = await fetch('/api/marketing/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail }),
      });

      const data = (await response.json()) as { error?: string };
      if (!response.ok) {
        setSubmitState('error');
        setSubmitMessage(data.error || 'Unable to join waitlist right now.');
        return;
      }

      setSubmitState('success');
      setSubmitMessage('Thanks. We will reach out when early access opens.');
      setEmail('');
    } catch (error) {
      console.error('Waitlist submit failed:', error);
      setSubmitState('error');
      setSubmitMessage('Unable to join waitlist right now.');
    }
  };

  return (
    <div className="min-h-screen bg-os-bg text-os-text">
      <header className="border-b border-black/5 bg-white/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold tracking-wide">Composer Studio</span>
            <span className="rounded-full border border-black/10 bg-os-bg px-2 py-0.5 text-[10px] text-os-muted">
              Beta
            </span>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <Link
              href="/compose"
              className="rounded-full border border-black/10 bg-white px-4 py-2 text-os-text shadow-sm transition hover:bg-os-bg"
            >
              Open app
            </Link>
            <a
              href="#waitlist"
              className="rounded-full bg-os-accent px-4 py-2 font-semibold text-white shadow-sm transition hover:bg-blue-600"
            >
              Join waitlist
            </a>
          </div>
        </div>
      </header>

      <main>
        <section className="gradient-bg">
          <div className="mx-auto max-w-6xl px-6 py-16">
            <div className="grid gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
              <div className="space-y-6">
                <p className="text-xs uppercase tracking-[0.3em] text-os-muted">Composer Studio</p>
                <h1 className="text-4xl font-semibold tracking-tight sm:text-5xl">
                  Paste a brief, get a publishable package
                </h1>
                <p className="text-base text-os-muted">
                  Your images, rights-checked and cropped. Your archive&apos;s prior coverage. The
                  competitive landscape. The angle to take. Works with the DAM and CMS you already
                  have — is one if you don&apos;t.
                </p>
                <div className="flex flex-wrap gap-3">
                  <a
                    href="#waitlist"
                    className="rounded-full bg-os-accent px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-600"
                  >
                    Join the waitlist
                  </a>
                  <Link
                    href="/compose"
                    className="rounded-full border border-black/10 bg-white px-5 py-2 text-sm text-os-text shadow-sm transition hover:bg-os-bg"
                  >
                    Try the demo
                  </Link>
                </div>
                <div className="flex flex-wrap gap-2 text-xs text-os-muted">
                  {[
                    'Five-gate editorial assessment',
                    'Rights checked, crops cut',
                    'Archive prior coverage',
                    'Competitive landscape + the angle',
                  ].map((item) => (
                    <span
                      key={item}
                      className="rounded-full border border-black/10 bg-white px-3 py-1 shadow-sm"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
              <div className="rounded-3xl border border-black/10 bg-white p-6 shadow-sm">
                <p className="text-xs uppercase tracking-[0.3em] text-os-muted">Why it&apos;s different</p>
                <div className="mt-4 space-y-4 text-sm text-os-muted">
                  <div className="rounded-2xl border border-black/10 bg-os-bg p-4">
                    <p className="text-sm font-semibold text-os-text">Judgment, not plumbing</p>
                    <p>An editorial director evaluates every brief — five gates, a verdict, required revisions.</p>
                  </div>
                  <div className="rounded-2xl border border-black/10 bg-os-bg p-4">
                    <p className="text-sm font-semibold text-os-text">The package is the artifact</p>
                    <p>A designed, tabbed, downloadable package — not a chat log, not a resized file.</p>
                  </div>
                  <div className="rounded-2xl border border-black/10 bg-os-bg p-4">
                    <p className="text-sm font-semibold text-os-text">Rides what you have</p>
                    <p>If you have a DAM, Composer rides it. If you don&apos;t, Composer is one — one that packages.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-16">
          <div className="grid gap-6 md:grid-cols-3">
            {SCREENS.slice(0, 3).map((feature) => (
              <div key={feature.title} className="rounded-3xl border border-black/10 bg-white p-6 shadow-sm">
                <h3 className="text-base font-semibold">{feature.title}</h3>
                <p className="mt-2 text-sm text-os-muted">{feature.copy}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {SCREENS.slice(3).map((feature) => (
              <div key={feature.title} className="rounded-3xl border border-black/10 bg-white p-6 shadow-sm">
                <h3 className="text-base font-semibold">{feature.title}</h3>
                <p className="mt-2 text-sm text-os-muted">{feature.copy}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 pb-16">
          <div className="rounded-3xl border border-black/10 bg-white p-8 shadow-sm">
            <p className="text-xs uppercase tracking-[0.3em] text-os-muted">Pricing</p>
            <h2 className="text-3xl font-semibold">Between the toys and the DAMs</h2>
            <p className="mt-2 text-sm text-os-muted">
              Priced where the empty middle lives — rights-first, archive-aware, judgment-bearing.
            </p>
            <div className="mt-6 grid gap-4 md:grid-cols-3">
              {TIERS.map((tier) => (
                <div key={tier.name} className="rounded-2xl border border-black/10 bg-os-bg px-6 py-5">
                  <p className="text-sm font-semibold">{tier.name}</p>
                  <p className="mt-1 text-2xl font-semibold">{tier.price}</p>
                  <p className="mt-2 text-xs text-os-muted">{tier.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="waitlist" className="mx-auto max-w-6xl px-6 pb-20">
          <div className="rounded-3xl border border-black/10 bg-white p-8 shadow-sm">
            <div className="grid gap-6 md:grid-cols-[1.2fr_0.8fr] md:items-center">
              <div>
                <p className="text-xs uppercase tracking-[0.3em] text-os-muted">Waitlist</p>
                <h2 className="text-3xl font-semibold">Join early access</h2>
                <p className="mt-2 text-sm text-os-muted">
                  Be first in line when Composer Studio opens to new publications.
                </p>
              </div>
              <form onSubmit={handleSubmit} className="flex flex-col gap-3">
                <input
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@publication.com"
                  required
                  className="h-12 rounded-xl border border-black/10 bg-white px-4 text-sm text-os-text shadow-sm focus:border-os-accent focus:outline-none focus:ring-2 focus:ring-os-accent/20"
                />
                <button
                  type="submit"
                  disabled={submitState === 'loading'}
                  className="h-12 rounded-xl bg-os-accent text-sm font-semibold text-white shadow-sm transition hover:bg-blue-600"
                >
                  {submitState === 'loading' ? 'Joining...' : 'Join waitlist'}
                </button>
                {submitState !== 'idle' && (
                  <p className={submitState === 'error' ? 'text-xs text-red-600' : 'text-xs text-os-muted'}>
                    {submitMessage}
                  </p>
                )}
              </form>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-black/5 bg-white/80">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-6 py-6 text-xs text-os-muted sm:flex-row sm:items-center sm:justify-between">
          <span>Composer Studio — paste a brief, get a publishable package</span>
          <div className="flex items-center gap-3">
            <Link href="/legal/privacy" className="underline">
              Privacy
            </Link>
            <Link href="/legal/terms" className="underline">
              Terms
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
