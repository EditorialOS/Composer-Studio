import { NextResponse } from 'next/server';
import { getWorkspaceContextData, saveWorkspaceContextData } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';
import type { WorkspaceContextData } from '@/lib/engine/types';

export const runtime = 'nodejs';

function toLines(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String).map((s) => s.trim()).filter(Boolean);
  if (typeof value === 'string') return value.split('\n').map((s) => s.trim()).filter(Boolean);
  return [];
}

export async function GET() {
  const { orgId } = await getWorkspaceIdentity();
  return NextResponse.json({ workspace: await getWorkspaceContextData(orgId) });
}

export async function POST(req: Request) {
  let body: Partial<Record<keyof WorkspaceContextData, unknown>>;
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  const workspace: WorkspaceContextData = {
    activeThemes: toLines(body.activeThemes),
    recentCoverage: toLines(body.recentCoverage),
    voiceNotes: typeof body.voiceNotes === 'string' ? body.voiceNotes.trim() : '',
    calendar: toLines(body.calendar),
  };

  const { orgId } = await getWorkspaceIdentity();
  await saveWorkspaceContextData(orgId, workspace);
  return NextResponse.json({ workspace });
}
