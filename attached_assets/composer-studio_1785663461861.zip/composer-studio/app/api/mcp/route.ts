/**
 * Composer Studio — MCP endpoint (Streamable HTTP).
 *
 * The same engine the dashboard uses, exposed as agent-callable tools
 * (spec Part 4: one engine, two faces — MCP follows from the same
 * codebase as a thin wrapper; the proxy pattern is proven twice:
 * The-Gate-VPS, Context-API).
 *
 * Tools: search_assets · compose_package · check_rights · send_package
 * (GET /api/mcp returns the tools/list-compatible descriptor.)
 *
 * Auth: `Authorization: Bearer <COMPOSER_API_KEY>` on every request.
 * In COMPOSER_MOCK=1 any non-empty key works and resolves the demo org.
 *
 * ── Client config: Claude Cowork / Claude Desktop ──────────────────
 * claude_desktop_config.json (or Cowork's MCP settings):
 *
 * {
 *   "mcpServers": {
 *     "composer-studio": {
 *       "url": "https://<your-host>/api/mcp",
 *       "headers": {
 *         "Authorization": "Bearer <COMPOSER_API_KEY>"
 *       }
 *     }
 *   }
 * }
 *
 * Local dev: "url": "http://localhost:3000/api/mcp" with any bearer
 * token while COMPOSER_MOCK=1.
 * ───────────────────────────────────────────────────────────────────
 */

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import { z } from 'zod';
import { isMockMode, MOCK_WORKSPACE } from '@/lib/mock';
import {
  MCP_TOOL_DESCRIPTORS,
  toolCheckRights,
  toolComposePackage,
  toolSearchAssets,
  toolSendPackage,
} from '@/lib/engine/mcp';

export const runtime = 'nodejs';

interface McpAuth {
  orgId: string;
}

/**
 * Bearer auth. Mock mode: any non-empty key → demo org. Real mode: must
 * match COMPOSER_API_KEY. Multi-tenant keying (key → customer org) rides
 * COMPOSER_MCP_ORG_ID until per-customer key storage lands.
 */
function authenticate(req: Request): McpAuth | null {
  const header = req.headers.get('authorization') ?? '';
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  const token = match?.[1]?.trim();
  if (!token) return null;

  if (isMockMode()) {
    return { orgId: MOCK_WORKSPACE.orgId };
  }
  const expected = process.env.COMPOSER_API_KEY;
  if (!expected || token !== expected) return null;
  return { orgId: process.env.COMPOSER_MCP_ORG_ID ?? 'mcp-customer' };
}

/** JSON-RPC-shaped 401, per the MCP-over-HTTP convention. */
function unauthorized(): Response {
  return Response.json(
    {
      jsonrpc: '2.0',
      error: {
        code: -32001,
        message:
          'Unauthorized — send Authorization: Bearer <COMPOSER_API_KEY>. In mock mode any non-empty key works.',
      },
      id: null,
    },
    { status: 401, headers: { 'WWW-Authenticate': 'Bearer realm="composer-studio-mcp"' } },
  );
}

function textResult(payload: unknown) {
  return {
    content: [{ type: 'text' as const, text: JSON.stringify(payload, null, 2) }],
  };
}

/** Request-scoped server — one McpServer per POST, never shared state. */
function createServer(orgId: string): McpServer {
  const server = new McpServer({ name: 'composer-studio', version: '1.0.0' });

  server.registerTool(
    'search_assets',
    {
      description: MCP_TOOL_DESCRIPTORS[0].description,
      inputSchema: { query: z.string().min(1).describe('What to look for, e.g. "apple pictures".') },
    },
    async ({ query }) => textResult(await toolSearchAssets(query)),
  );

  server.registerTool(
    'compose_package',
    {
      description: MCP_TOOL_DESCRIPTORS[1].description,
      inputSchema: { brief: z.string().min(1).describe('The story brief — one line to a full draft.') },
    },
    async ({ brief }) => textResult(await toolComposePackage(brief, orgId)),
  );

  server.registerTool(
    'check_rights',
    {
      description: MCP_TOOL_DESCRIPTORS[2].description,
      inputSchema: { asset_id: z.string().min(1).describe('Asset id, e.g. "lib-apple-orchard-row".') },
    },
    async ({ asset_id }) => textResult(await toolCheckRights(asset_id)),
  );

  server.registerTool(
    'send_package',
    {
      description: MCP_TOOL_DESCRIPTORS[3].description,
      inputSchema: {
        package_id: z.string().min(1).describe('Package id returned by compose_package.'),
        destination: z.enum(['beehiiv', 'cms', 'download']),
      },
    },
    async ({ package_id, destination }) => textResult(await toolSendPackage(package_id, destination)),
  );

  return server;
}

export async function POST(req: Request) {
  const auth = authenticate(req);
  if (!auth) return unauthorized();

  // Stateless (no session id) + JSON responses — one request in, one
  // response out, nothing held between calls. Request-scoped server.
  const server = createServer(auth.orgId);
  const transport = new WebStandardStreamableHTTPServerTransport({
    enableJsonResponse: true,
  });
  try {
    await server.connect(transport);
    return await transport.handleRequest(req);
  } finally {
    await transport.close().catch(() => {});
    await server.close().catch(() => {});
  }
}

/** Discovery: the tools/list-compatible descriptor, no auth required. */
export async function GET() {
  return Response.json({
    name: 'composer-studio',
    version: '1.0.0',
    transport: 'streamable-http',
    auth: 'Bearer COMPOSER_API_KEY (any non-empty key in COMPOSER_MOCK=1)',
    tools: MCP_TOOL_DESCRIPTORS,
  });
}
