import { NextResponse } from 'next/server';
import { searchAllAssetSources } from '@/lib/engine/assets';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const runtime = 'nodejs';

/**
 * The /assets quick-hit endpoint. Source-agnostic: fans out across every
 * connected library, merges results, and honestly reports per-source
 * status. AssetAdapter seam only — no archive, no market context.
 */
export async function POST(req: Request) {
  let body: { query?: string };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  const query = (body.query ?? '').trim();
  if (!query) {
    return NextResponse.json({ error: 'Query is required.' }, { status: 400 });
  }

  await getWorkspaceIdentity();
  const result = await searchAllAssetSources(query);
  return NextResponse.json(result);
}
