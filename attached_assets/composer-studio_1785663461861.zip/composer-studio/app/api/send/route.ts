import { NextResponse } from 'next/server';
import { getAdapters } from '@/lib/engine/adapters';
import { getPackage, listSends, recordSend } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';
import type { SendDestination, SendRecord } from '@/lib/engine/types';

export const runtime = 'nodejs';

const DESTINATIONS: SendDestination[] = ['beehiiv', 'cms', 'download'];

export async function POST(req: Request) {
  let body: { packageId?: string; destination?: string };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  const destination = body.destination as SendDestination;
  if (!body.packageId || !DESTINATIONS.includes(destination)) {
    return NextResponse.json({ error: 'packageId and a valid destination are required.' }, { status: 400 });
  }

  await getWorkspaceIdentity();
  const pkg = await getPackage(body.packageId);
  if (!pkg) {
    return NextResponse.json({ error: 'Package not found.' }, { status: 404 });
  }

  const adapters = getAdapters();
  const result = await adapters.send.send(pkg, destination);

  const record: SendRecord = {
    ...result,
    id: `send-${Date.now().toString(36)}`,
    packageId: pkg.id,
    createdAt: new Date().toISOString(),
  };
  await recordSend(record);

  return NextResponse.json({ send: record });
}

export async function GET() {
  await getWorkspaceIdentity();
  return NextResponse.json({ sends: await listSends() });
}
