'use client';

import Link from 'next/link';
import { SignIn } from '@clerk/nextjs';

const MOCK = process.env.NEXT_PUBLIC_COMPOSER_MOCK === '1';

export default function SignInPage() {
  if (MOCK) {
    return (
      <div className="min-h-screen bg-os-bg text-os-text">
        <div className="mx-auto flex min-h-screen max-w-5xl items-center justify-center px-6 py-12">
          <div className="w-full max-w-md rounded-3xl border border-black/10 bg-white p-6 text-center shadow-sm">
            <h1 className="text-2xl font-semibold">Mock mode — no sign-in needed</h1>
            <p className="mt-2 text-sm text-os-muted">
              COMPOSER_MOCK=1 bypasses auth. You are the demo org: <strong>Demo Publication</strong>.
            </p>
            <Link
              href="/compose"
              className="mt-6 inline-flex rounded-full bg-os-accent px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-600"
            >
              Open Composer Studio
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-os-bg text-os-text">
      <div className="mx-auto flex min-h-screen max-w-5xl items-center justify-center px-6 py-12">
        <div className="w-full max-w-md rounded-3xl border border-black/10 bg-white p-6 shadow-sm">
          <h1 className="text-2xl font-semibold">Welcome back</h1>
          <p className="mt-2 text-sm text-os-muted">Sign in to your Composer Studio workspace.</p>
          <div className="mt-6">
            <SignIn routing="path" path="/sign-in" />
          </div>
        </div>
      </div>
    </div>
  );
}
