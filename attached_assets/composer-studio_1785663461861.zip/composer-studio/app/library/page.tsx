import { RightsBadge, formatBytes } from '@/components/ui';
import { getAdapters } from '@/lib/engine/adapters';
import { ensureSeedData } from '@/lib/engine/store';
import { getWorkspaceIdentity } from '@/lib/workspace';

export const dynamic = 'force-dynamic';

export default async function LibraryPage() {
  const { orgId, orgName } = await getWorkspaceIdentity();
  await ensureSeedData(orgId);
  const adapters = getAdapters();
  const [assets, caps] = await Promise.all([
    adapters.imageLibrary.listAssets(),
    adapters.imageLibrary.capabilities(),
  ]);

  return (
    <main className="mx-auto max-w-5xl px-6 py-8">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <p className="mb-1 text-[11px] uppercase tracking-[0.5px] text-cs-t3">Library — {orgName}</p>
          <h1 className="m-0 text-[20px] font-medium text-cs-t1">
            {assets.length} asset{assets.length === 1 ? '' : 's'} · rights at a glance
          </h1>
        </div>
        <p className="m-0 text-[12px] text-cs-t3">
          {caps.visualSearch ? 'visual search on' : 'tag search (visual search not indexed)'}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {assets.map((asset) => (
          <div key={asset.id} className="overflow-hidden rounded-cs-lg bg-cs-b2">
            <div className="relative" style={{ aspectRatio: '4/3' }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={asset.thumbnailUrl}
                alt={asset.tags.join(', ') || asset.id}
                className="h-full w-full object-cover"
                loading="lazy"
              />
              <div className="absolute left-2 top-2">
                <RightsBadge status={asset.rightsStatus} />
              </div>
            </div>
            <div className="p-3">
              <p className="m-0 truncate text-[12px] font-medium text-cs-t1">{asset.id}</p>
              <p className="m-0 mt-0.5 text-[11px] text-cs-t2">
                {asset.photographer ? `${asset.photographer} · ` : ''}
                {asset.width}×{asset.height}
                {asset.bytes ? ` · ${formatBytes(asset.bytes)}` : ''}
              </p>
              {asset.rightsLabel && (
                <p className="m-0 mt-0.5 text-[11px] text-cs-t2">Rights: {asset.rightsLabel}</p>
              )}
              {asset.rightsExpiresAt && (
                <p className="m-0 mt-0.5 text-[11px] text-cs-warn">
                  Expires {new Date(asset.rightsExpiresAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </p>
              )}
              {asset.rightsNote && (
                <p className="m-0 mt-0.5 text-[11px] text-cs-t3">{asset.rightsNote}</p>
              )}
              <div className="mt-1.5 flex flex-wrap gap-1">
                {asset.tags.slice(0, 4).map((tag) => (
                  <span key={tag} className="rounded bg-cs-b1 px-1.5 py-0.5 text-[10px] text-cs-t3">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
