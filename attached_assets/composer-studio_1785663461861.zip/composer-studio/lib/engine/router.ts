// The intake router (spec Part 5B — the command grammar).
// One input box. The brief classifies itself; the user never picks a
// mode. Two routes at launch, one engine:
//   assets  → /assets quick-hit (AssetAdapter fan-out only — no archive,
//             no market context)
//   compose → the full /compose loop (brief → package)
//
// Mock mode uses a keyword/length heuristic (below). The classification
// table grows by rows, not rebuilds — add intent patterns here.
//
// TODO(real mode): route classification through the ModelAdapter seam —
// an LLM call with the same table as few-shot examples, falling back to
// this heuristic when no model provider is configured.

import type { IntakeClassification } from './types';

// Short asset-search intent: a find-verb near a media-noun, or a bare
// "photos of X" phrasing. Keep rows additive — config, not code paths.
const ASSET_INTENT_PATTERNS: RegExp[] = [
  /\b(search|find|get|show|look\s?up|pull|grab|fetch)\b[^.!?\n]*\b(photo|photos|picture|pictures|image|images|pic|pics|asset|assets|graphic|graphics|shot|shots)\b/i,
  /\b(photos|pictures|images|pics|shots)\s+(of|for)\b/i,
];

// Longer than this (or multi-sentence) reads as a story/brief, not a
// quick asset lookup — route to the full compose loop.
const MAX_QUICK_HIT_CHARS = 160;
const MAX_QUICK_HIT_WORDS = 25;

const LEADING_FILLER =
  /^\s*(?:please\s+)?(?:can you\s+|could you\s+)?(?:search|find|get|show|look\s?up|pull|grab|fetch)\s+(?:for\s+|me\s+|up\s+)*/i;

/** Strip the find-verb framing so "search for apple pictures" → "apple pictures". */
export function extractAssetQuery(text: string): string {
  const cleaned = text.trim().replace(LEADING_FILLER, '').replace(/[.!?\s]+$/, '');
  return cleaned || text.trim();
}

export function classifyIntake(text: string): IntakeClassification {
  const trimmed = text.trim();
  const wordCount = trimmed.split(/\s+/).filter(Boolean).length;
  const shortEnough =
    trimmed.length <= MAX_QUICK_HIT_CHARS && wordCount <= MAX_QUICK_HIT_WORDS;
  const assetIntent = ASSET_INTENT_PATTERNS.some((pattern) => pattern.test(trimmed));

  if (assetIntent && shortEnough) {
    const query = extractAssetQuery(trimmed);
    return {
      route: 'assets',
      query,
      reason: `Routed: asset search — short find-intent detected ("${query}"). No archive, no market context.`,
    };
  }

  if (assetIntent) {
    return {
      route: 'compose',
      reason:
        'Routed: full package — mentions assets but reads as a story/brief (too long for a quick-hit).',
    };
  }

  return {
    route: 'compose',
    reason: 'Routed: full package — narrative brief, running the full compose loop.',
  };
}
