import { v2 as cloudinary } from 'cloudinary';
import type {
  ArchiveDepth,
  ArchiveResult,
  AssetAdapter,
  ComposeInput,
  ComposerPackage,
  GateEvaluation,
  MatchedAsset,
  ModelAdapter,
  ParsedBrief,
  RightsAdapter,
  SearchAdapter,
  SendAdapter,
  ArchiveAdapter,
  SendDestination,
  SendRecord,
  WorkspaceContextData,
} from '../../types';
import { withDerivatives } from '../../derivatives';
import { MockModelAdapter, keywords } from '../mock';

// ── Real implementation stubs ────────────────────────────────
// Each reads env config, reports capabilities honestly, and degrades
// to "not configured" (not an exception) when env is missing — the
// compose loop notes the gap in the package.

// ── Web search (Tavily first; provider set via COMPOSER_SEARCH_PROVIDER) ──

function searchKey(): { provider: string; key: string | null } {
  const provider = (process.env.COMPOSER_SEARCH_PROVIDER || 'tavily').toLowerCase();
  const key =
    provider === 'tavily'
      ? process.env.TAVILY_API_KEY
      : provider === 'brave'
        ? process.env.BRAVE_SEARCH_API_KEY
        : provider === 'perplexity'
          ? process.env.PERPLEXITY_API_KEY
          : null;
  return { provider, key: key ?? null };
}

export class RealSearchAdapter implements SearchAdapter {
  name = 'web-search';

  async capabilities() {
    const { provider, key } = searchKey();
    return { webSearch: Boolean(key), provider };
  }

  async searchMarketContext(parsed: ParsedBrief) {
    const { provider, key } = searchKey();
    if (!key) {
      return {
        available: false,
        intro: '',
        competitors: [],
        facts: [],
        note: `No search provider configured — set ${provider.toUpperCase()}_API_KEY. Market context skipped, gap noted.`,
      };
    }
    // Stub: Tavily search. Facts carry source URLs (no URL, no fact).
    const res = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: key,
        query: parsed.headline,
        max_results: 6,
      }),
    });
    if (!res.ok) {
      return {
        available: false,
        intro: '',
        competitors: [],
        facts: [],
        note: `Search provider error (${res.status}) — market context skipped, gap noted.`,
      };
    }
    const data = (await res.json()) as {
      results?: Array<{ title?: string; content?: string; url?: string }>;
    };
    const facts = (data.results ?? [])
      .filter((r) => r.url && r.content)
      .map((r) => ({
        text: r.content!.slice(0, 240),
        sourceName: r.title,
        sourceUrl: r.url,
      }));
    return {
      available: true,
      intro: `Live market context via ${provider}:`,
      competitors: [],
      facts,
    };
  }
}

// ── Asset library (Cloudinary) ───────────────────────────────

function cloudinaryConfigured() {
  return Boolean(
    process.env.CLOUDINARY_CLOUD_NAME &&
      process.env.CLOUDINARY_API_KEY &&
      process.env.CLOUDINARY_API_SECRET,
  );
}

function mapCloudinaryResource(r: any): MatchedAsset {
  const context = (r.context?.custom ?? r.context ?? {}) as Record<string, string>;
  const rightsLabel: string | undefined = context.usage_rights;
  const rightsStatus = rightsLabel
    ? /expir/i.test(rightsLabel)
      ? 'expiring'
      : 'cleared'
    : context.photographer
      ? 'check'
      : 'unknown';
  return withDerivatives({
    id: r.public_id,
    url: r.secure_url,
    thumbnailUrl: r.secure_url,
    width: r.width ?? 0,
    height: r.height ?? 0,
    format: r.format ?? 'jpg',
    bytes: r.bytes ?? 0,
    tags: r.tags ?? [],
    photographer: context.photographer,
    campaign: context.campaign,
    rightsLabel,
    rightsStatus,
    rightsNote: rightsLabel ? undefined : 'No rights metadata embedded — not on file.',
    derivatives: [],
  });
}

export class RealAssetAdapter implements AssetAdapter {
  name = 'cloudinary';

  async capabilities() {
    const configured = cloudinaryConfigured();
    return {
      tagSearch: configured,
      // Visual search requires per-asset indexing; not probed live — reported off.
      visualSearch: false,
      derivatives: configured,
      rightsMetadata: configured,
    };
  }

  private configure() {
    cloudinary.config({
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET,
      secure: true,
    });
  }

  async searchAssets(parsed: ParsedBrief): Promise<MatchedAsset[]> {
    if (!cloudinaryConfigured()) return [];
    this.configure();
    const expression =
      parsed.searchTags.length > 0
        ? parsed.searchTags.map((t) => `tags:${t}`).join(' OR ')
        : 'resource_type:image';
    const result = await cloudinary.search
      .expression(expression)
      .with_field('context')
      .with_field('tags')
      .max_results(12)
      .execute();
    return (result.resources ?? []).map(mapCloudinaryResource);
  }

  async listAssets(): Promise<MatchedAsset[]> {
    if (!cloudinaryConfigured()) return [];
    this.configure();
    const result = await cloudinary.search
      .expression('resource_type:image')
      .with_field('context')
      .with_field('tags')
      .max_results(50)
      .execute();
    return (result.resources ?? []).map(mapCloudinaryResource);
  }

  buildDerivatives(asset: MatchedAsset) {
    return withDerivatives(asset).derivatives;
  }
}

// ── Archive (stub: none configured until a connector ships) ──

export class RealArchiveAdapter implements ArchiveAdapter {
  name = 'archive';

  async capabilities() {
    return { connected: false, deepSearch: false };
  }

  async searchArchive(_parsed: ParsedBrief, _depth: ArchiveDepth): Promise<ArchiveResult> {
    return {
      connected: false,
      adapterName: 'none',
      findings: [],
      metrics: [],
      note: 'No archive configured — connect Drive, Sanity, Contentful, or WordPress. The package ships; the gap is named.',
    };
  }
}

// ── Rights (reads embedded metadata already on assets) ───────

export class RealRightsAdapter implements RightsAdapter {
  name = 'embedded-xmp';

  async capabilities() {
    return { embeddedMetadata: true, expiryTracking: true };
  }

  async enrichRights(assets: MatchedAsset[]): Promise<MatchedAsset[]> {
    return assets.map((asset) =>
      asset.rightsStatus === 'unknown' && !asset.rightsNote
        ? { ...asset, rightsNote: 'No rights metadata embedded — not on file.' }
        : asset,
    );
  }
}

// ── Send (beehiiv / CMS / download) ──────────────────────────

export class RealSendAdapter implements SendAdapter {
  name = 'send';

  async capabilities() {
    return {
      beehiivDraft: Boolean(process.env.BEEHIIV_API_KEY && process.env.BEEHIIV_PUBLICATION_ID),
      cmsDraft: false,
      downloadAll: true,
    };
  }

  async send(
    pkg: ComposerPackage,
    destination: SendDestination,
  ): Promise<Omit<SendRecord, 'id' | 'packageId' | 'createdAt'>> {
    if (destination === 'download') {
      return {
        destination,
        status: 'download-ready',
        url: `/package/${pkg.id}#download`,
        note: 'Deliverables + derivative URLs bundled for download.',
      };
    }
    if (destination === 'beehiiv') {
      const caps = await this.capabilities();
      if (!caps.beehiivDraft) {
        return {
          destination,
          status: 'skipped',
          note: 'beehiiv not configured — set BEEHIIV_API_KEY and BEEHIIV_PUBLICATION_ID.',
        };
      }
      // Stub: create a beehiiv draft post.
      const res = await fetch(
        `https://api.beehiiv.com/v2/publications/${process.env.BEEHIIV_PUBLICATION_ID}/posts`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${process.env.BEEHIIV_API_KEY}`,
          },
          body: JSON.stringify({
            title: pkg.headline,
            subtitle: pkg.subhead,
            status: 'draft',
            content: {
              free: {
                web: pkg.deliverables.map((d) => `<h3>${d.title}</h3><p>${d.detail}</p>`).join(''),
              },
            },
          }),
        },
      );
      if (!res.ok) {
        return {
          destination,
          status: 'skipped',
          note: `beehiiv draft failed (${res.status}) — nothing sent, gap noted.`,
        };
      }
      return {
        destination,
        status: 'draft-created',
        note: `beehiiv draft created: "${pkg.headline}".`,
      };
    }
    return {
      destination,
      status: 'skipped',
      note: 'CMS send not configured — connect WordPress/Sanity/Contentful.',
    };
  }
}

// ── Model (heuristic fallback; OpenAI when configured) ───────

export class RealModelAdapter extends MockModelAdapter implements ModelAdapter {
  name = 'editorial-director';

  async capabilities() {
    return {
      gateEval: true,
      provider: process.env.OPENAI_API_KEY ? 'openai' : 'heuristic',
    };
  }

  // parseBrief + evaluateGates use the deterministic heuristic
  // implementation — never the mock fixtures. TODO(real): route
  // evaluateGates through OpenAI / Anthropic chat completions with the
  // workspace context as system prompt; the seam is already typed for it.
  async parseBrief(input: ComposeInput): Promise<ParsedBrief> {
    const firstLine =
      input.brief.split(/[.\n]/).map((s) => s.trim()).filter(Boolean)[0] ?? 'Untitled brief';
    return {
      headline: firstLine.length > 90 ? `${firstLine.slice(0, 87)}…` : firstLine,
      subhead: `${input.platforms.length || 1} platform${(input.platforms.length || 1) > 1 ? 's' : ''} · ${input.archiveDepth} archive depth`,
      kind: 'general',
      searchTags: keywords(input.brief),
      scenario: 'general',
    };
  }

  async evaluateGates(args: {
    parsed: ParsedBrief;
    workspace: WorkspaceContextData;
  }): Promise<GateEvaluation> {
    return super.evaluateGates({
      ...args,
      parsed: { ...args.parsed, scenario: 'general' },
    });
  }
}
