import { isMockMode } from '../../mock';
import type { ComposerAdapters } from '../types';
import {
  MockArchiveAdapter,
  MockAssetAdapter,
  MockModelAdapter,
  MockRightsAdapter,
  MockSearchAdapter,
  MockSendAdapter,
} from './mock';
import {
  RealArchiveAdapter,
  RealAssetAdapter,
  RealModelAdapter,
  RealRightsAdapter,
  RealSearchAdapter,
  RealSendAdapter,
} from './real';

let cached: ComposerAdapters | null = null;

/**
 * The adapter seam. COMPOSER_MOCK=1 → every adapter is a mock with rich
 * fixtures; otherwise real implementations read env config and degrade
 * honestly when a capability isn't connected.
 */
export function getAdapters(): ComposerAdapters {
  if (cached) return cached;
  cached = isMockMode()
    ? {
        webSearch: new MockSearchAdapter(),
        imageLibrary: new MockAssetAdapter(),
        archive: new MockArchiveAdapter(),
        rights: new MockRightsAdapter(),
        send: new MockSendAdapter(),
        llm: new MockModelAdapter(),
      }
    : {
        webSearch: new RealSearchAdapter(),
        imageLibrary: new RealAssetAdapter(),
        archive: new RealArchiveAdapter(),
        rights: new RealRightsAdapter(),
        send: new RealSendAdapter(),
        llm: new RealModelAdapter(),
      };
  return cached;
}

/** Capability snapshot for the workspace/setup screen (probing surface). */
export async function probeCapabilities() {
  const adapters = getAdapters();
  const [webSearch, imageLibrary, archive, rights, send, llm] = await Promise.all([
    adapters.webSearch.capabilities(),
    adapters.imageLibrary.capabilities(),
    adapters.archive.capabilities(),
    adapters.rights.capabilities(),
    adapters.send.capabilities(),
    adapters.llm.capabilities(),
  ]);
  return {
    adapters: {
      webSearch: adapters.webSearch.name,
      imageLibrary: adapters.imageLibrary.name,
      archive: adapters.archive.name,
      rights: adapters.rights.name,
      send: adapters.send.name,
      llm: adapters.llm.name,
    },
    webSearch,
    imageLibrary,
    archive,
    rights,
    send,
    llm,
  };
}
