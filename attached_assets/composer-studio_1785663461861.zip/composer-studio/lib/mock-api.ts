import { NextResponse } from 'next/server';

export { isMockMode } from './mock';

/** Legacy fold-in routes short-circuit with this in mock mode. */
export function mockUnavailable(feature: string) {
  return NextResponse.json(
    { error: `${feature} is not available in mock mode (COMPOSER_MOCK=1).`, mock: true },
    { status: 503 },
  );
}
