import { auth, clerkClient } from '@clerk/nextjs/server';
import { isMockMode, MOCK_WORKSPACE } from './mock';

export type WorkspaceIdentity = {
  orgId: string;
  orgName: string;
  userId: string;
  mock: boolean;
};

/**
 * Resolves the current workspace (org) for server code.
 * In mock mode this always returns the demo workspace — no Clerk required.
 */
export async function getWorkspaceIdentity(): Promise<WorkspaceIdentity> {
  if (isMockMode()) {
    return { ...MOCK_WORKSPACE, mock: true };
  }

  const { userId, orgId } = await auth();
  if (!userId) {
    throw new Error('Unauthorized');
  }

  let orgName = 'Personal workspace';
  if (orgId) {
    try {
      const client = await clerkClient();
      const org = await client.organizations.getOrganization({ organizationId: orgId });
      orgName = org.name;
    } catch {
      // best effort — org name is display-only
    }
  }

  return {
    orgId: orgId ?? `user-${userId}`,
    orgName,
    userId,
    mock: false,
  };
}
