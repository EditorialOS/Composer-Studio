// Mock mode — COMPOSER_MOCK=1 makes the app fully runnable with zero real
// API keys. Every external dependency resolves through the adapter seam
// (lib/engine/) which ships mock implementations with rich fixtures.

export function isMockMode() {
  return process.env.COMPOSER_MOCK === '1';
}

export const MOCK_WORKSPACE = {
  orgId: 'demo-org',
  orgName: 'Demo Publication',
  userId: 'demo-user',
} as const;

// Client components read the flag via NEXT_PUBLIC_COMPOSER_MOCK, which
// next.config.ts auto-populates from COMPOSER_MOCK at build time.
export const CLIENT_MOCK_MODE = process.env.NEXT_PUBLIC_COMPOSER_MOCK === '1';
