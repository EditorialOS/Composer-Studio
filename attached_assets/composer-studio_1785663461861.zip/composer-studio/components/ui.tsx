import type { GateStatus, RightsStatus } from '@/lib/engine/types';

export const DOT_COLORS: Record<GateStatus | RightsStatus, string> = {
  pass: '#639922',
  cleared: '#639922',
  warn: '#EF9F27',
  expiring: '#EF9F27',
  check: '#EF9F27',
  fail: '#E24B4A',
  unknown: '#888780',
};

export function StatusDot({ status }: { status: GateStatus | RightsStatus }) {
  return <span className="cs-dot" style={{ background: DOT_COLORS[status] }} />;
}

export const RIGHTS_LABELS: Record<RightsStatus, string> = {
  cleared: 'CLEARED',
  expiring: 'EXPIRING',
  check: 'CHECK',
  unknown: 'UNKNOWN',
};

export function RightsBadge({ status }: { status: RightsStatus }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md bg-black/[0.04] px-2 py-1 text-[10px] font-semibold tracking-wide text-cs-t2">
      <StatusDot status={status} />
      {RIGHTS_LABELS[status]}
    </span>
  );
}

export function Card({
  children,
  className = '',
  style,
}: {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div className={`cs-card ${className}`} style={style}>
      {children}
    </div>
  );
}

export function CardLabel({ children }: { children: React.ReactNode }) {
  return <p className="cs-card-label">{children}</p>;
}

export function formatBytes(bytes: number): string {
  if (!bytes) return '';
  if (bytes >= 1_000_000) return `${(bytes / 1_000_000).toFixed(1)}MB`;
  if (bytes >= 1_000) return `${Math.round(bytes / 1_000)}KB`;
  return `${bytes}B`;
}

export function relativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.max(0, Math.round(diffMs / 60_000));
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;
  const days = Math.round(hours / 24);
  return `${days} day${days > 1 ? 's' : ''} ago`;
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}
