'use client';

import { useState } from 'react';
import type { WorkspaceContextData } from '@/lib/engine/types';

type Props = { initial: WorkspaceContextData };

function Field({
  label,
  hint,
  value,
  onChange,
  rows = 3,
  disabled,
}: {
  label: string;
  hint: string;
  value: string;
  onChange: (v: string) => void;
  rows?: number;
  disabled?: boolean;
}) {
  return (
    <div className="mb-4">
      <p className="m-0 mb-1 text-[13px] font-medium text-cs-t1">{label}</p>
      <p className="m-0 mb-1.5 text-[12px] text-cs-t3">{hint}</p>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        disabled={disabled}
        className="w-full resize-y rounded-cs-md border border-cs-bd3 bg-cs-b1 p-3 text-[13px] leading-[1.6] text-cs-t1 outline-none focus:border-cs-info"
      />
    </div>
  );
}

export function WorkspaceForm({ initial }: Props) {
  const [themes, setThemes] = useState(initial.activeThemes.join('\n'));
  const [coverage, setCoverage] = useState(initial.recentCoverage.join('\n'));
  const [voice, setVoice] = useState(initial.voiceNotes);
  const [calendar, setCalendar] = useState(initial.calendar.join('\n'));
  const [phase, setPhase] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  const save = async () => {
    setPhase('saving');
    try {
      const res = await fetch('/api/workspace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          activeThemes: themes,
          recentCoverage: coverage,
          voiceNotes: voice,
          calendar,
        }),
      });
      if (!res.ok) throw new Error('Save failed.');
      setPhase('saved');
      setTimeout(() => setPhase('idle'), 2500);
    } catch {
      setPhase('error');
    }
  };

  return (
    <div className="cs-card">
      <Field
        label="Active themes"
        hint="One per line. Gate 1 (theme alignment) checks every brief against these."
        value={themes}
        onChange={setThemes}
        disabled={phase === 'saving'}
      />
      <Field
        label="Recent coverage"
        hint="One per line. Gate 2 (angle differentiation) flags overlap with these."
        value={coverage}
        onChange={setCoverage}
        disabled={phase === 'saving'}
      />
      <Field
        label="Voice notes"
        hint="How the publication sounds. Deliverables are voice-matched to this."
        value={voice}
        onChange={setVoice}
        rows={2}
        disabled={phase === 'saving'}
      />
      <Field
        label="Calendar"
        hint="One per line. Gate 5 (calendar fit) checks timing against these."
        value={calendar}
        onChange={setCalendar}
        rows={2}
        disabled={phase === 'saving'}
      />
      <div className="flex items-center justify-end gap-3">
        {phase === 'saved' && <span className="text-[12px] text-cs-success">Saved — the next compose run uses this.</span>}
        {phase === 'error' && <span className="text-[12px] text-cs-danger">Save failed.</span>}
        <button
          type="button"
          onClick={save}
          disabled={phase === 'saving'}
          className="rounded-full bg-cs-t1 px-5 py-2 text-[13px] font-medium text-white transition enabled:hover:opacity-85 disabled:opacity-40"
        >
          {phase === 'saving' ? 'Saving…' : 'Save workspace context'}
        </button>
      </div>
    </div>
  );
}
