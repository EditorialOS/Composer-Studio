'use client';

import { useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import type { AssetSearchResult } from '@/lib/engine/types';
import { AssetResults } from './assets-search';

const PLATFORMS = ['Newsletter', 'Web article', 'Instagram', 'X/Threads', 'LinkedIn'];
const DEPTHS = [
  { value: 'shallow', label: 'Shallow — headlines only' },
  { value: 'standard', label: 'Standard' },
  { value: 'deep', label: 'Deep — institutional notes' },
] as const;

const DEMO_BRIEFS = [
  {
    label: 'Hotel launch (feature)',
    brief:
      'Casa Soledad — Oaxaca boutique hotel opening. 12 rooms, rooftop mezcal bar, pre-Hispanic tasting menu, Day of the Dead launch timing. Need: newsletter feature + social kit.',
  },
  {
    label: 'Noto earthquake (breaking)',
    brief:
      'Earthquake, Noto Peninsula, context package. M7.2, tsunami warnings across the Pacific Rim — same region devastated in Jan 2024.',
  },
  {
    label: 'Asset quick-hit (routes to /assets)',
    brief: 'search for apple pictures',
  },
];

type ComposeResponse =
  | ({ routed: 'asset-search'; reason: string } & AssetSearchResult)
  | { routed: 'full-package'; reason: string; id: string; verdict: string }
  | { error: string };

const ACK_STEPS = [
  'reading your brief…',
  'running the five-gate editorial evaluation…',
  'searching archive + assets + market in parallel…',
  'checking rights + cutting derivatives…',
  'assembling the package…',
];

export function ComposeForm() {
  const router = useRouter();
  const [brief, setBrief] = useState('');
  const [platforms, setPlatforms] = useState<string[]>(['Newsletter']);
  const [depth, setDepth] = useState<string>('standard');
  const [phase, setPhase] = useState<'idle' | 'working' | 'error'>('idle');
  const [ackStep, setAckStep] = useState(0);
  const [error, setError] = useState('');
  const [assetResult, setAssetResult] = useState<
    ({ routed: 'asset-search'; reason: string } & AssetSearchResult) | null
  >(null);
  const [fullPackageRouted, setFullPackageRouted] = useState<string>('');
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  const togglePlatform = (p: string) =>
    setPlatforms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));

  const submit = async () => {
    if (!brief.trim() || phase === 'working') return;
    setPhase('working');
    setError('');
    setAckStep(0);
    setAssetResult(null);
    setFullPackageRouted('');
    timers.current.forEach(clearTimeout);
    timers.current = ACK_STEPS.map((_, i) =>
      setTimeout(() => setAckStep(i), 350 * i),
    );

    try {
      const res = await fetch('/api/compose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ brief: brief.trim(), platforms, archiveDepth: depth }),
      });
      const data = (await res.json()) as ComposeResponse;
      if (!res.ok || 'error' in data) {
        throw new Error('error' in data ? data.error : 'Compose failed.');
      }
      timers.current.forEach(clearTimeout);

      // The intake router decided — show which route was taken.
      if (data.routed === 'asset-search') {
        setPhase('idle');
        setAssetResult(data);
        return;
      }
      setFullPackageRouted(`Routed: full package — assembling "${data.id}"…`);
      // Let the routed note breathe before navigating to the package.
      setTimeout(() => router.push(`/package/${data.id}`), 600);
    } catch (err) {
      timers.current.forEach(clearTimeout);
      setPhase('error');
      setError(err instanceof Error ? err.message : 'Compose failed.');
    }
  };

  return (
    <div className="cs-card">
      <textarea
        value={brief}
        onChange={(e) => setBrief(e.target.value)}
        rows={5}
        placeholder="Paste the brief — one line to a full draft. e.g. &quot;Boutique hotel opening in Oaxaca, need the newsletter feature + social kit.&quot;"
        className="w-full resize-y rounded-cs-md border border-cs-bd3 bg-cs-b1 p-3 text-[14px] leading-[1.6] text-cs-t1 outline-none placeholder:text-cs-t3 focus:border-cs-info"
        disabled={phase === 'working'}
      />

      <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-3">
        <div>
          <p className="m-0 mb-1.5 text-[11px] uppercase tracking-[0.5px] text-cs-t3">Platforms</p>
          <div className="flex flex-wrap gap-1.5">
            {PLATFORMS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => togglePlatform(p)}
                className={`cs-tab ${platforms.includes(p) ? 'cs-tab-active' : ''}`}
                disabled={phase === 'working'}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="m-0 mb-1.5 text-[11px] uppercase tracking-[0.5px] text-cs-t3">Archive depth</p>
          <select
            value={depth}
            onChange={(e) => setDepth(e.target.value)}
            className="rounded-cs-md border border-cs-bd3 bg-cs-b1 px-2.5 py-1.5 text-[12px] text-cs-t2 outline-none"
            disabled={phase === 'working'}
          >
            {DEPTHS.map((d) => (
              <option key={d.value} value={d.value}>
                {d.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between gap-3">
        <div className="flex gap-2">
          {DEMO_BRIEFS.map((demo) => (
            <button
              key={demo.label}
              type="button"
              onClick={() => setBrief(demo.brief)}
              className="text-[12px] text-cs-info hover:underline"
              disabled={phase === 'working'}
            >
              Try: {demo.label}
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={submit}
          disabled={!brief.trim() || phase === 'working'}
          className="rounded-full bg-cs-t1 px-5 py-2 text-[13px] font-medium text-white transition enabled:hover:opacity-85 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Compose package
        </button>
      </div>

      {phase === 'working' && (
        <div className="mt-5 rounded-cs-md bg-cs-b1 p-3.5">
          <p className="m-0 mb-1 text-[13px] font-medium text-cs-t1">
            on it — <span className="cs-pulse text-cs-t2">{ACK_STEPS[ackStep]}</span>
          </p>
          <p className="m-0 text-[12px] text-cs-t3">
            {fullPackageRouted ||
              'The intake router picks the route: asset quick-hit or full package.'}
          </p>
        </div>
      )}

      {phase === 'error' && (
        <div className="mt-5 rounded-cs-md bg-cs-dangerbg p-3.5">
          <p className="m-0 text-[13px] text-cs-danger">{error}</p>
        </div>
      )}

      {assetResult && (
        <div className="mt-6">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <p className="m-0 text-[13px] font-medium text-cs-t1">
              <span className="mr-2 rounded-full bg-cs-infobg px-2.5 py-1 text-[11px] font-semibold text-cs-info">
                Routed: asset search
              </span>
              {assetResult.total} match{assetResult.total === 1 ? '' : 'es'} — merged across
              connected sources
            </p>
            <Link
              href="/assets"
              className="text-[12px] text-cs-info hover:underline"
            >
              Open in /assets →
            </Link>
          </div>
          <AssetResults result={assetResult} />
        </div>
      )}
    </div>
  );
}
