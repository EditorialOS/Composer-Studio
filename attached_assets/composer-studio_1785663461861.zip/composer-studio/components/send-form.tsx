'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import type { ComposerPackage, SendDestination, SendRecord } from '@/lib/engine/types';
import { formatDate } from './ui';

const DESTINATIONS: Array<{ key: SendDestination; label: string; detail: string }> = [
  { key: 'beehiiv', label: 'beehiiv draft', detail: 'Creates a draft post natively in your beehiiv publication.' },
  { key: 'cms', label: 'CMS draft', detail: 'Stages the context block + asset sheet as a CMS draft.' },
  { key: 'download', label: 'Download all', detail: 'Bundle every deliverable + derivative URL.' },
];

export function SendForm({
  packages,
  sends: initialSends,
}: {
  packages: ComposerPackage[];
  sends: SendRecord[];
}) {
  const params = useSearchParams();
  const [packageId, setPackageId] = useState(params.get('package') ?? packages[0]?.id ?? '');
  const [destination, setDestination] = useState<SendDestination>('beehiiv');
  const [phase, setPhase] = useState<'idle' | 'working' | 'done' | 'error'>('idle');
  const [error, setError] = useState('');
  const [sends, setSends] = useState<SendRecord[]>(initialSends);

  const submit = async () => {
    if (!packageId || phase === 'working') return;
    setPhase('working');
    setError('');
    try {
      const res = await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packageId, destination }),
      });
      const data = (await res.json()) as { send?: SendRecord; error?: string };
      if (!res.ok || !data.send) throw new Error(data.error ?? 'Send failed.');
      setSends((prev) => [data.send!, ...prev]);
      setPhase('done');
    } catch (err) {
      setPhase('error');
      setError(err instanceof Error ? err.message : 'Send failed.');
    }
  };

  return (
    <div>
      <div className="cs-card mb-4">
        <p className="cs-card-label">Package</p>
        <select
          value={packageId}
          onChange={(e) => setPackageId(e.target.value)}
          className="w-full rounded-cs-md border border-cs-bd3 bg-cs-b1 px-2.5 py-2 text-[13px] text-cs-t1 outline-none"
        >
          {packages.map((pkg) => (
            <option key={pkg.id} value={pkg.id}>
              {pkg.headline}
            </option>
          ))}
        </select>

        <p className="cs-card-label mt-4">Destination</p>
        <div className="flex flex-col gap-2">
          {DESTINATIONS.map((d) => (
            <button
              key={d.key}
              type="button"
              onClick={() => setDestination(d.key)}
              className={`rounded-cs-md px-3.5 py-2.5 text-left transition ${
                destination === d.key ? 'bg-cs-infobg' : 'bg-cs-b1 hover:bg-cs-bd3/30'
              }`}
            >
              <p className={`m-0 text-[13px] font-medium ${destination === d.key ? 'text-cs-info' : 'text-cs-t1'}`}>
                {d.label}
              </p>
              <p className="m-0 mt-0.5 text-[12px] text-cs-t2">{d.detail}</p>
            </button>
          ))}
        </div>

        <div className="mt-4 flex items-center justify-end">
          <button
            type="button"
            onClick={submit}
            disabled={!packageId || phase === 'working'}
            className="rounded-full bg-cs-t1 px-5 py-2 text-[13px] font-medium text-white transition enabled:hover:opacity-85 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {phase === 'working' ? 'Sending…' : 'Send package'}
          </button>
        </div>

        {phase === 'error' && <p className="mb-0 mt-3 text-[13px] text-cs-danger">{error}</p>}
      </div>

      {sends.length > 0 && (
        <div>
          <p className="cs-card-label">Send log</p>
          <div className="flex flex-col gap-2">
            {sends.map((send) => (
              <div key={send.id} className="rounded-cs-md bg-cs-b2 px-4 py-3">
                <div className="flex items-center justify-between">
                  <p className="m-0 text-[13px] font-medium text-cs-t1">
                    {send.destination} · {send.status}
                  </p>
                  <p className="m-0 text-[11px] text-cs-t3">{formatDate(send.createdAt)}</p>
                </div>
                <p className="m-0 mt-0.5 text-[12px] text-cs-t2">{send.note}</p>
                {send.url && (
                  <a href={send.url} className="text-[12px] text-cs-info hover:underline">
                    {send.url}
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
