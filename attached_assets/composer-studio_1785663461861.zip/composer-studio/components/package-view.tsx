'use client';

import { useState } from 'react';
import Link from 'next/link';
import type { ComposerPackage } from '@/lib/engine/types';
import { Card, CardLabel, StatusDot, formatBytes, relativeTime } from './ui';

const TABS = [
  { key: 'editorial', label: 'Editorial assessment' },
  { key: 'assets', label: 'Asset matching' },
  { key: 'context', label: 'Market context' },
  { key: 'how', label: 'How it works' },
] as const;

type TabKey = (typeof TABS)[number]['key'];

const STEP_THEMES = [
  { bg: 'var(--color-background-info)', fg: 'var(--color-text-info)' },
  { bg: '#EEEDFE', fg: '#534AB7' },
  { bg: '#E1F5EE', fg: '#0F6E56' },
  { bg: '#FAECE7', fg: '#993C1D' },
  { bg: 'var(--color-background-success)', fg: 'var(--color-text-success)' },
];

export function PackageView({ pkg }: { pkg: ComposerPackage }) {
  const [tab, setTab] = useState<TabKey>('editorial');
  const { evaluation } = pkg;
  const revise = evaluation.verdict === 'REVISE';

  return (
    <div className="mx-auto max-w-[680px] px-6 py-8">
      {/* ── Header ── */}
      <div className="mb-1.5 flex items-center gap-2">
        {pkg.badge && (
          <span className="rounded-cs-md bg-cs-dangerbg px-2 py-0.5 text-[11px] font-medium uppercase tracking-[0.5px] text-cs-danger">
            {pkg.badge}
          </span>
        )}
        <span className="text-xs text-cs-t3">Package generated {relativeTime(pkg.createdAt)}</span>
        {pkg.provenance.generationMs > 0 && (
          <span className="text-xs text-cs-t3">· {(pkg.provenance.generationMs / 1000).toFixed(1)}s</span>
        )}
      </div>
      <h1 className="mb-1 text-[20px] font-medium leading-[1.3] text-cs-t1">{pkg.headline}</h1>
      <p className="mb-6 text-[13px] text-cs-t2">{pkg.subhead}</p>

      {/* ── Tab bar ── */}
      <div className="mb-6 flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`cs-tab ${tab === t.key ? 'cs-tab-active' : ''}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Editorial assessment ── */}
      {tab === 'editorial' && (
        <div className="cs-enter">
          <Card className="mb-3">
            <CardLabel>Five-gate evaluation — full priority</CardLabel>
            <div className="flex flex-col gap-2.5">
              {evaluation.gates.map((gate) => (
                <div key={gate.gate} className="flex items-center gap-2.5">
                  <StatusDot status={gate.status} />
                  <div>
                    <span className="text-[13px] font-medium text-cs-t1">{gate.gate}</span>
                    <span className="text-[13px] text-cs-t2"> — {gate.note}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <div
            className="mb-3 rounded-cs-lg p-4"
            style={{
              background: revise ? '#FCEBEB' : 'var(--color-background-success)',
            }}
          >
            <p
              className="mb-1.5 text-[13px] font-medium"
              style={{ color: revise ? '#791F1F' : 'var(--color-text-success)' }}
            >
              Verdict: {evaluation.verdict}
              {revise ? ' — and this is the useful part' : ' — cleared to publish'}
            </p>
            <p
              className="m-0 text-[13px] leading-[1.6]"
              style={{ color: revise ? '#A32D2D' : 'var(--color-text-success)' }}
            >
              {evaluation.verdictSummary}
            </p>
          </div>

          {evaluation.requiredRevisions.length > 0 && (
            <Card>
              <CardLabel>Required revisions from editorial director</CardLabel>
              <p className="m-0 text-[13px] leading-[1.7] text-cs-t1">
                {evaluation.requiredRevisions.map((rev, i) => (
                  <span key={i}>
                    {i + 1}. {rev}
                    <br />
                  </span>
                ))}
              </p>
              {evaluation.editorNote && (
                <p className="mb-0 mt-2.5 text-[13px] italic leading-[1.6] text-cs-t2">
                  {evaluation.editorNote}
                </p>
              )}
            </Card>
          )}
        </div>
      )}

      {/* ── Asset matching ── */}
      {tab === 'assets' && (
        <div className="cs-enter">
          {pkg.assetSearchNote && (
            <Card className="mb-3">
              <CardLabel>Asset search — honest notes</CardLabel>
              <p className="m-0 text-[13px] leading-[1.6] text-cs-t2">{pkg.assetSearchNote}</p>
            </Card>
          )}

          {pkg.assets.length === 0 && (
            <Card className="mb-3">
              <p className="m-0 text-[13px] text-cs-t2">
                No assets matched this brief. The gap is named rather than hidden.
              </p>
            </Card>
          )}

          <div className="mb-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {pkg.assets.map((asset) => (
              <div
                key={asset.id}
                className="relative overflow-hidden rounded-cs-lg"
                style={{ aspectRatio: '3/4' }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={asset.thumbnailUrl}
                  alt={asset.tags.join(', ') || asset.id}
                  className="h-full w-full object-cover"
                />
                <div
                  className="absolute inset-x-0 bottom-0 px-2.5 py-2"
                  style={{ background: 'linear-gradient(transparent, rgba(0,0,0,0.7))' }}
                >
                  {asset.photographer && (
                    <span className="block text-[11px] text-white">
                      Photographer: {asset.photographer}
                    </span>
                  )}
                  <span className="block text-[11px] text-white/70">
                    {asset.rightsLabel ??
                      `${asset.width}×${asset.height} · ${asset.format} · ${formatBytes(asset.bytes)}`}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {pkg.assets.some((a) => a.matchNote || a.rightsNote) && (
            <Card className="mb-3">
              <CardLabel>Asset intelligence</CardLabel>
              {pkg.assets.map((asset) => (
                <div key={asset.id} className="mb-2 last:mb-0">
                  {asset.matchNote && (
                    <p className="mb-1.5 text-[13px] leading-[1.6] text-cs-t1">{asset.matchNote}</p>
                  )}
                  {asset.rightsNote && (
                    <p className="mb-1.5 text-[12px] leading-[1.6] text-cs-warn">{asset.rightsNote}</p>
                  )}
                  <p className="m-0 text-[12px] text-cs-t3">
                    {asset.id} · {asset.width}×{asset.height} · {asset.format}
                    {asset.bytes ? ` · ${formatBytes(asset.bytes)}` : ''}
                    {asset.campaign ? ` · Campaign: ${asset.campaign}` : ''}
                  </p>
                </div>
              ))}
            </Card>
          )}

          <Card>
            <CardLabel>Live derivative generation</CardLabel>
            <div className="flex flex-wrap gap-2">
              {(pkg.assets[0]?.derivatives ?? []).map((d) => (
                <a key={d.key} href={d.url} target="_blank" rel="noreferrer" className="cs-pill text-cs-t2 hover:text-cs-t1">
                  {d.label}
                </a>
              ))}
              {pkg.assets.length === 0 &&
                ['Hero 16:9 (1920×1080)', 'Social square (1080×1080)', 'Story 9:16 (1080×1920)', 'Thumbnail (400×300)'].map(
                  (label) => (
                    <span key={label} className="cs-pill text-cs-t3">
                      {label}
                    </span>
                  ),
                )}
            </div>
            <p className="mb-0 mt-3 text-[13px] leading-[1.6] text-cs-t2">
              Derivatives are generated on the fly via URL params (
              <code className="cs-code">c_fill,w_1080,h_1080,g_auto</code>) —{' '}
              <code className="cs-code">g_auto</code> detects the subject so social crops need no
              manual art direction.
            </p>
          </Card>
        </div>
      )}

      {/* ── Market context ── */}
      {tab === 'context' && (
        <div className="cs-enter">
          {pkg.archive.connected ? (
            <>
              {pkg.archive.findings.map((finding, i) => (
                <Card key={i} className="mb-3">
                  <CardLabel>
                    From your archive — {finding.title}
                    {finding.date ? ` (${finding.date})` : ''}
                  </CardLabel>
                  <p className="m-0 text-[13px] leading-[1.6] text-cs-t2">{finding.excerpt}</p>
                </Card>
              ))}
              {pkg.archive.metrics.length > 0 && (
                <div className="mb-3 grid grid-cols-2 gap-3">
                  {pkg.archive.metrics.map((metric) => (
                    <div key={metric.label} className="rounded-cs-md bg-cs-b2 p-4">
                      <p className="m-0 mb-1 text-[11px] text-cs-t3">{metric.label}</p>
                      <p className="m-0 text-[22px] font-medium text-cs-t1">{metric.value}</p>
                      {metric.sub && <p className="m-0 mt-1 text-[12px] text-cs-t2">{metric.sub}</p>}
                    </div>
                  ))}
                </div>
              )}
              {pkg.archive.note && (
                <p className="mb-3 text-[12px] text-cs-t3">{pkg.archive.note}</p>
              )}
            </>
          ) : (
            <Card className="mb-3">
              <CardLabel>Archive</CardLabel>
              <p className="m-0 text-[13px] leading-[1.6] text-cs-t2">
                {pkg.archive.note ?? 'No archive configured.'}
              </p>
            </Card>
          )}

          {pkg.market.intro && (
            <Card className="mb-3">
              <CardLabel>
                {pkg.market.competitors.length > 0
                  ? 'Competitive landscape — live web research'
                  : 'Market context — live web research'}
              </CardLabel>
              <p className="mb-2.5 mt-0 text-[14px] leading-[1.6] text-cs-t1">{pkg.market.intro}</p>

              {pkg.market.competitors.length > 0 && (
                <div className="mb-2 flex flex-col gap-2">
                  {pkg.market.competitors.map((comp) => (
                    <div
                      key={comp.name}
                      className="rounded-r-cs-md bg-cs-b1 px-3.5 py-2.5"
                      style={{ borderLeft: `3px solid ${comp.color}` }}
                    >
                      <p className="m-0 text-[13px] font-medium text-cs-t1">
                        {comp.sourceUrl ? (
                          <a href={comp.sourceUrl} target="_blank" rel="noreferrer" className="hover:underline">
                            {comp.name}
                          </a>
                        ) : (
                          comp.name
                        )}
                      </p>
                      <p className="m-0 mt-0.5 text-[12px] text-cs-t2">{comp.detail}</p>
                    </div>
                  ))}
                </div>
              )}

              {pkg.market.facts.length > 0 && (
                <ul className="m-0 flex list-none flex-col gap-1.5 p-0">
                  {pkg.market.facts.map((fact, i) => (
                    <li key={i} className="text-[13px] leading-[1.6] text-cs-t2">
                      {fact.text}{' '}
                      <a
                        href={fact.sourceUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="cs-code text-cs-info hover:underline"
                      >
                        {fact.sourceName ?? 'source'}
                      </a>
                    </li>
                  ))}
                </ul>
              )}

              {pkg.market.droppedFactCount > 0 && (
                <p className="mb-0 mt-2 text-[12px] italic text-cs-warn">
                  {pkg.market.droppedFactCount} fact{pkg.market.droppedFactCount > 1 ? 's' : ''} dropped
                  at assembly — no source URL (no URL, no fact).
                </p>
              )}
            </Card>
          )}

          {pkg.market.callout && (
            <div className="rounded-cs-md bg-cs-infobg px-4 py-3">
              <p className="m-0 text-[13px] leading-[1.6] text-cs-info">{pkg.market.callout}</p>
            </div>
          )}
        </div>
      )}

      {/* ── How it works (workflow + provenance) ── */}
      {tab === 'how' && (
        <div className="cs-enter">
          <CardLabel>What just happened — the coordination layer</CardLabel>
          <div className="mb-4 flex flex-col">
            {pkg.workflow.map((step, i) => (
              <div key={i}>
                {i > 0 && (
                  <div
                    className="ml-[14px] h-3 w-0"
                    style={{ borderLeft: '1px dashed var(--color-border-secondary)' }}
                  />
                )}
                <div className="flex items-start gap-3 py-3">
                  <div
                    className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full text-[12px] font-medium"
                    style={{
                      background: STEP_THEMES[i % STEP_THEMES.length].bg,
                      color: STEP_THEMES[i % STEP_THEMES.length].fg,
                    }}
                  >
                    {i + 1}
                  </div>
                  <div>
                    <p className="m-0 mb-0.5 text-[14px] font-medium text-cs-t1">{step.title}</p>
                    <p className="m-0 text-[13px] text-cs-t2">{step.detail}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mb-3 rounded-cs-lg bg-cs-successbg p-4">
            <p className="m-0 mb-1.5 text-[13px] font-medium text-cs-success">What worked</p>
            <p className="m-0 text-[13px] leading-[1.7] text-cs-success">
              {pkg.provenance.worked.join(' · ')}
            </p>
          </div>

          <div className="mb-3 rounded-cs-lg p-4" style={{ background: '#FCEBEB' }}>
            <p className="m-0 mb-1.5 text-[13px] font-medium" style={{ color: '#791F1F' }}>
              What didn&apos;t
            </p>
            <p className="m-0 text-[13px] leading-[1.7]" style={{ color: '#A32D2D' }}>
              {pkg.provenance.didntWork.join(' · ')}
            </p>
          </div>

          {pkg.provenance.capabilityNotes.length > 0 && (
            <Card>
              <CardLabel>Capability probing — reported honestly</CardLabel>
              <div className="flex flex-col gap-2">
                {pkg.provenance.capabilityNotes.map((note, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <span
                      className="cs-dot mt-1"
                      style={{
                        background:
                          note.tone === 'ok' ? '#639922' : note.tone === 'warn' ? '#EF9F27' : '#E24B4A',
                      }}
                    />
                    <p className="m-0 text-[13px] leading-[1.6] text-cs-t2">
                      <span className="font-medium text-cs-t1">{note.area}</span> — {note.note}
                    </p>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}

      {/* ── Deliverables (always visible below tabs) ── */}
      <div className="mt-8">
        <CardLabel>Assembled deliverables — ready to publish</CardLabel>
        {pkg.deliverables.map((d) => (
          <div key={d.title} className="mb-4 pl-4" style={{ borderLeft: `3px solid ${d.color}` }}>
            <p className="m-0 mb-1 text-[13px] font-medium text-cs-t1">{d.title}</p>
            <p className="m-0 text-[13px] leading-[1.6] text-cs-t2">{d.detail}</p>
          </div>
        ))}

        {/* ── Download section ── */}
        <div id="download" className="mt-2 rounded-cs-md bg-cs-infobg px-4 py-3">
          <p className="m-0 text-[13px] leading-[1.6] text-cs-info">
            All components editable. Assets served via CDN — no file management needed.{' '}
            {pkg.assets.flatMap((a) => a.derivatives).length > 0 && (
              <>
                Download derivatives:{' '}
                {pkg.assets[0].derivatives.map((d) => (
                  <a key={d.key} href={d.url} target="_blank" rel="noreferrer" className="underline">
                    {d.key}
                  </a>
                )).reduce<React.ReactNode[]>((acc, el, i) => (i === 0 ? [el] : [...acc, ' · ', el]), [])}
                .{' '}
              </>
            )}
            <Link href={`/send?package=${pkg.id}`} className="font-medium underline">
              Send onward →
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
