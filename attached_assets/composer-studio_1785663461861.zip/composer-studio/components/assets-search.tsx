'use client';

import { useState } from 'react';
import type { AssetSearchResult, AssetSourceReport } from '@/lib/engine/types';
import { RightsBadge, formatBytes } from './ui';

const SOURCE_STATUS_COLOR: Record<AssetSourceReport['status'], string> = {
  matched: 'text-cs-success',
  'searched-empty': 'text-cs-warn',
  'not-connected': 'text-cs-t3',
};

/** Merged results grid + the per-source honesty report. */
export function AssetResults({ result }: { result: AssetSearchResult }) {
  return (
    <div>
      {/* Per-source honesty: what was searched, what matched, what isn't connected. */}
      <div className="mb-4 flex flex-wrap gap-x-5 gap-y-1.5">
        {result.sources.map((src) => (
          <p key={src.source} className="m-0 text-[12px]">
            <span className="font-medium text-cs-t1">{src.source}:</span>{' '}
            <span className={SOURCE_STATUS_COLOR[src.status]}>{src.note}</span>
          </p>
        ))}
      </div>

      {result.total === 0 ? (
        <p className="m-0 rounded-cs-md bg-cs-b1 p-3.5 text-[13px] text-cs-t2">
          No assets matched across connected sources. The per-source notes above say exactly
          what was searched.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          {result.assets.map((asset) => (
            <div key={asset.id} className="overflow-hidden rounded-cs-lg bg-cs-b2">
              <div className="relative" style={{ aspectRatio: '4/3' }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={asset.thumbnailUrl}
                  alt={asset.tags.join(', ') || asset.id}
                  className="h-full w-full object-cover"
                  loading="lazy"
                />
                <div className="absolute left-2 top-2">
                  <RightsBadge status={asset.rightsStatus} />
                </div>
              </div>
              <div className="p-3">
                <p className="m-0 truncate text-[12px] font-medium text-cs-t1">{asset.id}</p>
                <p className="m-0 mt-0.5 text-[11px] text-cs-t2">
                  {asset.photographer ? `${asset.photographer} · ` : ''}
                  {asset.width}×{asset.height}
                  {asset.bytes ? ` · ${formatBytes(asset.bytes)}` : ''}
                </p>
                {asset.rightsLabel && (
                  <p className="m-0 mt-0.5 text-[11px] text-cs-t2">Rights: {asset.rightsLabel}</p>
                )}
                {asset.rightsExpiresAt && (
                  <p className="m-0 mt-0.5 text-[11px] text-cs-warn">
                    Expires{' '}
                    {new Date(asset.rightsExpiresAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </p>
                )}
                {asset.rightsNote && (
                  <p className="m-0 mt-0.5 text-[11px] text-cs-t3">{asset.rightsNote}</p>
                )}
                {asset.derivatives.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {asset.derivatives.map((d) => (
                      <a
                        key={d.key}
                        href={d.url}
                        target="_blank"
                        rel="noreferrer"
                        title={`${d.label} — ${d.width}×${d.height}`}
                        className="rounded bg-cs-b1 px-1.5 py-0.5 text-[10px] text-cs-info hover:underline"
                      >
                        {d.key}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/** Standalone /assets quick-hit: one box, merged source-agnostic results. */
export function AssetsSearch() {
  const [query, setQuery] = useState('');
  const [phase, setPhase] = useState<'idle' | 'working' | 'error'>('idle');
  const [error, setError] = useState('');
  const [result, setResult] = useState<AssetSearchResult | null>(null);

  const submit = async (q?: string) => {
    const value = (q ?? query).trim();
    if (!value || phase === 'working') return;
    setPhase('working');
    setError('');
    try {
      const res = await fetch('/api/assets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: value }),
      });
      const data = (await res.json()) as AssetSearchResult & { error?: string };
      if (!res.ok) throw new Error(data.error ?? 'Search failed.');
      setResult(data);
      setPhase('idle');
    } catch (err) {
      setPhase('error');
      setError(err instanceof Error ? err.message : 'Search failed.');
    }
  };

  return (
    <div>
      <div className="cs-card">
        <div className="flex gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') void submit();
            }}
            placeholder='Search every connected library — e.g. "apple pictures"'
            className="w-full rounded-cs-md border border-cs-bd3 bg-cs-b1 px-3 py-2 text-[14px] text-cs-t1 outline-none placeholder:text-cs-t3 focus:border-cs-info"
            disabled={phase === 'working'}
          />
          <button
            type="button"
            onClick={() => void submit()}
            disabled={!query.trim() || phase === 'working'}
            className="shrink-0 rounded-full bg-cs-t1 px-5 py-2 text-[13px] font-medium text-white transition enabled:hover:opacity-85 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {phase === 'working' ? 'Searching…' : 'Search assets'}
          </button>
        </div>
        <button
          type="button"
          onClick={() => {
            setQuery('apple pictures');
            void submit('apple pictures');
          }}
          className="mt-2 text-[12px] text-cs-info hover:underline"
          disabled={phase === 'working'}
        >
          Try: apple pictures
        </button>
      </div>

      {phase === 'error' && (
        <div className="mt-4 rounded-cs-md bg-cs-dangerbg p-3.5">
          <p className="m-0 text-[13px] text-cs-danger">{error}</p>
        </div>
      )}

      {result && (
        <div className="mt-5">
          <p className="cs-card-label">
            {result.total} match{result.total === 1 ? '' : 'es'} for &quot;{result.query}&quot; —
            merged across sources
          </p>
          <AssetResults result={result} />
        </div>
      )}
    </div>
  );
}
