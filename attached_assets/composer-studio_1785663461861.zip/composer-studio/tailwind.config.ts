import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-geist)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-geist-mono)', 'ui-monospace', 'monospace'],
      },
      colors: {
        // Legacy warm palette (folded-in pages: audit, billing, settings)
        os: {
          bg: '#efede8',
          surface: '#f7f5f0',
          border: '#dad4ca',
          muted: '#7a736b',
          text: '#1f1b16',
          accent: '#3b6b7a',
          success: '#2e7d5b',
          warning: '#b46a2d',
        },
        // Composer Studio tokens (reference package designs)
        cs: {
          t1: 'var(--color-text-primary)',
          t2: 'var(--color-text-secondary)',
          t3: 'var(--color-text-tertiary)',
          b1: 'var(--color-background-primary)',
          b2: 'var(--color-background-secondary)',
          bd2: 'var(--color-border-secondary)',
          bd3: 'var(--color-border-tertiary)',
          info: 'var(--color-text-info)',
          infobg: 'var(--color-background-info)',
          success: 'var(--color-text-success)',
          successbg: 'var(--color-background-success)',
          warn: 'var(--color-text-warning)',
          warnbg: 'var(--color-background-warning)',
          danger: 'var(--color-text-danger)',
          dangerbg: 'var(--color-background-danger)',
          pass: 'var(--dot-pass)',
          amber: 'var(--dot-warn)',
          fail: 'var(--dot-fail)',
          unknown: 'var(--dot-unknown)',
        },
      },
      borderRadius: {
        'cs-md': 'var(--border-radius-md)',
        'cs-lg': 'var(--border-radius-lg)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}

export default config
