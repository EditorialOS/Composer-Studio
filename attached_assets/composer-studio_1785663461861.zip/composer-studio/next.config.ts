import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'res.cloudinary.com',
      },
    ],
  },
  serverExternalPackages: ['cloudinary'],
  // Make the mock flag available to client components without
  // requiring a second env var to be set by hand.
  env: {
    NEXT_PUBLIC_COMPOSER_MOCK: process.env.COMPOSER_MOCK ?? '',
  },
};

export default nextConfig;
