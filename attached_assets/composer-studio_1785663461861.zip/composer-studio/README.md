# Composer Studio

**Paste a brief, get a publishable package** — your images, rights-checked and cropped; your
archive's prior coverage; the competitive landscape; the angle to take. Works with the DAM and
CMS you already have. Is one if you don't.

## Quickstart (zero API keys)

```bash
npm install
COMPOSER_MOCK=1 npm run dev
```

Open http://localhost:3000 — you are **Demo Publication**, fully signed in. Everything works
end-to-end with mock adapters and rich fixtures:

- **Compose** (`/compose`) — paste a brief (or click a demo brief). The intake router
  classifies it automatically: story/brief → the full package loop; short find-intent
  (e.g. "search for apple pictures") → the asset quick-hit. The UI shows which route
  was taken ("Routed: asset search" vs "Routed: full package").
- **Assets** (`/assets`) — the standalone quick-hit: source-agnostic search across every
  connected library with rights badges, derivative pills, and an honest per-source report
  (matched / searched-but-empty / not connected — e.g. Drive searches *filenames only*).
- **The Package** (`/package/casa-soledad`, `/package/noto-earthquake`) — the tabbed artifact:
  five-gate editorial assessment with verdict + required revisions, rights-badged asset matching
  with derivative crops, market context with source-URL'd facts, and honest provenance
  ("what worked vs didn't").
- **Library** (`/library`) — asset grid with CLEARED / EXPIRING / CHECK / UNKNOWN rights badges.
- **Send** (`/send`) — beehiiv draft / CMS draft / download-all (all mock).
- **Memory** (`/memory`) — every package logged: lanes taken, rights flagged, verdict.
- **Workspace** (`/onboarding`) — active themes, recent coverage, voice notes, calendar. The
  gate evaluation consumes these on every run. Includes adapter capability probing.

Two fixture packages seed automatically: **Casa Soledad** (hotel launch, REVISE with a red on
theme alignment) and **Noto earthquake** (breaking news context package).

## Architecture map

```
app/
  compose/            brief input → POST /api/compose → intake router → package OR asset quick-hit
  assets/             standalone asset quick-hit (source-agnostic, per-source honesty)
  package/[id]/       the hero screen (components/package-view.tsx — tabbed artifact)
  library/            asset grid + rights badges
  send/               one click onward
  memory/             package log
  onboarding/         workspace context + capability probing
  marketing/          landing page ("Paste a brief, get a publishable package")
  api/compose|assets|send|workspace/  engine routes
  api/mcp/            MCP endpoint (Streamable HTTP) — same engine, agent-callable
  api/dam|stripe|billing|audit/ Pixel-Sky fold-ins (billing, audit, BYOC Cloudinary)
components/
  package-view.tsx    tabbed package UI (ported from the reference HTML designs)
  assets-search.tsx   quick-hit form + merged results grid (reused by compose-form)
  nav.tsx, ui.tsx, compose-form.tsx, send-form.tsx, workspace-form.tsx
lib/
  mock.ts             COMPOSER_MOCK flag + demo workspace
  workspace.ts        org resolution (Clerk in prod, demo org in mock)
  engine/
    types.ts          domain types + the six adapter interfaces
    router.ts         THE INTAKE ROUTER (asset quick-hit vs full package)
    assets.ts         source-agnostic asset fan-out + rights check
    compose.ts        THE COMPOSE LOOP
    mcp.ts            MCP tool implementations (shared engine, thin wrapper)
    store.ts          package/memory/send/workspace store (file mock → Supabase in prod)
    derivatives.ts    Cloudinary URL transforms (hero/social/story/thumb)
    fixtures/         Casa Soledad + Noto earthquake reference packages (+ apple quick-hit)
    adapters/
      index.ts        getAdapters() — mock vs real selection + capability probing
      mock/           rich fixtures, honest gaps (visualSearch: false, etc.)
      real/           env-reading stubs (Tavily, Cloudinary, beehiiv, OpenAI)
  supabase.ts, stripe.ts, openai.ts, cloudinary.ts, billing.ts, audit.ts …  fold-in infra
middleware.ts         Clerk middleware with COMPOSER_MOCK=1 bypass; /api/mcp does Bearer auth
```

### The intake router (lib/engine/router.ts)

One input box; the brief classifies itself (spec Part 5B). Short asset-search intent → the
`/assets` quick-hit (AssetAdapter fan-out only — no archive, no market context). Story/brief →
the full compose loop. Mock mode uses a keyword/length heuristic; the LLM classification seam
is typed (TODO in router.ts). The classification table grows by rows, not rebuilds.

### The compose loop (lib/engine/compose.ts)

1. **Parse brief** → headline, kind, search tags, scenario (ModelAdapter)
2. **Editorial gate evaluation** — five gates (theme alignment, angle differentiation, audience
   need, production reality, calendar fit) with colored status + verdict APPROVED/REVISE +
   required revisions. Consumes workspace context.
3. **PARALLEL** archive search + asset search + market context (Promise.all)
4. **Rights enrichment + derivative crops** (RightsAdapter, AssetAdapter transforms)
5. **Filtration** — any market-context fact without a `sourceUrl` is dropped at assembly, in
   code, and counted honestly ("no URL, no fact").
6. **Assemble Package** → save → **log to memory** (lanes taken, rights flagged).

### The adapter seam (spec Part 5)

Every capability is a pluggable adapter — nothing is hardwired. Each adapter reports
capabilities; the engine degrades gracefully and names every gap in the package's provenance.

| Adapter | Interface | Mock | Real stub reads |
|---|---|---|---|
| `webSearch` | `SearchAdapter` | fixture market context | `COMPOSER_SEARCH_PROVIDER` + `TAVILY_API_KEY` / `BRAVE_SEARCH_API_KEY` / `PERPLEXITY_API_KEY` |
| `imageLibrary` | `AssetAdapter` | fixture assets + derivatives | `CLOUDINARY_*` |
| `archive` | `ArchiveAdapter` | fixture prior coverage | none yet (reports "No archive configured") |
| `rights` | `RightsAdapter` | embedded-metadata simulation | reads Cloudinary context metadata |
| `send` | `SendAdapter` | mock beehiiv/CMS/download | `BEEHIIV_API_KEY` + `BEEHIIV_PUBLICATION_ID` |
| `llm` | `ModelAdapter` | fixture + heuristic gate eval | heuristic now; OpenAI/Anthropic seam typed |

Rules of the seam: search is hot-swappable; anything the user has, Composer can ride; graceful
degradation is a product feature (the package always ships, gaps are always named); every
adapter ships a mock so the product runs offline end-to-end.

## MCP (agent access — same engine, thin wrapper)

The engine is exposed as MCP tools over Streamable HTTP at **`/api/mcp`**
(`app/api/mcp/route.ts`, `@modelcontextprotocol/sdk`). One engine, two faces: the dashboard is
the money product; MCP is the distribution play — same adapters, same fixtures, same honesty.

**Tools** (`GET /api/mcp` returns the tools/list-compatible descriptor):

| Tool | What it does |
|---|---|
| `search_assets(query)` | Merged asset results + per-source honesty report (matched / searched-but-empty / not connected) |
| `compose_package(brief)` | Full package JSON: `id`, `verdict`, and the complete tabs payload |
| `check_rights(asset_id)` | Rights badge + expiry + photographer, with "not on file" honesty |
| `send_package(package_id, destination)` | beehiiv draft / CMS draft / download (mock adapters in mock mode) |

**Auth:** every request needs `Authorization: Bearer <COMPOSER_API_KEY>`. In `COMPOSER_MOCK=1`
any non-empty key works and resolves the demo org; missing/invalid keys get a JSON-RPC-shaped
`401`. Real mode compares against `COMPOSER_API_KEY` (org pinning via `COMPOSER_MCP_ORG_ID`
until per-customer key storage lands).

**Claude Cowork / Desktop config** (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "composer-studio": {
      "url": "https://<your-host>/api/mcp",
      "headers": { "Authorization": "Bearer <COMPOSER_API_KEY>" }
    }
  }
}
```

Local dev: `"url": "http://localhost:3000/api/mcp"`, any bearer token while `COMPOSER_MOCK=1`.

## Environment

See `.env.example` for the full table. Only `COMPOSER_MOCK=1` is required for the demo. For
production: Clerk (auth), Supabase (store/billing/audit), Cloudinary (library), Stripe
(billing), a search provider, beehiiv (send), OpenAI/Anthropic (models). `HANDOFF.md` has the
dummy-proof version.

## Scripts

```bash
npm run dev     # develop
npm run build   # production build
npm run start   # serve the build
npm run lint    # eslint
```

## Deploy

Standard Next.js on Vercel. Set env vars per `.env.example` / `HANDOFF.md`. In mock mode no
env vars are needed at all.
